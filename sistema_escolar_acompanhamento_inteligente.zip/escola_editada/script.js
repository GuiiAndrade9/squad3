document.addEventListener('DOMContentLoaded', () => {
  const STORAGE = 'siged_saas_v5';
  const defaultData = () => ({
    currentSchoolId: null,
    currentUserId: null,
    schools: [],
    classes: [],
    teachers: [],
    students: [],
    guardians: [],
    mockUsers: [],
    teacherAssignments: [],
    calendars: [],
    activities: [],
    certificates: [],
    occurrences: [],
    users: [],
    jobs: [],
    candidates: [],
    employees: [],
    payrollRuns: [],
    substitutes: [],
    benefits: [],
    leaves: [],
    terminations: [],
    trainings: [],
    evaluations: [],
    careerPlans: [],
    climateSurveys: [],
    wellbeing: [],
    safety: [],
    unions: [],
    lgpd: [],
    ethicsCases: [],
    interns: [],
    announcements: [],
    notifications: [],
    serviceRequests: [],
    appointments: [],
    queueTickets: [],
    academicPeriods: [],
    enrollmentRequests: [],
    spaces: [],
    assets: [],
    library: [],
    transportRoutes: [],
    transportVehicles: [],
    transportDrivers: [],
    meals: [],
    mealStock: [],
    healthRecords: [],
    aeeRecords: [],
    financeRecords: [],
    publicFunds: [],
    publicExpenses: [],
    documentIssuances: [],
    studentDocuments: [],
    contactLogs: [],
    lessonPlans: [],
    lessonRecords: [],
    grades: [],
    trackingRecords: [],
    classCouncils: [],
    schoolCouncil: [],
    inventory: [],
    auditLog: [],
    permissions: {}
  });

  const load = () => {
    try { return { ...defaultData(), ...JSON.parse(localStorage.getItem(STORAGE) || '{}') }; }
    catch { return defaultData(); }
  };
  const state = load();
  const save = () => {
    try { localStorage.setItem(STORAGE, JSON.stringify(state)); }
    catch (err) {
      console.error('Falha ao salvar no localStorage', err);
      showToast('Não foi possível salvar: o armazenamento do navegador está cheio. Tente remover algum anexo grande e salvar novamente.');
    }
  };

  const roles = {
    direcao: {
      name: 'Direção / Administrador', sector: 'Direção Escolar', icon: 'fa-user-tie',
      description: 'Gestão institucional, indicadores, pessoas, estrutura, financeiro, decisões, relatórios, permissões e configurações.',
      menu: [
        ['VISÃO GERAL','dashboard','fa-chart-pie','Visão geral'],
        ['APROVAÇÕES','jobs','fa-bullhorn','Aprovação de vagas'],
        ['APROVAÇÕES','employees','fa-sack-dollar','Confirmação financeira e acessos'],
        ['ACOMPANHAMENTO PEDAGÓGICO','atRisk','fa-heart-circle-exclamation','Alunos em acompanhamento'],
        ['ACOMPANHAMENTO PEDAGÓGICO','classCouncils','fa-users-rectangle','Conselho de classe'],
        ['ESCOLA E ESTRUTURA','schools','fa-school','Dados da escola'],
        ['ESCOLA E ESTRUTURA','spaces','fa-building','Estrutura física'],
        ['GESTÃO DO SISTEMA','users','fa-user-shield','Usuários e perfis'],
        ['GESTÃO DO SISTEMA','permissions','fa-lock','Permissões por perfil'],
        ['GESTÃO DO SISTEMA','auditLog','fa-magnifying-glass-chart','Auditoria'],
        ['GESTÃO DO SISTEMA','settings','fa-gear','Configurações'],
        ['FINANCEIRO','financeRecords','fa-sack-dollar','Financeiro'],
        ['SERVIÇOS ESCOLARES','library','fa-book','Biblioteca'],
        ['SERVIÇOS ESCOLARES','transportRoutes','fa-bus','Transporte'],
        ['SERVIÇOS ESCOLARES','meals','fa-utensils','Alimentação escolar'],
        ['SERVIÇOS ESCOLARES','healthRecords','fa-notes-medical','Saúde e apoio escolar'],
        ['SERVIÇOS ESCOLARES','assets','fa-boxes-stacked','Estoque e patrimônio'],
        ['COMUNICAÇÃO','announcements','fa-bullhorn','Comunicados institucionais'],
        ['CALENDÁRIO','calendar','fa-calendar-days','Calendário institucional'],
        ['CONSULTAS','reports','fa-chart-line','Indicadores e relatórios']
      ]
    },
    secretaria_gestao: {
      name: 'Secretaria — Gestão Escolar', sector: 'Gestão Acadêmica', icon: 'fa-building-columns',
      description: 'Matrículas, turmas, calendário, horários, currículo, notas, frequência, diário, histórico e processos acadêmicos.',
      menu: [
        ['INÍCIO','dashboard','fa-house','Painel operacional'],
        ['ANO LETIVO','academicPeriods','fa-calendar-check','Ano letivo e períodos'],
        ['ESTRUTURA ESCOLAR','schools','fa-school','Dados da escola'],
        ['ESTRUTURA ESCOLAR','classes','fa-people-roof','Turmas e séries'],
        ['ESTRUTURA ESCOLAR','curriculum','fa-book-open','Matrizes curriculares'],
        ['ESTRUTURA ESCOLAR','schedule','fa-clock','Grade de horários'],
        ['VIDA ACADÊMICA','enrollmentRequests','fa-user-pen','Matrículas e transferências'],
        ['VIDA ACADÊMICA','diaryBook','fa-book-journal-whills','Diário de classe'],
        ['VIDA ACADÊMICA','attendance','fa-clipboard-check','Frequência'],
        ['VIDA ACADÊMICA','gradebook','fa-marker','Notas'],
        ['VIDA ACADÊMICA','reportCard','fa-file-lines','Boletim'],
        ['VIDA ACADÊMICA','documents','fa-folder-open','Documentação acadêmica'],
        ['PEDAGÓGICO','atRisk','fa-heart-circle-exclamation','Alunos em acompanhamento'],
        ['PEDAGÓGICO','classCouncils','fa-users-rectangle','Conselho de classe'],
        ['PESSOAS','teachers','fa-chalkboard-user','Professores'],
        ['PESSOAS','assignments','fa-diagram-project','Distribuição de professores'],
        ['PESSOAS','students','fa-user-graduate','Alunos'],
        ['PESSOAS','guardians','fa-people-roof','Responsáveis'],
        ['CALENDÁRIO','calendar','fa-calendar-days','Calendários escolares'],
        ['CONSULTAS','reports','fa-file-lines','Relatórios']
      ]
    },
    secretaria_atendimento: {
      name: 'Secretaria — Atendimento', sector: 'Atendimento Escolar', icon: 'fa-headset',
      description: 'Atendimento, protocolos, solicitações, documentos, agendamentos, cadastro e comunicação com alunos e responsáveis.',
      menu: [
        ['INÍCIO','dashboard','fa-headset','Atendimento de hoje'],
        ['ALUNOS','students','fa-user-graduate','Buscar aluno'],
        ['ALUNOS','guardians','fa-people-roof','Responsáveis'],
        ['ALUNOS','classes','fa-people-roof','Consultar turmas'],
        ['ATENDIMENTO','serviceRequests','fa-ticket','Solicitações e protocolos'],
        ['ATENDIMENTO','appointments','fa-calendar-check','Agendamentos'],
        ['ATENDIMENTO','queueTickets','fa-list-ol','Fila de atendimento'],
        ['ATENDIMENTO','contactLogs','fa-phone-volume','Central de atendimento'],
        ['DOCUMENTOS','documentIssuances','fa-file-export','Emissão rápida de documentos'],
        ['DOCUMENTOS','studentDocuments','fa-folder-open','Gestão documental'],
        ['DOCUMENTOS','certificates','fa-file-medical','Atestados'],
        ['DOCUMENTOS','occurrences','fa-clipboard-list','Ocorrências'],
        ['COMUNICAÇÃO','announcements','fa-bullhorn','Comunicação com famílias'],
        ['CALENDÁRIO','calendar','fa-calendar-day','Agenda anual'],
        ['CONSULTAS','reports','fa-file-lines','Atendimentos e relatórios']
      ]
    },
    professor: {
      name: 'Portal do Professor', sector: 'Professor', icon: 'fa-chalkboard-user',
      description: 'Diário, frequência, notas, planejamento, conteúdos, comunicação, ocorrências e calendário das suas turmas.',
      menu: [
        ['INÍCIO','dashboard','fa-house','Painel do professor'],
        ['MINHAS TURMAS','classes','fa-people-roof','Turmas'],
        ['MINHAS TURMAS','schedule','fa-clock','Horários'],
        ['VIDA ACADÊMICA','diaryBook','fa-book-journal-whills','Diário de classe'],
        ['VIDA ACADÊMICA','attendance','fa-clipboard-check','Frequência'],
        ['VIDA ACADÊMICA','gradebook','fa-marker','Notas'],
        ['VIDA ACADÊMICA','lessonPlans','fa-list-check','Planejamento de aulas'],
        ['COMUNICAÇÃO','occurrences','fa-clipboard-list','Ocorrências'],
        ['COMUNICAÇÃO','announcements','fa-bullhorn','Comunicados'],
        ['CALENDÁRIO','calendar','fa-calendar-days','Calendário escolar']
      ]
    },
    aluno: {
      name: 'Portal do Aluno', sector: 'Aluno', icon: 'fa-user-graduate',
      description: 'Boletim, notas, frequência, horários, calendário, documentos, solicitações e comunicados.',
      menu: [
        ['INÍCIO','dashboard','fa-house','Painel do aluno'],
        ['MINHA VIDA ESCOLAR','reportCard','fa-file-lines','Boletim'],
        ['MINHA VIDA ESCOLAR','attendance','fa-clipboard-check','Frequência'],
        ['MINHA VIDA ESCOLAR','schedule','fa-clock','Horários'],
        ['MINHA VIDA ESCOLAR','calendar','fa-calendar-days','Calendário'],
        ['SERVIÇOS','serviceRequests','fa-ticket','Minhas solicitações'],
        ['SERVIÇOS','studentDocuments','fa-folder-open','Meus documentos'],
        ['COMUNICAÇÃO','announcements','fa-bullhorn','Comunicados']
      ]
    },
    responsavel: {
      name: 'Portal do Responsável', sector: 'Responsável', icon: 'fa-house-user',
      description: 'Filhos vinculados, boletim, frequência, ocorrências, agenda, comunicados, documentos, solicitações e financeiro.',
      menu: [
        ['INÍCIO','dashboard','fa-house','Painel do responsável'],
        ['MEUS FILHOS','reportCard','fa-file-lines','Boletim'],
        ['MEUS FILHOS','attendance','fa-clipboard-check','Frequência'],
        ['ACOMPANHAMENTO','occurrences','fa-clipboard-list','Ocorrências'],
        ['ACOMPANHAMENTO','calendar','fa-calendar-days','Calendário'],
        ['SERVIÇOS','serviceRequests','fa-ticket','Solicitações'],
        ['SERVIÇOS','financeRecords','fa-sack-dollar','Financeiro'],
        ['COMUNICAÇÃO','announcements','fa-bullhorn','Comunicados']
      ]
    },
    rh: {
      name: 'Recursos Humanos', sector: 'RH — Pessoas', icon: 'fa-people-arrows',
      description: 'Conduz todo o ciclo de RH: recrutamento, departamento pessoal, desenvolvimento, clima, compliance e ética.',
      menu: [
        ['INÍCIO','dashboard','fa-house','Painel de RH'],
        ['RECRUTAMENTO','jobs','fa-bullhorn','Vagas abertas'],
        ['RECRUTAMENTO','candidates','fa-user-check','Candidatos'],
        ['RECRUTAMENTO','substitutes','fa-user-clock','Banco de substitutos'],
        ['DEPARTAMENTO PESSOAL','employees','fa-id-card','Funcionários'],
        ['DEPARTAMENTO PESSOAL','payroll','fa-sack-dollar','Folha de pagamento'],
        ['DEPARTAMENTO PESSOAL','benefits','fa-hand-holding-heart','Benefícios e bolsas'],
        ['DEPARTAMENTO PESSOAL','leaves','fa-bed-pulse','Afastamentos e licenças'],
        ['DEPARTAMENTO PESSOAL','terminations','fa-file-signature','Rescisões e homologações'],
        ['DESENVOLVIMENTO','trainings','fa-chalkboard','Treinamentos e formação'],
        ['DESENVOLVIMENTO','evaluations','fa-star-half-stroke','Avaliação de desempenho'],
        ['DESENVOLVIMENTO','careerPlans','fa-stairs','Plano de carreira (PCCS)'],
        ['CLIMA E BEM-ESTAR','climateSurveys','fa-face-smile','Pesquisa de clima'],
        ['CLIMA E BEM-ESTAR','wellbeing','fa-heart-pulse','Bem-estar e endomarketing'],
        ['SERVIÇOS ESCOLARES','aeeRecords','fa-hands-holding-child','Educação Especial (AEE)'],
        ['SERVIÇOS ESCOLARES','healthRecords','fa-briefcase-medical','Saúde e apoio escolar'],
        ['SERVIÇOS ESCOLARES','inventory','fa-boxes-stacked','Estoque'],
        ['SERVIÇOS ESCOLARES','transportVehicles','fa-bus','Transporte — veículos'],
        ['SERVIÇOS ESCOLARES','transportDrivers','fa-id-badge','Transporte — motoristas'],
        ['FINANCEIRO PÚBLICO','publicFunds','fa-hand-holding-dollar','Recursos'],
        ['FINANCEIRO PÚBLICO','publicExpenses','fa-file-invoice-dollar','Despesas'],
        ['GESTÃO DO SISTEMA','census','fa-clipboard-check','Censo Escolar'],
        ['COMPLIANCE','safety','fa-briefcase-medical','Segurança e medicina (SST)'],
        ['COMPLIANCE','unions','fa-scale-balanced','Sindicatos e CCT'],
        ['COMPLIANCE','lgpd','fa-shield-halved','Adequação à LGPD'],
        ['ÉTICA','ethicsCases','fa-user-secret','Ouvidoria e ética'],
        ['ÉTICA','interns','fa-user-graduate','Estagiários'],
        ['CONSULTAS','reports','fa-file-lines','Relatórios de RH']
      ]
    }
  };

  // ===== Sistema de permissões (simulado no front-end) =====
  const PERMISSION_MODULES = ['alunos','responsaveis','professores','funcionarios','turmas','matriculas','diario','frequencia','notas','boletim','coordenacao','ocorrencias','documentos','protocolos','biblioteca','transporte','alimentacao','estoque','patrimonio','saude','aee','rh','vagas','financeiro','comunicados','calendario','relatorios','censo','auditoria','permissoes','estrutura'];
  const PAGE_MODULE_MAP = {
    schools:'estrutura', spaces:'patrimonio', assets:'patrimonio',
    teachers:'professores', students:'alunos', users:'permissoes', permissions:'permissoes',
    classes:'turmas', curriculum:'turmas', schedule:'turmas',
    calendar:'calendario', academicPeriods:'calendario',
    reports:'relatorios', documents:'documentos', studentDocuments:'documentos', documentIssuances:'documentos',
    certificates:'documentos', occurrences:'ocorrencias', grades:'boletim', content:'diario', lessonPlans:'diario',
    jobs:'vagas', candidates:'rh', employees:'rh', payroll:'rh', substitutes:'rh', benefits:'rh', leaves:'rh', terminations:'rh',
    trainings:'rh', evaluations:'rh', careerPlans:'rh', climateSurveys:'rh', wellbeing:'rh', safety:'rh', unions:'rh', lgpd:'rh', ethicsCases:'rh', interns:'rh',
    announcements:'comunicados', serviceRequests:'protocolos', appointments:'protocolos', queueTickets:'protocolos', contactLogs:'protocolos',
    enrollmentRequests:'matriculas', library:'biblioteca', transportRoutes:'transporte', meals:'alimentacao',
    healthRecords:'saude', aeeRecords:'aee', financeRecords:'financeiro', publicFunds:'financeiro', publicExpenses:'financeiro', auditLog:'auditoria', inventory:'estoque',
    transportVehicles:'transporte', transportDrivers:'transporte', classCouncils:'coordenacao', atRisk:'coordenacao', census:'censo', globalSearch:'relatorios',
    guardians:'responsaveis', assignments:'professores', diaryBook:'diario', attendance:'frequencia', gradebook:'notas', reportCard:'boletim'
  };
  const FULL_ACCESS={view:true,create:true,edit:true,delete:true,approve:true,export:true};
  const VIEW_ONLY={view:true,create:false,edit:false,delete:false,approve:false,export:false};
  const NO_ACCESS={view:false,create:false,edit:false,delete:false,approve:false,export:false};
  function seedDefaultPermissions(){
    const matrix={};
    const allFull=()=>Object.fromEntries(PERMISSION_MODULES.map(m=>[m,{...FULL_ACCESS}]));
    matrix.direcao=allFull();
    matrix.secretaria_gestao=Object.fromEntries(PERMISSION_MODULES.map(m=>[m,{...NO_ACCESS}]));
    Object.assign(matrix.secretaria_gestao,{alunos:{...FULL_ACCESS,delete:false},responsaveis:{...FULL_ACCESS,delete:false},professores:{...FULL_ACCESS,delete:false},turmas:{...FULL_ACCESS,delete:false},matriculas:{...FULL_ACCESS,delete:false},documentos:{...FULL_ACCESS,delete:false},boletim:{...VIEW_ONLY,export:true},diario:VIEW_ONLY,frequencia:{...VIEW_ONLY,export:true},notas:{...VIEW_ONLY,export:true},ocorrencias:VIEW_ONLY,calendario:{...FULL_ACCESS,delete:false},relatorios:{...VIEW_ONLY,export:true},comunicados:{view:true,create:true,edit:true,delete:false,approve:false,export:false},estrutura:VIEW_ONLY,coordenacao:{...FULL_ACCESS,delete:false},censo:{...VIEW_ONLY,export:true}});
    matrix.secretaria_atendimento=Object.fromEntries(PERMISSION_MODULES.map(m=>[m,{...NO_ACCESS}]));
    Object.assign(matrix.secretaria_atendimento,{alunos:VIEW_ONLY,responsaveis:VIEW_ONLY,protocolos:{...FULL_ACCESS,delete:false},documentos:{...FULL_ACCESS,delete:false},comunicados:{view:true,create:true,edit:false,delete:false,approve:false,export:false},calendario:VIEW_ONLY,matriculas:VIEW_ONLY,relatorios:VIEW_ONLY});
    matrix.rh=Object.fromEntries(PERMISSION_MODULES.map(m=>[m,{...NO_ACCESS}]));
    Object.assign(matrix.rh,{rh:{...FULL_ACCESS,delete:false},vagas:{view:true,create:true,edit:true,delete:false,approve:false,export:true},funcionarios:VIEW_ONLY,relatorios:{...VIEW_ONLY,export:true}});
    matrix.professor=Object.fromEntries(PERMISSION_MODULES.map(m=>[m,{...NO_ACCESS}]));
    Object.assign(matrix.professor,{turmas:VIEW_ONLY,alunos:VIEW_ONLY,diario:{view:true,create:true,edit:true,delete:false,approve:false,export:false},frequencia:{view:true,create:true,edit:true,delete:false,approve:false,export:false},notas:{view:true,create:true,edit:true,delete:false,approve:false,export:false},boletim:VIEW_ONLY,ocorrencias:{view:true,create:true,edit:true,delete:false,approve:false,export:false},calendario:VIEW_ONLY,comunicados:VIEW_ONLY});
    matrix.aluno=Object.fromEntries(PERMISSION_MODULES.map(m=>[m,{...NO_ACCESS}]));
    Object.assign(matrix.aluno,{boletim:VIEW_ONLY,frequencia:VIEW_ONLY,calendario:VIEW_ONLY,documentos:VIEW_ONLY,protocolos:{view:true,create:true,edit:false,delete:false,approve:false,export:false},comunicados:VIEW_ONLY});
    matrix.responsavel=Object.fromEntries(PERMISSION_MODULES.map(m=>[m,{...NO_ACCESS}]));
    Object.assign(matrix.responsavel,{boletim:VIEW_ONLY,frequencia:VIEW_ONLY,ocorrencias:VIEW_ONLY,calendario:VIEW_ONLY,documentos:VIEW_ONLY,financeiro:VIEW_ONLY,protocolos:{view:true,create:true,edit:false,delete:false,approve:false,export:false},comunicados:VIEW_ONLY});
    return matrix;
  }
  function can(module,action){
    if(!module)return true;
    const roleMatrix=state.permissions?.[state.role];
    if(!roleMatrix)return state.role==='direcao';
    const modulePerms=roleMatrix[module];
    if(!modulePerms)return false;
    return !!modulePerms[action];
  }
  function denyToast(action){
    const labels={view:'visualizar',create:'criar',edit:'editar',delete:'excluir',approve:'aprovar',export:'exportar'};
    showToast(`Seu perfil não tem permissão para ${labels[action]||'realizar'} esta ação.`);
  }
  function currentUser(){ return (state.mockUsers||[]).find(u=>u.id===state.currentUserId) || null; }

  const curriculumTemplates = {
    '1º ano do Ensino Fundamental': [
      ['Língua Portuguesa',200,5],['Matemática',200,5],['Ciências',80,2],['História',80,2],['Geografia',80,2],['Arte',40,1],['Educação Física',80,2]
    ],
    '5º ano do Ensino Fundamental': [
      ['Língua Portuguesa',200,5],['Matemática',200,5],['Ciências',80,2],['História',80,2],['Geografia',80,2],['Arte',40,1],['Educação Física',80,2],['Ensino Religioso',40,1]
    ],
    '1º ano do Ensino Médio': [
      ['Língua Portuguesa',120,3],['Matemática',120,3],['Biologia',80,2],['Física',80,2],['Química',80,2],['História',80,2],['Geografia',80,2],['Filosofia',40,1],['Sociologia',40,1],['Língua Inglesa',80,2],['Educação Física',40,1]
    ],
    '2º ano do Ensino Médio': [
      ['Língua Portuguesa',120,3],['Matemática',120,3],['Biologia',80,2],['Física',80,2],['Química',80,2],['História',80,2],['Geografia',80,2],['Filosofia',40,1],['Sociologia',40,1],['Língua Inglesa',80,2],['Educação Física',40,1]
    ],
    '3º ano do Ensino Médio': [
      ['Língua Portuguesa',120,3],['Matemática',120,3],['Biologia',80,2],['Física',80,2],['Química',80,2],['História',80,2],['Geografia',80,2],['Filosofia',40,1],['Sociologia',40,1],['Língua Inglesa',80,2],['Educação Física',40,1]
    ]
  };

  const timeSlots = [
    ['1º','07:00','07:50'],['2º','07:50','08:40'],['3º','08:40','09:30'],['4º','09:50','10:40'],['5º','10:40','11:30'],['6º','11:30','12:20']
  ];
  const weekdays = ['Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira'];

  const loginForm = document.getElementById('loginForm');
  const loginScreen = document.getElementById('loginScreen');
  const app = document.getElementById('app');
  const sideMenu = document.getElementById('sideMenu');
  const content = document.getElementById('content');

  const ROLE_ICON={direcao:'fa-user-tie',secretaria_gestao:'fa-building-columns',secretaria_atendimento:'fa-headset',rh:'fa-people-arrows',professor:'fa-chalkboard-user',aluno:'fa-user-graduate',responsavel:'fa-house-user'};
  const ROLE_LOGIN_LABEL={direcao:'Diretor(a)',secretaria_gestao:'Secretário(a) Escolar',secretaria_atendimento:'Atendente da Secretaria',rh:'Recursos Humanos',professor:'Professor(a)',aluno:'Aluno(a)',responsavel:'Responsável'};
  function renderAccountCards(){
    const container=document.getElementById('roleCards');
    if(!container)return;
    const accounts=(state.mockUsers||[]);
    container.innerHTML=accounts.map(acc=>`<button type="button" class="role-card" data-account="${acc.id}"><span class="role-card-icon"><i class="fa-solid ${ROLE_ICON[acc.role]||'fa-user'}"></i></span><span><strong>${escapeHtml(ROLE_LOGIN_LABEL[acc.role]||roles[acc.role]?.name||acc.role)}</strong><small>${escapeHtml(acc.vinculoLabel||roles[acc.role]?.name||'')}<br>${escapeHtml(acc.email)} · senha: ${escapeHtml(acc.password)}</small></span></button>`).join('');
    container.querySelectorAll('.role-card').forEach(card=>card.addEventListener('click',()=>{
      container.querySelectorAll('.role-card').forEach(x=>x.classList.remove('selected'));
      card.classList.add('selected');
      const acc=accounts.find(a=>a.id===card.dataset.account);
      if(acc){ document.getElementById('loginUser').value=acc.email; document.getElementById('loginPassword').value=acc.password; document.getElementById('loginAccountId').value=acc.id; hideLoginError(); }
    }));
  }
  function hideLoginError(){ document.getElementById('loginError')?.classList.add('hidden'); }
  function showLoginError(msg){ const el=document.getElementById('loginError'); if(el){ el.querySelector('span').textContent=msg; el.classList.remove('hidden'); } }

  if (!roles[state.role]) {
    state.role = null;
    state.user = null;
    state.currentUserId = null;
    save();
  }

  loginForm.addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('loginUser').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;
    const account = (state.mockUsers||[]).find(u=>u.email.toLowerCase()===email && u.password===password);
    if(!account){ showLoginError('E-mail ou senha inválidos. Selecione uma das contas de demonstração abaixo.'); return; }
    if(account.status!=='Ativo'){ showLoginError(`Esta conta está com status "${account.status}" e não pode acessar o sistema.`); return; }
    hideLoginError();
    state.user = account.name; state.role = account.role; state.currentUserId = account.id; state.currentSchoolId = account.schoolId;
    logAudit('Login','Acesso',`${account.name} entrou no sistema (${roles[account.role]?.name||account.role}).`);
    save();
    loginScreen.classList.add('hidden'); app.classList.remove('hidden');
    updateUser(); buildMenu(); navigate('dashboard'); wireTopbar(); updateNotifBadge();
  });

  document.getElementById('publicSchoolButton')?.addEventListener('click', () => openPublicSchoolRegistration());
  document.getElementById('schoolRegBack')?.addEventListener('click', () => {
    document.getElementById('schoolRegScreen').classList.add('hidden');
    loginScreen.classList.remove('hidden');
  });

  document.getElementById('logoutButton')?.addEventListener('click', () => {
    const acc=currentUser();
    if(acc) logAudit('Login','Encerramento de sessão',`${acc.name} saiu do sistema.`);
    save();
    app.classList.add('hidden'); loginScreen.classList.remove('hidden');
    document.getElementById('loginPassword').value = '';
    document.getElementById('loginAccountId').value='';
    document.querySelectorAll('.role-card').forEach(x=>x.classList.remove('selected'));
  });
  document.getElementById('modalClose')?.addEventListener('click', closeModal);
  document.getElementById('closeSidebar')?.addEventListener('click', () => document.getElementById('sidebar')?.classList.remove('open'));
  document.getElementById('menuToggle')?.addEventListener('click', () => document.getElementById('sidebar')?.classList.toggle('open'));

  function updateUser() {
    const cfg = roles[state.role] || roles.direcao;
    const acc = currentUser();
    document.getElementById('sidebarUser').textContent = state.user;
    document.getElementById('topUserName').textContent = state.user;
    document.getElementById('sidebarRole').textContent = acc?.vinculoLabel ? `${cfg.name} · ${acc.vinculoLabel}` : cfg.name;
    document.getElementById('sidebarSector').textContent = cfg.sector;
  }

  function buildMenu() {
    const cfg = roles[state.role] || roles.direcao;
    sideMenu.innerHTML = '';
    let group = '';
    cfg.menu.forEach(([category,page,icon,title]) => {
      const moduleKey=PAGE_MODULE_MAP[page];
      if(moduleKey && !can(moduleKey,'view')) return;
      if (category !== group) { group = category; const label=document.createElement('div'); label.className='menu-label'; label.textContent=category; sideMenu.appendChild(label); }
      const btn=document.createElement('button'); btn.className='menu-item'; btn.dataset.page=page; btn.innerHTML=`<i class="fa-solid ${icon}"></i><span>${title}</span>`; btn.onclick=()=>navigate(page); sideMenu.appendChild(btn);
    });
  }

  function navigate(page) {
    document.querySelectorAll('.menu-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
    const cfg=roles[state.role]||roles.direcao;
    const item=cfg.menu.find(x=>x[1]===page);
    document.getElementById('pageTitle').textContent=item?.[3]||'SIGED';
    document.getElementById('breadcrumb').textContent=`SIGED / ${cfg.sector} / ${item?.[3]||'Painel'}`;
    const renderers={dashboard:renderDashboard,schools:renderSchools,classes:renderClasses,curriculum:renderCurriculum,calendar:renderCalendar,teachers:renderTeachers,students:renderStudents,guardians:renderGuardians,assignments:renderAssignments,diaryBook:renderDiaryBook,attendance:renderAttendance,gradebook:renderGradebook,reportCard:renderReportCard,users:renderUsers,reports:renderReports,documents:renderDocuments,certificates:renderCertificates,occurrences:renderOccurrences,grades:renderGrades,schedule:renderSchedule,content:renderContent,jobs:renderJobs,candidates:renderCandidates,employees:renderEmployees,payroll:renderPayroll,
      substitutes:()=>renderCrud(crudModules.substitutes),benefits:()=>renderCrud(crudModules.benefits),leaves:()=>renderCrud(crudModules.leaves),terminations:()=>renderCrud(crudModules.terminations),
      trainings:()=>renderCrud(crudModules.trainings),evaluations:()=>renderCrud(crudModules.evaluations),careerPlans:()=>renderCrud(crudModules.careerPlans),
      climateSurveys:()=>renderCrud(crudModules.climateSurveys),wellbeing:()=>renderCrud(crudModules.wellbeing),
      safety:()=>renderCrud(crudModules.safety),unions:()=>renderCrud(crudModules.unions),lgpd:()=>renderCrud(crudModules.lgpd),
      ethicsCases:()=>renderCrud(crudModules.ethicsCases),interns:()=>renderCrud(crudModules.interns),
      aeeRecords:()=>renderCrud(crudModules.aeeRecords),inventory:()=>renderCrud(crudModules.inventory),
      transportVehicles:()=>renderCrud(crudModules.transportVehicles),transportDrivers:()=>renderCrud(crudModules.transportDrivers),
      classCouncils:()=>renderCrud(crudModules.classCouncils),publicFunds:()=>renderCrud(crudModules.publicFunds),publicExpenses:()=>renderCrud(crudModules.publicExpenses),
      atRisk:renderAtRisk,census:renderCensus,globalSearch:renderGlobalSearch,
      academicPeriods:()=>renderCrud(crudModules.academicPeriods),enrollmentRequests:()=>renderCrud(crudModules.enrollmentRequests),
      spaces:()=>renderCrud(crudModules.spaces),assets:()=>renderCrud(crudModules.assets),library:()=>renderCrud(crudModules.library),
      transportRoutes:()=>renderCrud(crudModules.transportRoutes),meals:()=>renderCrud(crudModules.meals),healthRecords:()=>renderCrud(crudModules.healthRecords),
      financeRecords:()=>renderCrud(crudModules.financeRecords),studentDocuments:()=>renderCrud(crudModules.studentDocuments),
      contactLogs:()=>renderCrud(crudModules.contactLogs),lessonPlans:()=>renderCrud(crudModules.lessonPlans),
      announcements:()=>renderCrud(crudModules.announcements),appointments:()=>renderCrud(crudModules.appointments),
      serviceRequests:()=>renderCrud(crudModules.serviceRequests),documentIssuances:()=>renderCrud(crudModules.documentIssuances),
      auditLog:renderAuditLog,permissions:renderPermissions,queueTickets:renderQueue,settings:renderSettings};
    (renderers[page]||(()=>renderGeneric(page,item?.[3]||page)))();
  }

  function pageHeader(title,desc,actions='') { return `<div class="page-header"><div><h2>${title}</h2><p>${desc}</p></div><div class="page-actions">${actions}</div></div>`; }
  function statCard(title,value,icon){ return `<div class="stat-card"><div class="stat-icon"><i class="fa-solid ${icon}"></i></div><div><span>${title}</span><strong>${value}</strong></div></div>`; }
  function schoolForCurrent() { return state.schools.find(s=>s.id===state.currentSchoolId) || state.schools[0]; }
  function schoolOptions(selected='') { return state.schools.map(s=>`<option value="${s.id}" ${s.id===selected?'selected':''}>${escapeHtml(s.name)}</option>`).join(''); }
  function escapeHtml(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

  function renderDashboard() {
    const school=schoolForCurrent();
    const scopedClasses=school?state.classes.filter(c=>c.schoolId===school.id):[];
    const scopedStudents=school?state.students.filter(s=>s.schoolId===school.id):[];
    const scopedTeachers=school?state.teachers.filter(t=>t.schoolId===school.id):[];
    const byS=arr=>(state[arr]||[]).filter(x=>x.schoolId===school?.id);
    const cfg=roles[state.role]||roles.direcao;

    if(state.role==='secretaria_atendimento'){
      const certs=(state.certificates||[]).filter(c=>c.schoolId===school?.id);
      const openRequests=byS('serviceRequests').filter(r=>r.status!=='Concluída'&&r.status!=='Cancelada');
      const todayAppointments=byS('appointments').filter(a=>a.date===new Date().toISOString().slice(0,10));
      content.innerHTML=`${pageHeader('Atendimento de hoje', 'Painel operacional para resolver solicitações no balcão com rapidez.', '<button class="btn-primary" id="quickService"><i class="fa-solid fa-plus"></i> Nova solicitação</button>')}
        <div class="welcome-banner"><div><span class="eyebrow">${escapeHtml(cfg.name)}</span><h2>${escapeHtml(school?.name||'Sua escola')}</h2><p>Consulte o aluno, resolva a solicitação e registre tudo no histórico.</p></div><div class="welcome-actions"><button class="quick-action" data-page="students"><i class="fa-solid fa-magnifying-glass"></i><span>Buscar aluno</span></button><button class="quick-action" data-page="serviceRequests"><i class="fa-solid fa-file-circle-plus"></i><span>Nova solicitação</span></button><button class="quick-action" data-page="queueTickets"><i class="fa-solid fa-list-ol"></i><span>Fila de atendimento</span></button></div></div>
        <div class="stat-grid">${statCard('Alunos cadastrados',scopedStudents.length,'fa-user-graduate')}${statCard('Solicitações em aberto',openRequests.length,'fa-ticket')}${statCard('Agendamentos hoje',todayAppointments.length,'fa-calendar-check')}${statCard('Atestados registrados',certs.length,'fa-file-medical')}</div>
        <div class="dashboard-grid"><div class="card"><div class="card-title"><div><h3>Fluxo de atendimento</h3><span>Operação da secretaria</span></div></div><div class="process-list"><div><b>1</b><span>Identificar aluno e responsável</span><i class="fa-solid fa-chevron-right"></i></div><div><b>2</b><span>Abrir protocolo da solicitação</span><i class="fa-solid fa-chevron-right"></i></div><div><b>3</b><span>Anexar ou emitir documento</span><i class="fa-solid fa-chevron-right"></i></div><div><b>4</b><span>Concluir e encerrar o protocolo</span><i class="fa-solid fa-check"></i></div></div></div>
        <div class="card"><div class="card-title"><div><h3>Atalhos</h3><span>Módulos do dia a dia</span></div></div><div class="quick-grid" style="grid-template-columns:1fr"><button class="module-card action-card" data-page="serviceRequests"><div class="module-icon"><i class="fa-solid fa-ticket"></i></div><h3>Solicitações e protocolos</h3><p>Abra, acompanhe e conclua protocolos da comunidade escolar.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="documentIssuances"><div class="module-icon"><i class="fa-solid fa-file-export"></i></div><h3>Emissão rápida de documentos</h3><p>Gere e imprima declarações, boletins e históricos.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="appointments"><div class="module-icon"><i class="fa-solid fa-calendar-check"></i></div><h3>Agendamentos</h3><p>Marque atendimentos com secretaria, direção ou coordenação.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button></div></div></div>`;
      document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>navigate(b.dataset.page));
      document.getElementById('quickService')?.addEventListener('click',()=>openCrudEditor(crudModules.serviceRequests));
      return;
    }

    if(state.role==='secretaria_gestao'){
      const today=new Date(); const year=today.getFullYear();
      const pendingEnrollments=byS('enrollmentRequests').filter(r=>r.status==='Em análise'||r.status==='Pendente de documentos').length;
      content.innerHTML=`${pageHeader('Painel operacional', 'Tudo que a secretaria precisa para organizar o ano letivo e a vida acadêmica.', '<button class="btn-primary" id="quickClass"><i class="fa-solid fa-plus"></i> Criar turma</button>')}
        <div class="welcome-banner"><div><span class="eyebrow">Secretaria • Gestão Escolar</span><h2>${escapeHtml(school?.name||'Sua escola')}</h2><p>Organize estrutura, pessoas, horários e calendários em um único fluxo.</p></div><div class="welcome-metric"><strong>${year}</strong><span>Ano letivo atual</span></div></div>
        <div class="stat-grid">${statCard('Turmas',scopedClasses.length,'fa-people-roof')}${statCard('Alunos',scopedStudents.length,'fa-user-graduate')}${statCard('Professores',scopedTeachers.length,'fa-chalkboard-user')}${statCard('Matrículas/transferências pendentes',pendingEnrollments,'fa-user-pen')}</div>
        <div class="quick-grid"><button class="module-card action-card" data-page="classes"><div class="module-icon"><i class="fa-solid fa-people-roof"></i></div><h3>Montar turmas</h3><p>Crie a turma e carregue a matriz curricular automaticamente.</p><span>Gerenciar <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="schedule"><div class="module-icon"><i class="fa-solid fa-clock"></i></div><h3>Organizar horários</h3><p>Confira a grade semanal gerada e faça ajustes antes de publicar.</p><span>Ver grade <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="enrollmentRequests"><div class="module-icon"><i class="fa-solid fa-user-pen"></i></div><h3>Matrículas e transferências</h3><p>Acompanhe matrícula inicial, rematrícula, trancamentos e mais.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="academicPeriods"><div class="module-icon"><i class="fa-solid fa-calendar-check"></i></div><h3>Ano letivo</h3><p>Abra e encerre bimestres, trimestres e o ano letivo.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button></div>`;
      document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>navigate(b.dataset.page));
      document.getElementById('quickClass')?.addEventListener('click',()=>openClassEditor());
      return;
    }

    if(state.role==='professor'){
      const asg=assignmentsForCurrentUser();
      const classIds=[...new Set(asg.map(a=>a.classId))];
      const myStudents=classIds.reduce((n,id)=>n+studentsOfClass(id).length,0);
      const per='3º Bimestre';
      const pendingGrades=asg.reduce((n,a)=>n+studentsOfClass(a.classId).filter(st=>{const g=findGrade(a.classId,a.subject,per,st.id);return !g||g.av1===null;}).length,0);
      const noLessonToday=asg.filter(a=>!(state.lessonRecords||[]).some(r=>r.classId===a.classId&&r.subject===a.subject&&r.date===todayIso())).length;
      const lowAtt=classIds.reduce((n,id)=>n+studentsOfClass(id).filter(st=>{const x=attendanceStats(st.id,id,null);return x.pct!==null&&x.pct<MIN_ATTENDANCE;}).length,0);
      content.innerHTML=`${pageHeader('Painel do Professor','Suas turmas, diário, notas e frequência.','<button class="btn-primary" id="quickDiary"><i class="fa-solid fa-plus"></i> Registrar aula</button>')}
        <div class="welcome-banner"><div><span class="eyebrow">Portal do Professor</span><h2>${escapeHtml(state.user||'')}</h2><p>${escapeHtml(school?.name||'')} — você vê somente as turmas e disciplinas atribuídas a você.</p></div></div>
        ${lowAtt?`<div class="alert alert-danger" role="alert"><i class="fa-solid fa-triangle-exclamation"></i> <div><strong>${lowAtt} aluno(s)</strong> das suas turmas estão com frequência abaixo de ${MIN_ATTENDANCE}%.</div></div>`:''}${noLessonToday?`<div class="alert alert-info"><i class="fa-solid fa-circle-info"></i> <div>${noLessonToday} turma(s)/disciplina(s) ainda sem chamada registrada hoje.</div></div>`:''}
        <div class="stat-grid">${statCard('Minhas turmas',classIds.length,'fa-people-roof')}${statCard('Minhas disciplinas',asg.length,'fa-book')}${statCard('Alunos atendidos',myStudents,'fa-user-graduate')}${statCard('Notas pendentes (3º bim.)',pendingGrades,'fa-marker')}</div>
        <div class="card"><div class="card-title"><div><h3>Minhas turmas e disciplinas</h3></div></div>${asg.length?`<div class="table-wrap"><table><thead><tr><th>Turma</th><th>Disciplina</th><th>Aulas/sem</th><th>Última aula</th></tr></thead><tbody>${asg.map(a=>{const last=(state.lessonRecords||[]).filter(r=>r.classId===a.classId&&r.subject===a.subject).map(r=>r.date).sort().pop();return `<tr><td>${escapeHtml(classLabel(classById(a.classId)))}</td><td>${escapeHtml(a.subject)}</td><td>${a.weeklyClasses}</td><td>${last?formatDate(last):'—'}</td></tr>`;}).join('')}</tbody></table></div>`:'<div class="empty-state">Nenhuma atribuição. Fale com a Secretaria.</div>'}</div>
        <div class="quick-grid"><button class="module-card action-card" data-page="attendance"><div class="module-icon"><i class="fa-solid fa-clipboard-check"></i></div><h3>Registrar frequência</h3><p>Chamada por turma e disciplina.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="gradebook"><div class="module-icon"><i class="fa-solid fa-marker"></i></div><h3>Lançar notas</h3><p>Avaliações, média e situação automáticas.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="diaryBook"><div class="module-icon"><i class="fa-solid fa-book-journal-whills"></i></div><h3>Registrar diário</h3><p>Conteúdo ministrado e chamada da aula.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="lessonPlans"><div class="module-icon"><i class="fa-solid fa-list-check"></i></div><h3>Planejar aula</h3><p>Objetivos, metodologia e recursos.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button></div>`;
      document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>navigate(b.dataset.page));
      document.getElementById('quickDiary')?.addEventListener('click',()=>navigate('diaryBook'));
      return;
    }

    if(state.role==='aluno'||state.role==='responsavel'){
      const kid=selectedChild();
      const isGuardian=state.role==='responsavel';
      const title=isGuardian?'Painel do Responsável':'Painel do Aluno';
      if(!kid){content.innerHTML=`${pageHeader(title,'')}<div class="empty-state">Nenhum aluno vinculado a esta conta.</div>`;return;}
      const o=studentOverall(kid);
      const lowAtt=o.att.pct!==null&&o.att.pct<MIN_ATTENDANCE;
      const risk=riskReasons(kid);
      const notes=(state.notifications||[]).filter(n=>n.schoolId===school?.id&&(n.studentId===kid.id||!n.studentId)).slice(0,5);
      const openReq=byS('serviceRequests').filter(r=>r.createdBy===state.currentUserId&&r.status!=='Concluída'&&r.status!=='Cancelada').length;
      const pendingFin=isGuardian?byS('financeRecords').filter(f=>f.studentId===kid.id&&(f.status==='Em aberto'||f.status==='Atrasado')).length:0;
      const upcoming=(state.lessonRecords||[]).filter(r=>r.classId===kid.classId&&(r.attendance||[]).some(x=>x.studentId===kid.id&&x.status==='Falta')).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,3);
      content.innerHTML=`${pageHeader(title,isGuardian?'Acompanhamento escolar dos seus filhos.':'Sua vida escolar em um só lugar.','<button class="btn-primary" id="quickRequest"><i class="fa-solid fa-plus"></i> Nova solicitação</button>')}${childSwitcherHtml()}
        <div class="welcome-banner"><div><span class="eyebrow">${isGuardian?'Portal do Responsável':'Portal do Aluno'}</span><h2>${escapeHtml(kid.name)}</h2><p>${escapeHtml(classLabel(classById(kid.classId)))} · Matrícula ${escapeHtml(kid.registration||'—')}</p></div></div>
        ${lowAtt?`<div class="alert alert-danger" role="alert"><i class="fa-solid fa-triangle-exclamation"></i> <div><strong>${escapeHtml(kid.name.split(' ')[0])} possui frequência abaixo do esperado:</strong> ${String(o.att.pct).replace('.',',')}% (mínimo ${MIN_ATTENDANCE}%).</div></div>`:''}${risk.length&&!lowAtt?`<div class="alert alert-info"><i class="fa-solid fa-circle-info"></i> <div>Acompanhamento pedagógico: ${escapeHtml(risk.join(' · '))}.</div></div>`:''}
        <div class="stat-grid">${statCard('Média geral',fmtNum(o.media),'fa-star-half-stroke')}${statCard('Frequência',o.att.pct===null?'—':String(o.att.pct).replace('.',',')+'%','fa-clipboard-check')}${statCard('Faltas',o.att.fal,'fa-user-xmark')}${statCard(isGuardian?'Pendências financeiras':'Solicitações abertas',isGuardian?pendingFin:openReq,isGuardian?'fa-sack-dollar':'fa-ticket')}</div>
        <div class="dashboard-grid"><div class="card"><div class="card-title"><div><h3>Notificações</h3><span>Últimas atualizações</span></div></div>${notes.length?`<ul class="plain-list">${notes.map(n=>`<li><i class="fa-solid fa-bell"></i> ${escapeHtml(n.text)} <small class="muted">${new Date(n.date).toLocaleDateString('pt-BR')}</small></li>`).join('')}</ul>`:'<div class="empty-state">Sem notificações.</div>'}</div>
        <div class="card"><div class="card-title"><div><h3>Faltas recentes</h3></div></div>${upcoming.length?`<ul class="plain-list">${upcoming.map(r=>`<li>${formatDate(r.date)} — ${escapeHtml(r.subject)}</li>`).join('')}</ul>`:'<div class="empty-state">Nenhuma falta recente.</div>'}</div></div>
        <div class="quick-grid"><button class="module-card action-card" data-page="reportCard"><div class="module-icon"><i class="fa-solid fa-file-lines"></i></div><h3>Boletim</h3><p>Notas por bimestre, frequência e resultado.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="attendance"><div class="module-icon"><i class="fa-solid fa-clipboard-check"></i></div><h3>Frequência</h3><p>Presenças e faltas por disciplina.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="serviceRequests"><div class="module-icon"><i class="fa-solid fa-ticket"></i></div><h3>Solicitações</h3><p>Peça declarações, histórico e outros documentos.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button></div>`;
      document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>navigate(b.dataset.page));
      document.getElementById('quickRequest')?.addEventListener('click',()=>openCrudEditor(crudModules.serviceRequests));
      bindChildSwitcher(renderDashboard);
      return;
    }

    if(state.role==='rh'){
      const jobs=(state.jobs||[]).filter(j=>j.schoolId===school?.id);
      const cands=(state.candidates||[]).filter(c=>c.schoolId===school?.id);
      const emps=(state.employees||[]).filter(e=>e.schoolId===school?.id);
      const openJobs=jobs.filter(j=>j.status==='Aberta').length;
      const inProcess=cands.filter(c=>c.status==='Triagem'||c.status==='Entrevista').length;
      const pendingAccess=emps.filter(e=>e.status==='Aguardando Financeiro'||e.status==='Aguardando Liberação de Acesso').length;
      const activeLeaves=(state.leaves||[]).filter(l=>l.schoolId===school?.id&&l.status==='Em andamento').length;
      const openEthics=(state.ethicsCases||[]).filter(c=>c.schoolId===school?.id&&c.status==='Em apuração').length;
      const availableSubs=(state.substitutes||[]).filter(s=>s.schoolId===school?.id&&s.status==='Disponível').length;
      content.innerHTML=`${pageHeader('Painel de RH','Do pedido de contratação ao desligamento: recrutamento, departamento pessoal, desenvolvimento, clima, compliance e ética.','<button class="btn-primary" id="quickJob"><i class="fa-solid fa-plus"></i> Nova vaga</button>')}
        <div class="welcome-banner"><div><span class="eyebrow">Recursos Humanos</span><h2>${escapeHtml(school?.name||'Sua escola')}</h2><p>Publique vagas, avalie candidatos, contrate, gerencie o departamento pessoal e acompanhe clima, compliance e ética.</p></div></div>
        <div class="stat-grid">${statCard('Vagas abertas',openJobs,'fa-bullhorn')}${statCard('Candidatos em processo',inProcess,'fa-user-check')}${statCard('Funcionários ativos',emps.filter(e=>e.status==='Ativo').length,'fa-id-card')}${statCard('Aguardando acesso',pendingAccess,'fa-key')}</div>
        <div class="stat-grid">${statCard('Afastamentos ativos',activeLeaves,'fa-bed-pulse')}${statCard('Substitutos disponíveis',availableSubs,'fa-user-clock')}${statCard('Apurações em aberto (Ouvidoria)',openEthics,'fa-user-secret')}${statCard('Funcionários totais',emps.length,'fa-users')}</div>
        <div class="dashboard-grid"><div class="card"><div class="card-title"><div><h3>Fluxo de contratação</h3><span>Do RH ao primeiro acesso</span></div></div><div class="process-list"><div><b>1</b><span>Abrir vaga e triar candidatos</span><i class="fa-solid fa-chevron-right"></i></div><div><b>2</b><span>Aprovar e coletar documentos</span><i class="fa-solid fa-chevron-right"></i></div><div><b>3</b><span>Contratar e enviar ao Financeiro</span><i class="fa-solid fa-chevron-right"></i></div><div><b>4</b><span>Liberar acesso ao sistema</span><i class="fa-solid fa-check"></i></div></div></div>
        <div class="card"><div class="card-title"><div><h3>Atalhos</h3><span>Etapas do processo</span></div></div><div class="quick-grid" style="grid-template-columns:1fr"><button class="module-card action-card" data-page="candidates"><div class="module-icon"><i class="fa-solid fa-user-check"></i></div><h3>Avaliar candidatos</h3><p>Mova pelo funil: triagem, entrevista, aprovado.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="employees"><div class="module-icon"><i class="fa-solid fa-id-card"></i></div><h3>Funcionários e acesso</h3><p>Contratos ativos, afastamentos e rescisões.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="evaluations"><div class="module-icon"><i class="fa-solid fa-star-half-stroke"></i></div><h3>Desempenho e carreira</h3><p>Avaliação 360°, PDI e plano de carreira (PCCS).</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button><button class="module-card action-card" data-page="climateSurveys"><div class="module-icon"><i class="fa-solid fa-face-smile"></i></div><h3>Clima e bem-estar</h3><p>Pesquisas de clima e combate ao burnout.</p><span>Abrir <i class="fa-solid fa-arrow-right"></i></span></button></div></div></div>`;
      document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>navigate(b.dataset.page));
      document.getElementById('quickJob')?.addEventListener('click',()=>openJobEditor());
      return;
    }

    content.innerHTML=`${pageHeader('Visão geral da escola','Indicadores institucionais para acompanhamento da direção e apoio à decisão.')}
      <div class="welcome-banner executive"><div><span class="eyebrow">Direção Escolar</span><h2>${escapeHtml(school?.name||'Sua escola')}</h2><p>Uma visão consolidada da operação: pessoas, estrutura, pedagógico, financeiro e comunicação.</p></div><div class="executive-status"><span class="status-dot"></span><strong>Ambiente ativo</strong><small>Dados desta escola</small></div></div>
      <div class="stat-grid">${statCard('Alunos ativos',scopedStudents.length,'fa-user-graduate')}${statCard('Turmas em andamento',scopedClasses.length,'fa-people-roof')}${statCard('Professores ativos',scopedTeachers.length,'fa-chalkboard-user')}${statCard('Funcionários ativos',byS('employees').filter(e=>e.status==='Ativo').length,'fa-id-card')}</div>
      <div class="stat-grid">${statCard('Vagas aguardando aprovação',byS('jobs').filter(j=>j.status==='Aguardando aprovação').length,'fa-bullhorn')}${statCard('Contratações aguardando Financeiro/TI',byS('employees').filter(e=>e.status==='Aguardando Financeiro'||e.status==='Aguardando Liberação de Acesso').length,'fa-user-clock')}${statCard('Matrículas/transferências em análise',byS('enrollmentRequests').filter(r=>r.status==='Em análise'||r.status==='Pendente de documentos').length,'fa-user-pen')}${statCard('Solicitações abertas (Atendimento)',byS('serviceRequests').filter(r=>r.status!=='Concluída'&&r.status!=='Cancelada').length,'fa-ticket')}</div>
      <div class="stat-grid">${statCard('Pendências de RH',byS('leaves').filter(l=>l.status==='Em andamento').length+byS('ethicsCases').filter(c=>c.status==='Em apuração').length,'fa-triangle-exclamation')}${statCard('Comunicados recentes',byS('announcements').length,'fa-bullhorn')}${statCard('Lançamentos financeiros em aberto',byS('financeRecords').filter(f=>f.status==='Em aberto'||f.status==='Atrasado').length,'fa-sack-dollar')}${statCard('Eventos no calendário',state.calendars.filter(c=>c.schoolId===school?.id).reduce((a,c)=>a+c.events.length,0),'fa-calendar-check')}</div>
      <div class="dashboard-grid"><div class="card"><div class="card-title"><div><h3>Acompanhamento</h3><span>O que merece atenção</span></div></div><div class="attention-list"><div><span class="attention-icon warning"><i class="fa-solid fa-bullhorn"></i></span><div><strong>Aprovação de vagas</strong><p>Vagas solicitadas pelo RH aguardando sua decisão.</p></div><button class="small-button" data-page="jobs"><i class="fa-solid fa-arrow-right"></i></button></div><div><span class="attention-icon warning"><i class="fa-solid fa-user-clock"></i></span><div><strong>Financeiro e TI</strong><p>Confirme contratações e libere o acesso ao sistema.</p></div><button class="small-button" data-page="employees"><i class="fa-solid fa-arrow-right"></i></button></div><div><span class="attention-icon"><i class="fa-solid fa-magnifying-glass-chart"></i></span><div><strong>Auditoria</strong><p>Acompanhe as últimas alterações no sistema.</p></div><button class="small-button" data-page="auditLog"><i class="fa-solid fa-arrow-right"></i></button></div></div></div><div class="card"><div class="card-title"><div><h3>Visão institucional</h3><span>Resumo da escola</span></div></div><div class="institution-grid"><div><span>Unidade</span><strong>${escapeHtml(school?.name||'Não cadastrada')}</strong></div><div><span>Ano</span><strong>${new Date().getFullYear()}</strong></div><div><span>Cidade</span><strong>${escapeHtml(school?.city||'—')}</strong></div><div><span>UF</span><strong>${escapeHtml(school?.state||'—')}</strong></div></div></div></div>`;
    document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>navigate(b.dataset.page));
  }

  function renderSchools() {
    const school=schoolForCurrent();
    content.innerHTML=`${pageHeader('Dados da Escola','Consulte e altere os dados cadastrais da escola deste ambiente.','<button class="btn-primary" id="editSchool"><i class="fa-solid fa-pen"></i> Alterar dados</button>')}
      ${school?`<div class="module-grid"><div class="module-card"><div class="module-icon"><i class="fa-solid fa-school"></i></div><h3>${escapeHtml(school.name)}</h3><p>${escapeHtml(school.address||'Endereço não informado')} — ${escapeHtml(school.city||'')}/${escapeHtml(school.state||'')}</p><p><b>INEP:</b> ${escapeHtml(school.inep||'Não informado')}</p><p><b>CNPJ:</b> ${escapeHtml(school.cnpj||'Não informado')}</p><p><b>E-mail:</b> ${escapeHtml(school.email||'Não informado')}</p></div></div>`:'<div class="empty-state">Nenhuma escola cadastrada. Use “Adicione sua escola” na tela inicial.</div>'}`;
    document.getElementById('editSchool')?.addEventListener('click',()=>openSchoolEditor(school?.id));
  }

  const SCHOOL_STAGES=['Educação Infantil — Creche','Educação Infantil — Pré-escola','Ensino Fundamental — Anos Iniciais','Ensino Fundamental — Anos Finais','Ensino Médio','Educação de Jovens e Adultos (EJA)','Educação Especial (AEE)','Educação Profissional'];
  const SCHOOL_SHIFTS=['Matutino','Vespertino','Noturno','Integral'];
  const SCHOOL_INFRA=['Biblioteca','Laboratório de Informática','Laboratório de Ciências','Quadra Poliesportiva','Cozinha / Refeitório','Acessibilidade (rampas e banheiro adaptado)','Internet','Sala de Recursos Multifuncionais (AEE)'];

  function schoolFormSectionsHtml(s){
    s=s||{};
    const chkGroup=(name,options,selected)=>`<div class="checkbox-grid">${options.map(o=>`<label><input type="checkbox" name="${name}" value="${escapeHtml(o)}" ${(selected||[]).includes(o)?'checked':''}> ${escapeHtml(o)}</label>`).join('')}</div>`;
    const sel=(id,label,opts,val,full)=>`<div${full?' class="full"':''}><label for="${id}">${label}</label><select id="${id}">${optionsHtml(opts,val)}</select></div>`;
    const inp=(id,label,val,extra='',full)=>`<div${full?' class="full"':''}><label for="${id}">${label}</label><input id="${id}" value="${escapeHtml(val||'')}" ${extra}></div>`;
    return `
      <div class="section-progress"><span>1. Identificação</span><span>2. Localização</span><span>3. Contato</span><span>4. Gestão</span><span>5. Oferta educacional</span><span>6. Infraestrutura</span><span>7. Serviços</span></div>

      <fieldset><legend>1. Identificação da escola</legend><div class="form-grid">
        ${inp('sr_name','Nome oficial da escola *',s.name,'required placeholder="Ex.: Escola Municipal Modelo"',true)}
        ${inp('sr_fantasy','Nome fantasia (se houver)',s.fantasyName)}
        ${inp('sr_cnpj','CNPJ',s.cnpj,'placeholder="00.000.000/0000-00"')}
        ${inp('sr_inep','Código INEP',s.inep,'placeholder="8 dígitos"')}
        ${sel('sr_dependency','Dependência administrativa',['Municipal','Estadual','Federal','Privada'],s.dependency||'Municipal')}
        ${sel('sr_category','Categoria administrativa',['Não se aplica (rede pública)','Particular','Comunitária','Confessional','Filantrópica'],s.adminCategory||'Não se aplica (rede pública)')}
        ${sel('sr_status','Situação de funcionamento',['Em atividade','Em implantação','Paralisada'],s.operatingStatus||'Em atividade')}
      </div></fieldset>

      <fieldset><legend>2. Localização</legend><div class="form-grid">
        ${inp('sr_cep','CEP',s.cep,'placeholder="00000-000"')}
        ${inp('sr_address','Logradouro (rua/avenida)',s.address,'',true)}
        ${inp('sr_number','Número',s.number)}
        ${inp('sr_complement','Complemento',s.complement)}
        ${inp('sr_neighborhood','Bairro',s.neighborhood)}
        ${inp('sr_city','Município',s.city)}
        ${inp('sr_state','UF',s.state,'maxlength="2"')}
        ${sel('sr_zone','Localização',['Urbana','Rural'],s.zone||'Urbana')}
      </div></fieldset>

      <fieldset><legend>3. Contato</legend><div class="form-grid">
        ${inp('sr_phone','Telefone',s.phone,'placeholder="(00) 0000-0000"')}
        <div><label for="sr_email">E-mail institucional</label><input id="sr_email" type="email" value="${escapeHtml(s.email||'')}"></div>
        ${inp('sr_website','Site (opcional)',s.website,'placeholder="https://..."')}
      </div></fieldset>

      <fieldset><legend>4. Gestão escolar</legend><div class="form-grid">
        ${inp('sr_managerName','Nome do(a) gestor(a) escolar *',s.managerName,'required')}
        ${inp('sr_managerRole','Cargo',s.managerRole||'Diretor(a) Escolar')}
        ${inp('sr_managerPhone','Telefone do(a) gestor(a)',s.managerPhone)}
        <div><label for="sr_managerEmail">E-mail do(a) gestor(a) *</label><input id="sr_managerEmail" type="email" value="${escapeHtml(s.managerEmail||'')}" required></div>
      </div></fieldset>

      <fieldset><legend>5. Oferta educacional</legend>
        <label>Etapas e modalidades ofertadas</label>${chkGroup('sr_stages',SCHOOL_STAGES,s.stagesOffered)}
        <label style="margin-top:14px">Turnos de funcionamento</label>${chkGroup('sr_shifts',SCHOOL_SHIFTS,s.shifts)}
      </fieldset>

      <fieldset><legend>6. Infraestrutura</legend><div class="form-grid">
        ${inp('sr_classrooms','Número de salas de aula',s.classroomCount,'type="number" min="0"')}
        ${sel('sr_water','Abastecimento de água',['Rede pública','Poço / Cisterna','Outra forma','Inexistente'],s.waterSupply||'Rede pública')}
        ${sel('sr_energy','Energia elétrica',['Rede pública','Gerador','Inexistente'],s.electricity||'Rede pública')}
      </div>
        <label style="margin-top:14px">Dependências e recursos</label>${chkGroup('sr_infra',SCHOOL_INFRA,s.infrastructure)}
      </fieldset>

      <fieldset><legend>7. Serviços escolares</legend><div class="form-grid">
        ${sel('sr_meals','Oferece alimentação escolar',['Sim','Não'],s.mealsProgram||'Sim')}
        ${sel('sr_transport','Oferece transporte escolar',['Sim','Não'],s.schoolTransport||'Não')}
      </div></fieldset>`;
  }

  function collectSchoolForm(prevId,prevCreatedAt){
    const v=id=>document.getElementById(id)?.value.trim();
    const checked=name=>[...document.querySelectorAll(`input[name="${name}"]:checked`)].map(x=>x.value);
    return {
      id: prevId||crypto.randomUUID(),
      name:v('sr_name'), fantasyName:v('sr_fantasy'), cnpj:v('sr_cnpj'), inep:v('sr_inep'),
      dependency:v('sr_dependency'), adminCategory:v('sr_category'), operatingStatus:v('sr_status'),
      cep:v('sr_cep'), address:v('sr_address'), number:v('sr_number'), complement:v('sr_complement'),
      neighborhood:v('sr_neighborhood'), city:v('sr_city'), state:v('sr_state').toUpperCase(), zone:v('sr_zone'),
      phone:v('sr_phone'), email:v('sr_email'), website:v('sr_website'),
      managerName:v('sr_managerName'), managerRole:v('sr_managerRole'), managerPhone:v('sr_managerPhone'), managerEmail:v('sr_managerEmail'),
      stagesOffered:checked('sr_stages'), shifts:checked('sr_shifts'),
      classroomCount:Number(v('sr_classrooms'))||0, waterSupply:v('sr_water'), electricity:v('sr_energy'),
      infrastructure:checked('sr_infra'), mealsProgram:v('sr_meals'), schoolTransport:v('sr_transport'),
      createdAt: prevCreatedAt||new Date().toISOString()
    };
  }

  function validateSchoolForm(data){
    if(!data.name) return 'Informe o nome oficial da escola.';
    if(!data.managerName) return 'Informe o nome do(a) gestor(a) escolar.';
    if(!validEmail(data.managerEmail)||!data.managerEmail) return 'Informe um e-mail válido para o(a) gestor(a).';
    if(!validEmail(data.email)) return 'E-mail institucional inválido.';
    if(!validPhone(data.phone)) return 'Telefone institucional em formato inválido.';
    if(data.state&&data.state.length!==2) return 'UF deve ter 2 letras (ex.: SE).';
    if(!data.stagesOffered.length) return 'Selecione ao menos uma etapa/modalidade ofertada.';
    if(!data.shifts.length) return 'Selecione ao menos um turno de funcionamento.';
    return null;
  }

  function openPublicSchoolRegistration(){
    loginScreen.classList.add('hidden');
    document.getElementById('schoolRegScreen').classList.remove('hidden');
    const body=document.getElementById('schoolRegBody');
    body.innerHTML=`
      <div class="public-register-intro">
        <i class="fa-solid fa-school"></i>
        <div><strong>Cadastre sua escola</strong><p>Preencha os dados abaixo para criar o ambiente de gestão da sua escola. Este cadastro não dá acesso a outras escolas — após concluir, esta será a única escola ativa neste navegador.</p></div>
      </div>
      <form id="schoolRegForm" novalidate>
        ${schoolFormSectionsHtml({})}
        <fieldset><legend>8. Conta de acesso do(a) responsável pelo cadastro</legend><div class="form-grid">
          <div class="full"><label for="sr_adminName">Nome completo *</label><input id="sr_adminName" required placeholder="Quem está cadastrando a escola"></div>
          <div><label for="sr_adminEmail">E-mail de acesso *</label><input id="sr_adminEmail" type="email" required></div>
          <div><label for="sr_adminPassword">Crie uma senha de acesso *</label><input id="sr_adminPassword" type="password" required minlength="4" placeholder="Mínimo 4 caracteres"></div>
        </div></fieldset>
        <div class="form-actions"><button type="button" class="btn-secondary" id="schoolRegCancel">Cancelar</button> <button class="btn-primary" type="submit"><i class="fa-solid fa-check"></i> Cadastrar minha escola</button></div>
      </form>`;
    document.getElementById('schoolRegCancel').onclick=()=>{document.getElementById('schoolRegScreen').classList.add('hidden');loginScreen.classList.remove('hidden');};
    document.getElementById('schoolRegForm').onsubmit=e=>{
      e.preventDefault();
      const data=collectSchoolForm();
      const err=validateSchoolForm(data);
      if(err){ let el=document.getElementById('schoolRegError'); if(!el){el=document.createElement('div');el.id='schoolRegError';el.className='alert alert-danger';el.setAttribute('role','alert');document.getElementById('schoolRegForm').prepend(el);} el.textContent=err; el.scrollIntoView({block:'center'}); return; }
      const adminName=document.getElementById('sr_adminName').value.trim();
      const adminEmail=document.getElementById('sr_adminEmail').value.trim();
      const adminPassword=document.getElementById('sr_adminPassword').value;
      if(!adminName||!adminEmail||!adminPassword){ showToast('Preencha os dados da conta de acesso.'); return; }
      state.schools.push(data);
      state.currentSchoolId=data.id;
      const account={id:crypto.randomUUID(),name:adminName,role:'secretaria_gestao',email:adminEmail,password:adminPassword,schoolId:data.id,status:'Ativo',vinculo:null,vinculoLabel:'Responsável pelo cadastro da escola',matricula:'FUNC-0000'};
      state.mockUsers.push(account);
      state.user=adminName; state.role='secretaria_gestao'; state.currentUserId=account.id;
      save();
      document.getElementById('schoolRegScreen').classList.add('hidden');
      app.classList.remove('hidden');
      updateUser(); buildMenu(); navigate('dashboard'); wireTopbar(); updateNotifBadge();
      logAudit('Escolas','Cadastro',`${data.name} cadastrada por ${adminName}.`);
      showToast('Escola cadastrada. Ambiente de gestão criado com sucesso.');
    };
  }

  function openSchoolEditor(id=null){
    const school=schoolForCurrent();
    if(!can('estrutura', id?'edit':'create')){ denyToast(id?'edit':'create'); return; }
    const s=state.schools.find(x=>x.id===id)||{};
    content.innerHTML=`${pageHeader(id?'Alterar Dados da Escola':'Cadastrar Nova Escola','Cadastro completo, nos mesmos moldes das informações pedidas pelo Censo Escolar/INEP.')}
      <div class="table-card" style="padding:28px 30px"><form id="schoolEditForm" novalidate>${schoolFormSectionsHtml(s)}<div class="form-actions"><button type="button" class="btn-secondary" id="schoolEditCancel">Cancelar</button> <button class="btn-primary" type="submit">Salvar escola</button></div></form></div>`;
    document.getElementById('schoolEditCancel').onclick=()=>renderSchools();
    document.getElementById('schoolEditForm').onsubmit=e=>{
      e.preventDefault();
      const data=collectSchoolForm(id||undefined,s.createdAt);
      if(id){ data.email=data.email; } // keep collected value
      const err=validateSchoolForm(data);
      if(err){ let el=document.getElementById('schoolEditError'); if(!el){el=document.createElement('div');el.id='schoolEditError';el.className='alert alert-danger';el.setAttribute('role','alert');document.getElementById('schoolEditForm').prepend(el);} el.textContent=err; el.scrollIntoView({block:'center'}); return; }
      if(id){ Object.assign(s,data,{adminName:s.adminName,adminEmail:s.adminEmail}); logAudit('Escolas','Alteração',s.name); }
      else{ state.schools.push(data); if(!state.currentSchoolId) state.currentSchoolId=data.id; logAudit('Escolas','Criação',data.name); }
      save(); renderSchools(); showToast('Escola cadastrada/atualizada com sucesso.');
    };
  }

  function renderClasses(){
    const school=schoolForCurrent(); const list=state.classes.filter(c=>!school||c.schoolId===school.id);
    content.innerHTML=`${pageHeader('Turmas e Séries','Crie turmas com matriz curricular e grade semanal pré-carregadas.','<button class="btn-primary" id="newClass"><i class="fa-solid fa-plus"></i> Criar turma</button>')}
      <div class="alert alert-info"><i class="fa-solid fa-wand-magic-sparkles"></i><div><strong>Cadastro inteligente</strong><br>Ao escolher a série, disciplinas, carga horária e quantidade semanal de aulas são carregadas automaticamente. A grade de segunda a sexta também é criada.</div></div>
      <div class="table-card"><div class="table-wrap"><table><thead><tr><th>Turma</th><th>Série</th><th>Turno</th><th>Ocupação</th><th>Disciplinas</th><th>Aulas/semana</th><th>Ações</th></tr></thead><tbody>${list.length?list.map(c=>{const occ=studentsOfClass(c.id).length;const pct=c.vacancies?Math.round(occ/c.vacancies*100):0;const full=occ>=c.vacancies;return `<tr><td><strong>${escapeHtml(c.name)}</strong></td><td>${escapeHtml(c.grade)}</td><td>${escapeHtml(c.shift)}</td><td><span class="badge ${full?'badge-red':pct>=90?'badge-yellow':'badge-green'}">${occ} / ${c.vacancies} (${pct}%)</span>${full?' <small class="muted">turma cheia</small>':''}</td><td>${c.subjects.length}</td><td>${c.subjects.reduce((a,s)=>a+Number(s.weeklyClasses||0),0)}</td><td><button class="small-button class-view" data-id="${c.id}"><i class="fa-solid fa-eye"></i></button><button class="small-button class-edit" data-id="${c.id}"><i class="fa-solid fa-pen"></i></button></td></tr>`;}).join(''):'<tr><td colspan="7" style="text-align:center;padding:30px">Nenhuma turma cadastrada.</td></tr>'}</tbody></table></div></div>`;
    document.getElementById('newClass')?.addEventListener('click',()=>openClassEditor());
    document.querySelectorAll('.class-edit').forEach(b=>b.onclick=()=>openClassEditor(b.dataset.id));
    document.querySelectorAll('.class-view').forEach(b=>b.onclick=()=>openClassDetails(b.dataset.id));
  }

  function getTemplate(grade){return (curriculumTemplates[grade]||[]).map(([name,annual,weeklyClasses])=>({name,annual,weeklyHours:Math.round(annual/40),weeklyClasses}));}

  function buildSchedule(subjects){
    const slots=[]; let cursor=0; const max=timeSlots.length*weekdays.length;
    const queue=[]; subjects.forEach(s=>{for(let i=0;i<s.weeklyClasses;i++)queue.push(s.name);});
    // Distribute by day to avoid filling one subject on the same day repeatedly.
    let index=0;
    for(let d=0;d<weekdays.length && index<queue.length;d++){
      const used=new Set();
      for(let p=0;p<timeSlots.length && index<queue.length;p++){
        let found=-1;
        for(let k=index;k<queue.length;k++){if(!used.has(queue[k])){found=k;break;}}
        if(found<0) found=index;
        const subject=queue[found]; queue.splice(found,1); used.add(subject);
        const t=timeSlots[p]; slots.push({weekday:d+1,weekdayName:weekdays[d],period:t[0],start:t[1],end:t[2],subject}); index=0;
      }
    }
    while(queue.length && slots.length<max){const subject=queue.shift();const p=slots.length%timeSlots.length;const d=Math.floor(slots.length/timeSlots.length);const t=timeSlots[p];slots.push({weekday:d+1,weekdayName:weekdays[d],period:t[0],start:t[1],end:t[2],subject});}
    return slots;
  }

  function openClassEditor(id=null){
    const c=state.classes.find(x=>x.id===id); const grade=c?.grade||'1º ano do Ensino Médio'; const subjects=c?.subjects||getTemplate(grade); const school=schoolForCurrent();
    if(!school){showToast('Cadastre sua escola primeiro pelo botão “Adicione sua escola”.');return;}
    openModal(id?'Alterar turma':'Criar turma',`<form id="classForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid"><div class="full"><label>Escola *</label><select id="classSchool" required>${schoolOptions(c?.schoolId||school?.id)}</select></div><div><label>Ano letivo</label><input id="classYear" value="${c?.year||new Date().getFullYear()}" type="number"></div><div><label>Série / etapa *</label><select id="classGrade">${Object.keys(curriculumTemplates).map(g=>`<option ${g===grade?'selected':''}>${g}</option>`).join('')}</select></div><div><label>Nome da turma *</label><input id="className" value="${escapeHtml(c?.name||'A')}" placeholder="Ex.: A" required></div><div><label>Turno</label><select id="classShift">${['Manhã','Tarde','Noite','Integral'].map(x=>`<option ${x===(c?.shift||'Manhã')?'selected':''}>${x}</option>`).join('')}</select></div><div><label>Sala</label><input id="classRoom" value="${escapeHtml(c?.room||'')}" placeholder="Ex.: Sala 03"></div><div><label>Vagas</label><input id="classVacancies" type="number" value="${c?.vacancies||35}" min="1"></div></div><div class="curriculum-editor"><div class="card-title"><h3>Matriz curricular</h3><span>Pré-definida e editável</span></div><div id="subjectRows">${subjects.map(subjectRow).join('')}</div><button type="button" class="btn-secondary" id="addSubject"><i class="fa-solid fa-plus"></i> Adicionar disciplina</button></div><div class="alert alert-success"><i class="fa-solid fa-calendar-check"></i><div><strong>Grade semanal automática</strong><br>Depois de salvar, o sistema distribui as aulas entre segunda e sexta-feira usando os horários padrão.</div></div><div class="form-actions"><button class="btn-primary" type="submit">${id?'Salvar alterações':'Criar turma e gerar grade'}</button></div></form>`);
    const bind=()=>document.querySelectorAll('.remove-subject').forEach(b=>b.onclick=()=>b.parentElement.remove());
    document.getElementById('classGrade').onchange=e=>{document.getElementById('subjectRows').innerHTML=getTemplate(e.target.value).map(subjectRow).join('');bind();};
    document.getElementById('addSubject').onclick=()=>{const d=document.createElement('div');d.innerHTML=subjectRow({name:'',annual:40,weeklyHours:1,weeklyClasses:1});document.getElementById('subjectRows').appendChild(d.firstElementChild);bind();}; bind();
    document.getElementById('classForm').onsubmit=e=>{e.preventDefault();const subjects=[...document.querySelectorAll('.subject-row')].map(r=>({name:r.querySelector('.subject-name').value.trim(),annual:Number(r.querySelector('.subject-annual').value||0),weeklyHours:Number(r.querySelector('.subject-hours').value||0),weeklyClasses:Number(r.querySelector('.subject-classes').value||0)})).filter(s=>s.name);const data={id:id||crypto.randomUUID(),schoolId:document.getElementById('classSchool').value,year:Number(document.getElementById('classYear').value),grade:document.getElementById('classGrade').value,name:document.getElementById('className').value.trim(),shift:document.getElementById('classShift').value,room:document.getElementById('classRoom').value,vacancies:Number(document.getElementById('classVacancies').value),subjects,schedule:buildSchedule(subjects),updatedAt:new Date().toISOString()};if(id)Object.assign(c,data);else state.classes.push(data);state.currentSchoolId=data.schoolId;save();closeModal();renderClasses();showToast('Turma criada com matriz e grade semanal automaticamente.');};
  }
  function subjectRow(s){return `<div class="subject-row"><input class="subject-name" value="${escapeHtml(s.name)}" placeholder="Disciplina"><input class="subject-hours" type="number" min="0" value="${s.weeklyHours}" title="Horas/semana"><input class="subject-annual" type="number" min="0" value="${s.annual}" title="Carga anual"><input class="subject-classes" type="number" min="1" value="${s.weeklyClasses}" title="Aulas/semana"><button type="button" class="small-button remove-subject"><i class="fa-solid fa-trash"></i></button></div>`;}

  function openClassDetails(id){const c=state.classes.find(x=>x.id===id);if(!c)return;openModal(`Turma ${escapeHtml(c.name)}`,`<div class="detail-grid"><div><b>Série</b><span>${escapeHtml(c.grade)}</span></div><div><b>Turno</b><span>${escapeHtml(c.shift)}</span></div><div><b>Sala</b><span>${escapeHtml(c.room||'-')}</span></div><div><b>Vagas</b><span>${c.vacancies}</span></div></div><h3 style="margin:24px 0 12px">Matriz curricular</h3><div class="table-card"><div class="table-wrap"><table><thead><tr><th>Disciplina</th><th>Horas/semana</th><th>Horas/ano</th><th>Aulas/semana</th></tr></thead><tbody>${c.subjects.map(s=>`<tr><td>${escapeHtml(s.name)}</td><td>${s.weeklyHours}</td><td>${s.annual}</td><td>${s.weeklyClasses}</td></tr>`).join('')}</tbody></table></div></div><h3 style="margin:24px 0 12px">Grade semanal automática</h3>${scheduleTable(c.schedule)}`);}
  function scheduleTable(schedule=[]){return `<div class="table-card"><div class="table-wrap"><table class="schedule-table"><thead><tr><th>Horário</th>${weekdays.map(d=>`<th>${d}</th>`).join('')}</tr></thead><tbody>${timeSlots.map(t=>`<tr><th>${t[0]}<br><small>${t[1]}–${t[2]}</small></th>${weekdays.map((_,di)=>{const x=schedule.find(z=>z.weekday===di+1&&z.period===t[0]);return `<td>${x?`<strong>${escapeHtml(x.subject)}</strong>`:'—'}</td>`}).join('')}</tr>`).join('')}</tbody></table></div></div>`;}

  function renderCurriculum(){content.innerHTML=`${pageHeader('Matrizes Curriculares','Modelos pré-definidos que alimentam automaticamente novas turmas.') }<div class="module-grid">${Object.entries(curriculumTemplates).map(([name,items])=>`<div class="module-card"><div class="module-icon"><i class="fa-solid fa-book-open"></i></div><h3>${name}</h3><p>${items.length} disciplinas · ${items.reduce((a,x)=>a+x[2],0)} aulas semanais</p><button class="btn-secondary template-view" data-grade="${escapeHtml(name)}">Visualizar / editar</button></div>`).join('')}</div>`;document.querySelectorAll('.template-view').forEach(b=>b.onclick=()=>openTemplateEditor(b.dataset.grade));}
  function openTemplateEditor(grade){const items=getTemplate(grade);openModal(`Matriz — ${grade}`,`<div class="alert alert-info">Este modelo é usado como padrão ao criar uma nova turma. A turma recebe uma cópia editável, então alterações na turma não alteram o modelo.</div><div id="templateRows">${items.map(subjectRow).join('')}</div><div class="form-actions"><button class="btn-primary" id="saveTemplate">Salvar modelo</button></div>`);document.getElementById('saveTemplate').onclick=()=>{const arr=[...document.querySelectorAll('.subject-row')].map(r=>[r.querySelector('.subject-name').value,Number(r.querySelector('.subject-annual').value),Number(r.querySelector('.subject-classes').value)]);curriculumTemplates[grade]=arr;closeModal();renderCurriculum();showToast('Matriz atualizada.');};}

  function renderCalendar(){
    const school=schoolForCurrent();
    if(!school){
      content.innerHTML=`${pageHeader('Calendário Escolar','Cadastre uma escola para configurar o calendário escolar.')}<div class="empty-state">Nenhuma escola cadastrada.</div>`;
      return;
    }

    const config=ensureSchoolCalendar(school.id);
    const models=calendarModels();
    const selected=models.find(m=>m.id===config.modelId)||models[0];
    const year=config.year||2026;
    const events=config.events||[];

    content.innerHTML=`${pageHeader(
      'Calendário Escolar',
      'Escolha um dos modelos padrão e aplique o que melhor se encaixa na realidade da escola.',
      `<button class="btn-primary" id="changeCalendarModel"><i class="fa-solid fa-repeat"></i> Trocar modelo</button>`
    )}
      <div class="calendar-selection-note"><i class="fa-solid fa-circle-info"></i><div><strong>Um modelo ativo por escola</strong><span>A escola escolhe um calendário padrão. Os outros dois ficam disponíveis apenas como opções de comparação.</span></div></div>
      <div class="calendar-option-grid">
        ${models.map(m=>`<div class="calendar-option ${m.id===selected.id?'active':''}">
          <div class="calendar-option-top"><span class="calendar-option-number">${m.number}</span>${m.id===selected.id?'<span class="badge badge-green">Selecionado</span>':''}</div>
          <h3>${escapeHtml(m.title)}</h3>
          <p>${escapeHtml(m.description)}</p>
          <div class="calendar-option-meta"><span><i class="fa-solid fa-arrows-rotate"></i>${escapeHtml(m.rule)}</span><span><i class="fa-solid fa-calendar-check"></i>${m.saturdays} sábados letivos (base histórica)</span></div>
          <button class="btn-secondary model-view" data-model="${m.id}">${m.id===selected.id?'Ver calendário':'Visualizar modelo'}</button>
        </div>`).join('')}
      </div>

      <div class="selected-calendar-header">
        <div><span class="eyebrow">MODELO ATIVO</span><h2>${escapeHtml(selected.title)}</h2><p>${escapeHtml(selected.description)}</p></div>
        <div class="selected-calendar-actions"><label>Ano <select id="calendarYear">${[2026,2027,2028,2029,2030].map(y=>`<option ${y===year?'selected':''}>${y}</option>`).join('')}</select></label></div>
      </div>

      <div class="calendar-legend">
        ${calendarLegend().map(x=>`<span><i class="legend-dot ${x.className}"></i>${x.label}</span>`).join('')}
      </div>

      <div class="card annual-calendar-card"><div class="card-title"><div><h3>Calendário anual ${year}</h3><span>Datas letivas, feriados, recessos, períodos pedagógicos e avaliações.</span></div><span class="calendar-total-days">${countEventType(events,'Dia letivo')} dias/eventos marcados</span></div><div id="annualCalendarGrid">${renderSchoolAnnualCalendar(year, events)}</div></div>

      <div class="card calendar-summary-card"><div class="card-title"><div><h3>Resumo do calendário</h3><span>Principais marcos do ano letivo selecionado</span></div></div><div class="calendar-summary-grid">${summaryCards(events)}</div></div>`;

    document.querySelectorAll('.model-view').forEach(btn=>btn.onclick=()=>{const modelId=btn.dataset.model;if(modelId===config.modelId){renderCalendar();}else{chooseCalendarModel(school.id,modelId);}});
    document.getElementById('changeCalendarModel')?.addEventListener('click',()=>openCalendarModelSelector(school.id));
    document.getElementById('calendarYear')?.addEventListener('change',e=>{config.year=Number(e.target.value);config.events=buildModelEvents(config.modelId,config.year);save();renderCalendar();});
  }

  function openCalendarModelSelector(schoolId){
    const config=ensureSchoolCalendar(schoolId);
    const models=calendarModels();
    openModal('Escolher modelo de calendário',`<div class="model-selector-modal"><p class="muted">Selecione o modelo que melhor corresponde à organização da escola. Apenas um modelo fica ativo por vez.</p><div class="calendar-modal-options">${models.map(m=>`<button type="button" class="calendar-modal-option ${m.id===config.modelId?'selected':''}" data-model="${m.id}"><span class="calendar-option-number">${m.number}</span><div><strong>${escapeHtml(m.title)}</strong><small>${escapeHtml(m.description)}</small></div>${m.id===config.modelId?'<i class="fa-solid fa-circle-check"></i>':''}</button>`).join('')}</div></div>`);
    document.querySelectorAll('.calendar-modal-option').forEach(b=>b.onclick=()=>{chooseCalendarModel(schoolId,b.dataset.model);closeModal();});
  }

  function chooseCalendarModel(schoolId,modelId){
    const config=ensureSchoolCalendar(schoolId);config.modelId=modelId;config.year=config.year||2026;config.events=buildModelEvents(modelId,config.year);save();renderCalendar();showToast('Modelo de calendário selecionado para a escola.');
  }

  function ensureSchoolCalendar(schoolId){
    if(!state.schoolCalendars) state.schoolCalendars=[];
    let config=state.schoolCalendars.find(x=>x.schoolId===schoolId);
    if(!config){
      config={id:crypto.randomUUID(),schoolId,modelId:'MODEL_1',year:2026,events:buildModelEvents('MODEL_1',2026)};
      state.schoolCalendars.push(config);
      save();
    }
    return config;
  }

  function calendarModels(){
    return [
      {id:'MODEL_1',number:'01',title:'Modelo 1 — Recuperação Paralela',description:'Modelo indicado para escolas que trabalham com recuperação paralela e contínua.',rule:'Recuperação paralela',saturdays:14},
      {id:'MODEL_2',number:'02',title:'Modelo 2 — Recuperação Semestral',description:'Modelo indicado para escolas que adotam recuperação semestral.',rule:'Recuperação semestral',saturdays:17},
      {id:'MODEL_3',number:'03',title:'Modelo 3 — EJA / Recuperação Final',description:'Modelo destinado às modalidades específicas, especialmente EJA, com organização própria de recuperação.',rule:'EJA / recuperação final',saturdays:20}
    ];
  }

  function calendarLegend(){return [
    {label:'Feriado',className:'holiday'},{label:'Dia letivo',className:'school-day'},{label:'Recesso / férias',className:'break'},{label:'Avaliação',className:'assessment'},{label:'Planejamento / reunião',className:'planning'},{label:'Sábado letivo',className:'saturday'}
  ];}

  function buildModelEvents(modelId,year){
    const base=[
      ['Planejamento do 1º semestre',`${year}-01-26`,`${year}-01-28`,'Planejamento'],
      ['Início do ano letivo',`${year}-02-02`,'','Dia letivo'],
      ['Carnaval',`${year}-02-16`,`${year}-02-18`,'Recesso'],
      ['Paixão de Cristo',`${year}-04-03`,'','Feriado'],
      ['Tiradentes',`${year}-04-21`,'','Feriado'],
      ['Dia Mundial do Trabalho',`${year}-05-01`,'','Feriado'],
      ['Corpus Christi',`${year}-06-04`,'','Feriado'],
      ['São João',`${year}-06-24`,'','Feriado'],
      ['Independência de Sergipe',`${year}-07-08`,'','Feriado'],
      ['Final do 1º semestre',`${year}-07-10`,'','Término'],
      ['Férias do magistério',`${year}-07-13`,`${year}-07-27`,'Férias'],
      ['Planejamento do 2º semestre',`${year}-07-28`,'','Planejamento'],
      ['Início do 2º semestre',`${year}-07-29`,'','Dia letivo'],
      ['Independência do Brasil',`${year}-09-07`,'','Feriado'],
      ['Nossa Senhora Aparecida',`${year}-10-12`,'','Feriado'],
      ['Finados',`${year}-11-02`,'','Feriado'],
      ['Dia da Consciência Negra',`${year}-11-20`,'','Feriado'],
      ['Proclamação da República',`${year}-11-15`,'','Feriado'],
      ['Natal',`${year}-12-25`,'','Feriado'],
      ['Final do ano letivo',`${year}-12-18`,'','Término']
    ];
    if(modelId==='MODEL_2') base.splice(9,0,['Período de recuperação semestral',`${year}-07-01`,`${year}-07-10`,'Avaliação']);
    if(modelId==='MODEL_3') base.push(['Período de recuperação final',`${year}-12-19`,`${year}-12-23`,'Avaliação']);
    return base.map(([title,date,endDate,type])=>({id:crypto.randomUUID(),title,date,endDate,type}));
  }

  function countEventType(events,type){return events.filter(e=>e.type===type).length;}

  function summaryCards(events){
    const important=['Início do ano letivo','Final do 1º semestre','Início do 2º semestre','Final do ano letivo'];
    return important.map(title=>{const e=events.find(x=>x.title===title);return `<div><span>${escapeHtml(title)}</span><strong>${e?formatDate(e.date):'—'}</strong></div>`}).join('');
  }

  function renderSchoolAnnualCalendar(year,events=[]){
    const monthNames=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    const weekdaysShort=['D','S','T','Q','Q','S','S'];
    return `<div class="annual-year-grid school-calendar-grid">${monthNames.map((month,mi)=>{
      const first=new Date(year,mi,1), days=new Date(year,mi+1,0).getDate(), start=first.getDay();
      let cells=''; for(let i=0;i<start;i++) cells+='<span class="day-cell empty"></span>';
      for(let d=1;d<=days;d++){
        const iso=`${year}-${String(mi+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
        const dayEvents=events.filter(e=>e.date===iso || (e.endDate&&iso>=e.date&&iso<=e.endDate));
        const primary=dayEvents[0];
        const classes=dayEvents.map(e=>eventColorClass(e.type)).join(' ');
        cells+=`<span class="day-cell ${classes||''} ${dayEvents.length?'has-event':''}" title="${escapeHtml(dayEvents.map(e=>e.title).join(' • '))}">${d}</span>`;
      }
      return `<div class="year-month"><div class="month-title">${month} <span>${year}</span></div><div class="weekday-head">${weekdaysShort.map(w=>`<span>${w}</span>`).join('')}</div><div class="month-days">${cells}</div>${events.filter(e=>Number(e.date?.slice(5,7))===mi+1).slice(0,5).map(e=>`<div class="month-event ${eventColorClass(e.type)}"><b>${formatDate(e.date)}</b> ${escapeHtml(e.title)}</div>`).join('')}</div>`;
    }).join('')}</div>`;
  }

  function eventColorClass(type){return type==='Feriado'?'holiday':type==='Dia letivo'?'school-day':type==='Férias'||type==='Recesso'?'break':type==='Avaliação'?'assessment':type==='Planejamento'?'planning':type==='Sábado letivo'?'saturday':'other-event';}

  function ensureCalendars(schoolId){
    ensureSchoolCalendar(schoolId);
    return [];
  }
  function calendarLabel(t){return t==='ACADEMIC'?'Calendário Acadêmico':t==='ADMINISTRATIVE'?'Calendário Administrativo':'Calendário de Eventos / Atividades';}
  function calendarDescription(t){return t==='ACADEMIC'?'Dias letivos, bimestres, provas, recuperação e exames.':t==='ADMINISTRATIVE'?'Reuniões, conselho de classe, prazos e atividades administrativas.':'Datas comemorativas, passeios, eventos e atividades da escola.';}
  function calendarIcon(t){return t==='ACADEMIC'?'fa-graduation-cap':t==='ADMINISTRATIVE'?'fa-building-columns':'fa-calendar-star';}
  function defaultEvents(type){const y=new Date().getFullYear();return [{id:crypto.randomUUID(),title:'Evento de demonstração',date:`${y}-02-02`,type:'Evento'}];}
  function renderCalendarEventsHtml(c){if(!c)return '<div class="empty-state">Nenhum calendário configurado.</div>';return `<div class="event-list">${c.events.length?c.events.sort((a,b)=>a.date.localeCompare(b.date)).map(e=>`<div class="event-row"><div class="event-date"><strong>${formatDate(e.date)}</strong>${e.endDate?`<small>até ${formatDate(e.endDate)}</small>`:''}</div><div><b>${escapeHtml(e.title)}</b><span>${escapeHtml(e.type||'Evento')}</span></div><button class="small-button event-edit" data-id="${e.id}" data-calendar="${c.id}"><i class="fa-solid fa-pen"></i></button></div>`).join(''):'<div class="empty-state">Nenhum evento neste calendário.</div>'}</div>`;}
  function bindCalendarEvents(){document.querySelectorAll('.event-edit').forEach(b=>b.onclick=()=>openEventEditor(b.dataset.id,b.dataset.calendar));}
  function openCalendarEditor(id){const c=state.calendars.find(x=>x.id===id);if(!c)return;openModal('Alterar calendário',`<form id="calendarForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid"><div class="full"><label>Nome</label><input id="calName" value="${escapeHtml(c.name)}" required></div><div class="full"><label>Descrição</label><textarea id="calDescription" rows="4">${escapeHtml(c.description)}</textarea></div></div><div class="form-actions"><button class="btn-primary">Salvar alterações</button></div></form>`);document.getElementById('calendarForm').onsubmit=e=>{e.preventDefault();c.name=document.getElementById('calName').value;c.description=document.getElementById('calDescription').value;save();closeModal();renderCalendar();showToast('Calendário alterado com sucesso.');};}
  function openEventEditor(eventId=null,calendarId=null){const school=schoolForCurrent();if(!school)return;const cs=ensureCalendars(school.id);const existing=eventId?cs.flatMap(c=>c.events.map(e=>({...e,calendarId:c.id}))).find(e=>e.id===eventId):null;calendarId=calendarId||existing?.calendarId||cs[0].id;openModal(existing?'Alterar evento':'Novo evento',`<form id="eventForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid"><div class="full"><label>Calendário</label><select id="eventCalendar">${cs.map(c=>`<option value="${c.id}" ${c.id===calendarId?'selected':''}>${calendarLabel(c.type)}</option>`).join('')}</select></div><div class="full"><label>Título *</label><input id="eventTitle" value="${escapeHtml(existing?.title||'')}" required></div><div><label>Data *</label><input id="eventDate" type="date" value="${existing?.date||''}" required></div><div><label>Data final</label><input id="eventEnd" type="date" value="${existing?.endDate||''}"></div><div><label>Tipo</label><input id="eventType" value="${escapeHtml(existing?.type||'Evento')}"></div></div><div class="form-actions"><button class="btn-primary">Salvar evento</button></div></form>`);document.getElementById('eventForm').onsubmit=e=>{e.preventDefault();const target=state.calendars.find(c=>c.id===document.getElementById('eventCalendar').value);const data={id:existing?.id||crypto.randomUUID(),title:document.getElementById('eventTitle').value,date:document.getElementById('eventDate').value,endDate:document.getElementById('eventEnd').value,type:document.getElementById('eventType').value};if(existing){cs.forEach(c=>c.events=c.events.filter(x=>x.id!==existing.id));}target.events.push(data);save();closeModal();renderCalendar();showToast('Evento salvo.');};}
  function formatDate(s){if(!s)return '-';return new Date(`${s}T12:00:00`).toLocaleDateString('pt-BR');}


  function renderUsers(){content.innerHTML=`${pageHeader('Usuários e Perfis','Perfis principais do sistema e seus níveis de acesso.','<button class="btn-secondary" id="goPerms"><i class="fa-solid fa-lock"></i> Configurar permissões detalhadas</button>')}<div class="module-grid">${Object.values(roles).map(r=>`<div class="module-card"><div class="module-icon"><i class="fa-solid ${r.icon}"></i></div><h3>${r.name}</h3><p>${r.sector}</p><span class="badge badge-green">Perfil ativo</span></div>`).join('')}</div>`;document.getElementById('goPerms')?.addEventListener('click',()=>navigate('permissions'));}
  function renderReports(){
    const school=schoolForCurrent();
    const cls=state.classes.filter(c=>c.schoolId===school?.id);
    const byS=arr=>(state[arr]||[]).filter(x=>x.schoolId===school?.id);
    const rhCards=state.role==='rh'?`${statCard('Vagas abertas',byS('jobs').filter(j=>j.status==='Aberta').length,'fa-bullhorn')}${statCard('Funcionários ativos',byS('employees').filter(e=>e.status==='Ativo').length,'fa-id-card')}${statCard('Afastamentos ativos',byS('leaves').filter(l=>l.status==='Em andamento').length,'fa-bed-pulse')}${statCard('Rescisões no ano',byS('terminations').length,'fa-file-signature')}${statCard('Treinamentos realizados',byS('trainings').filter(t=>t.status==='Concluído').length,'fa-chalkboard')}${statCard('Avaliações de desempenho',byS('evaluations').length,'fa-star-half-stroke')}${statCard('Pesquisas de clima',byS('climateSurveys').length,'fa-face-smile')}${statCard('Registros de SST',byS('safety').length,'fa-briefcase-medical')}${statCard('Apurações de ouvidoria',byS('ethicsCases').length,'fa-user-secret')}`:'';
    const atendimentoCards=state.role==='secretaria_atendimento'?`${statCard('Solicitações em aberto',byS('serviceRequests').filter(r=>r.status!=='Concluída'&&r.status!=='Cancelada').length,'fa-ticket')}${statCard('Solicitações concluídas',byS('serviceRequests').filter(r=>r.status==='Concluída').length,'fa-circle-check')}${statCard('Documentos emitidos',byS('documentIssuances').length,'fa-file-export')}${statCard('Agendamentos',byS('appointments').length,'fa-calendar-check')}${statCard('Atestados',byS('certificates').length,'fa-file-medical')}${statCard('Ocorrências',byS('occurrences').length,'fa-clipboard-list')}`:'';
    const gestaoCards=state.role==='secretaria_gestao'?`${statCard('Matrículas/transferências no período',byS('enrollmentRequests').length,'fa-user-pen')}${statCard('Matrículas concluídas',byS('enrollmentRequests').filter(r=>r.status==='Concluída').length,'fa-circle-check')}${statCard('Períodos letivos cadastrados',byS('academicPeriods').length,'fa-calendar-check')}`:'';
    const direcaoCards=state.role==='direcao'?`${statCard('Lançamentos financeiros',byS('financeRecords').length,'fa-sack-dollar')}${statCard('Inadimplência (em aberto/atrasado)',byS('financeRecords').filter(f=>f.status==='Em aberto'||f.status==='Atrasado').length,'fa-triangle-exclamation')}${statCard('Comunicados publicados',byS('announcements').length,'fa-bullhorn')}${statCard('Registros de auditoria',byS('auditLog').length,'fa-magnifying-glass-chart')}`:'';
    content.innerHTML=`${pageHeader('Relatórios','Indicadores básicos da escola ativa.')}<div class="stat-grid">${statCard('Turmas',cls.length,'fa-people-roof')}${statCard('Alunos',state.students.filter(s=>s.schoolId===school?.id).length,'fa-user-graduate')}${statCard('Professores',state.teachers.filter(t=>t.schoolId===school?.id).length,'fa-chalkboard-user')}${statCard('Eventos',state.calendars.filter(c=>c.schoolId===school?.id).reduce((a,c)=>a+c.events.length,0),'fa-calendar-days')}</div>${rhCards?`<div class="stat-grid">${rhCards}</div>`:''}${atendimentoCards?`<div class="stat-grid">${atendimentoCards}</div>`:''}${gestaoCards?`<div class="stat-grid">${gestaoCards}</div>`:''}${direcaoCards?`<div class="stat-grid">${direcaoCards}</div>`:''}`;
  }
  function renderDocuments(){content.innerHTML=`${pageHeader('Documentação Acadêmica','Emita documentos oficiais e consulte a documentação dos alunos.')}<div class="module-grid"><div class="module-card"><div class="module-icon"><i class="fa-solid fa-file-export"></i></div><h3>Emissão rápida de documentos</h3><p>Boletim, histórico, declarações e certificados, prontos para impressão.</p><button class="btn-secondary" data-page="documentIssuances">Abrir emissão</button></div><div class="module-card"><div class="module-icon"><i class="fa-solid fa-folder-open"></i></div><h3>Gestão documental</h3><p>Documentos dos alunos: RG, CPF, comprovantes e documentos acadêmicos.</p><button class="btn-secondary" data-page="studentDocuments">Abrir gestão documental</button></div><div class="module-card"><div class="module-icon"><i class="fa-solid fa-user-pen"></i></div><h3>Matrículas e transferências</h3><p>Matrícula inicial, rematrícula, trancamento e transferências.</p><button class="btn-secondary" data-page="enrollmentRequests">Abrir matrículas</button></div></div>`;document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>navigate(b.dataset.page));}
  function renderCertificates(){
    const school=schoolForCurrent();
    const list=state.certificates.filter(x=>x.schoolId===school?.id).sort((a,b)=>a.start.localeCompare(b.start));
    const year=new Date().getFullYear();
    content.innerHTML=`${pageHeader('Atestados de Alunos','Registre atestados apresentados na secretaria e acompanhe os períodos pelo calendário anual.','<button class="btn-primary" id="newCertificate"><i class="fa-solid fa-plus"></i> Adicionar atestado</button>')}
      <div class="card annual-calendar-card"><div class="card-title"><div><h3>Calendário anual ${year}</h3><span>As datas com atestado ficam marcadas no calendário.</span></div><span class="badge badge-green">Calendário da secretaria</span></div><div>${renderAnnualCalendarWithCertificates(year,list)}</div></div>
      <div class="table-card"><div class="table-wrap"><table><thead><tr><th>Aluno</th><th>Início</th><th>Término</th><th>Dias</th><th>Motivo / Observação</th><th>Ação</th></tr></thead><tbody>${list.length?list.map(a=>`<tr><td><strong>${escapeHtml(a.studentName)}</strong></td><td>${formatDate(a.start)}</td><td>${formatDate(a.end)}</td><td>${diffDays(a.start,a.end)}</td><td>${escapeHtml(a.reason||'-')}</td><td><button class="small-button certificate-edit" data-id="${a.id}"><i class="fa-solid fa-pen"></i></button></td></tr>`).join(''):'<tr><td colspan="6" style="text-align:center;padding:30px">Nenhum atestado registrado.</td></tr>'}</tbody></table></div></div>`;
    document.getElementById('newCertificate').onclick=()=>openCertificateEditor();
    document.querySelectorAll('.certificate-edit').forEach(b=>b.onclick=()=>openCertificateEditor(b.dataset.id));
  }
  function renderAnnualCalendarWithCertificates(year,certs){
    const monthNames=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    const week=['D','S','T','Q','Q','S','S'];
    return `<div class="certificate-calendar-grid">${monthNames.map((month,mi)=>{
      const first=new Date(year,mi,1), days=new Date(year,mi+1,0).getDate(), offset=first.getDay();
      let cells='';
      for(let i=0;i<offset;i++) cells+='<span class="certificate-day empty"></span>';
      for(let d=1;d<=days;d++){
        const iso=`${year}-${String(mi+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
        const hits=certs.filter(c=>iso>=c.start&&iso<=c.end);
        const names=[...new Set(hits.map(c=>c.studentName))];
        cells+=`<button type="button" class="certificate-day ${hits.length?'has-certificate':''}" data-date="${iso}" title="${escapeHtml(names.join(' • ')||'Selecionar data')}">${d}</button>`;
      }
      return `<section class="certificate-month"><h4>${month} <small>${year}</small></h4><div class="certificate-week">${week.map(w=>`<span>${w}</span>`).join('')}</div><div class="certificate-days">${cells}</div></section>`;
    }).join('')}</div>`;
  }
  function diffDays(start,end){if(!start||!end)return 0;return Math.max(1,Math.floor((new Date(end+'T12:00:00')-new Date(start+'T12:00:00'))/86400000)+1);}
  function openCertificateEditor(id=null){
    const school=schoolForCurrent(); if(!school){showToast('Cadastre uma escola primeiro.');return;}
    const existing=state.certificates.find(x=>x.id===id)||{};
    const students=state.students.filter(s=>s.schoolId===school.id);
    const defaultStart=existing.start||'';
    const defaultEnd=existing.end||existing.start||'';
    const tempYear=(defaultStart||new Date().toISOString().slice(0,10)).slice(0,4);
    openModal(id?'Alterar atestado':'Adicionar atestado',`
      <div class="certificate-editor">
        <form id="certificateForm" class="form-card" style="border:none;padding:0;max-width:none">
          <div class="form-grid">
            <div class="full"><label>Aluno *</label><select id="certStudent" required><option value="">Selecione o aluno</option>${students.map(s=>`<option value="${s.id}" ${s.id===existing.studentId?'selected':''}>${escapeHtml(s.name)}${s.registration?` — ${escapeHtml(s.registration)}`:''}</option>`).join('')}</select></div>
            <div><label>Data inicial *</label><input id="certStart" type="date" value="${defaultStart}" required></div>
            <div><label>Data final *</label><input id="certEnd" type="date" value="${defaultEnd}" required></div>
          </div>
          <div class="certificate-calendar-head"><div><strong>Selecione no calendário o período do atestado</strong><span>Clique no primeiro dia e depois no último dia. O período ficará marcado.</span></div><div class="certificate-calendar-year"><button type="button" class="small-button" id="certPrevYear">‹</button><strong id="certCalendarYear">${tempYear}</strong><button type="button" class="small-button" id="certNextYear">›</button></div></div>
          <div id="certificatePicker">${renderAnnualCalendarWithCertificates(Number(tempYear),state.certificates.filter(x=>x.schoolId===school.id))}</div>
          <div class="certificate-selection-status" id="certificateSelectionStatus"><i class="fa-solid fa-calendar-check"></i><span>Escolha a data inicial e a data final no calendário.</span></div>
          <div class="form-grid">
            <div class="full"><label>Motivo / observação</label><textarea id="certReason" rows="3" placeholder="Ex.: afastamento médico / documento apresentado na secretaria">${escapeHtml(existing.reason||'')}</textarea></div>
            <div><label>Documento / número</label><input id="certDoc" value="${escapeHtml(existing.document||'')}" placeholder="Opcional"></div>
          </div>
          <div class="form-actions"><button class="btn-primary" type="submit"><i class="fa-solid fa-check"></i> Salvar atestado</button></div>
        </form>
      </div>`);

    let selectedStart=defaultStart, selectedEnd=defaultEnd;
    let calendarYear=Number(tempYear);
    const refreshCalendar=()=>{
      document.getElementById('certCalendarYear').textContent=calendarYear;
      document.getElementById('certificatePicker').innerHTML=renderAnnualCalendarWithCertificates(calendarYear,state.certificates.filter(x=>x.schoolId===school.id));
      bindCertificateCalendar();
      updateSelectionUI();
    };
    const updateInputs=()=>{
      document.getElementById('certStart').value=selectedStart||'';
      document.getElementById('certEnd').value=selectedEnd||'';
    };
    const updateSelectionUI=()=>{
      const status=document.getElementById('certificateSelectionStatus');
      if(!status)return;
      if(selectedStart&&selectedEnd) status.innerHTML=`<i class="fa-solid fa-calendar-check"></i><span>Período selecionado: <strong>${formatDate(selectedStart)}</strong> até <strong>${formatDate(selectedEnd)}</strong> (${diffDays(selectedStart,selectedEnd)} dia(s)).</span>`;
      else if(selectedStart) status.innerHTML=`<i class="fa-solid fa-calendar-day"></i><span>Data inicial: <strong>${formatDate(selectedStart)}</strong>. Agora selecione o último dia.</span>`;
      else status.innerHTML='<i class="fa-solid fa-calendar-check"></i><span>Escolha a data inicial e a data final no calendário.</span>';
      document.querySelectorAll('#certificatePicker .certificate-day:not(.empty)').forEach(btn=>{
        const d=btn.dataset.date;
        const inRange=selectedStart&&selectedEnd&&d>=selectedStart&&d<=selectedEnd;
        btn.classList.toggle('picker-start',d===selectedStart);
        btn.classList.toggle('picker-end',d===selectedEnd);
        btn.classList.toggle('picker-range',!!inRange);
      });
    };
    const bindCertificateCalendar=()=>{
      document.querySelectorAll('#certificatePicker .certificate-day:not(.empty)').forEach(btn=>btn.onclick=()=>{
        const d=btn.dataset.date;
        if(!selectedStart|| (selectedStart&&selectedEnd)){ selectedStart=d; selectedEnd=''; }
        else { selectedEnd=d<selectedStart?selectedStart:d; selectedStart=d<selectedStart?d:selectedStart; }
        calendarYear=Number((selectedStart||d).slice(0,4));
        updateInputs(); updateSelectionUI();
      });
    };
    document.getElementById('certStart').onchange=e=>{selectedStart=e.target.value; if(selectedEnd&&selectedEnd<selectedStart)selectedEnd=''; calendarYear=Number((selectedStart||calendarYear)); refreshCalendar();};
    document.getElementById('certEnd').onchange=e=>{selectedEnd=e.target.value; if(selectedStart&&selectedEnd<selectedStart){showToast('A data final não pode ser anterior à inicial.');selectedEnd='';} updateSelectionUI();};
    document.getElementById('certPrevYear').onclick=()=>{calendarYear--; refreshCalendar();};
    document.getElementById('certNextYear').onclick=()=>{calendarYear++; refreshCalendar();};
    bindCertificateCalendar(); updateSelectionUI();
    document.getElementById('certificateForm').onsubmit=e=>{
      e.preventDefault();
      const st=students.find(x=>x.id===document.getElementById('certStudent').value);
      const start=document.getElementById('certStart').value, end=document.getElementById('certEnd').value;
      if(!st)return showToast('Selecione o aluno.');
      if(!start||!end)return showToast('Selecione no calendário a data inicial e a data final.');
      if(end<start)return showToast('A data final não pode ser anterior à inicial.');
      const data={id:id||crypto.randomUUID(),schoolId:school.id,studentId:st.id,studentName:st.name,start,end,reason:document.getElementById('certReason').value.trim(),document:document.getElementById('certDoc').value.trim(),updatedAt:new Date().toISOString()};
      if(id)Object.assign(existing,data);else state.certificates.push(data);
      save(); closeModal(); renderCertificates(); showToast('Atestado registrado e período marcado no calendário.');
    };
  }

  function renderOccurrences(){renderCrud(crudModules.occurrences);}
  function renderGrades(){const school=schoolForCurrent();const cls=state.classes.find(c=>c.schoolId===school?.id);content.innerHTML=`${pageHeader(state.role==='aluno'?'Boletim e Frequência':'Notas e Frequência','Área preparada para lançamento e consulta acadêmica.')}${cls?`<div class="card"><h3>${escapeHtml(cls.name)} — ${escapeHtml(cls.grade)}</h3><p class="muted">O professor lança notas e faltas com base na grade horária atribuída pela secretaria.</p></div>`:'<div class="empty-state">Nenhuma turma disponível.</div>'}`;}
  function renderSchedule(){const school=schoolForCurrent();const cls=state.classes.find(c=>c.schoolId===school?.id);content.innerHTML=`${pageHeader('Grade Horária','Grade gerada automaticamente a partir da matriz curricular.')}${cls?scheduleTable(cls.schedule):'<div class="empty-state">Crie uma turma para gerar a grade.</div>'}`;}
  function renderContent(){content.innerHTML=`${pageHeader('Conteúdos das aulas','Professor registra conteúdos conforme suas aulas e horários atribuídos.')}<div class="empty-state">Selecione uma turma para começar.</div>`;}
  function renderGeneric(page,title){content.innerHTML=`${pageHeader(title,'Módulo preparado para evolução do sistema.')}<div class="empty-state">Este módulo está estruturado na arquitetura do SIGED e será conectado às operações correspondentes.</div>`;}

  const jobStatusBadge={'Aguardando aprovação':'badge-yellow',Aberta:'badge-green',Reprovada:'badge-red',Fechada:'badge-gray'};
  const candStatusBadge={Triagem:'badge-blue',Entrevista:'badge-yellow',Aprovado:'badge-green',Reprovado:'badge-red',Contratado:'badge-green'};
  function renderJobs(){
    const school=schoolForCurrent();
    const jobs=(state.jobs||[]).filter(j=>j.schoolId===school?.id);
    const isDirecao=can('vagas','approve');
    content.innerHTML=`${pageHeader(isDirecao?'Aprovação de Vagas':'Vagas abertas',isDirecao?'Aprove ou reprove os pedidos de abertura de vaga/turma solicitados pelo RH, conforme o processo de contratação.':'Solicite a abertura de vagas para professores e funcionários. A Direção aprova antes da publicação.','<button class="btn-primary" id="newJob"><i class="fa-solid fa-plus"></i> Nova vaga</button>')}<div class="table-card"><div class="table-wrap"><table><thead><tr><th>Vaga</th><th>Setor</th><th>Tipo</th><th>Candidatos</th><th>Status</th><th>Ação</th></tr></thead><tbody>${jobs.length?jobs.map(j=>{const n=(state.candidates||[]).filter(c=>c.jobId===j.id).length;const pending=j.status==='Aguardando aprovação';return `<tr><td><strong>${escapeHtml(j.title)}</strong></td><td>${escapeHtml(j.sector)}</td><td>${escapeHtml(j.type)}</td><td>${n}</td><td><span class="badge ${jobStatusBadge[j.status]||'badge-gray'}">${escapeHtml(j.status)}</span></td><td>${isDirecao&&pending?`<button class="small-button job-approve" data-id="${j.id}" title="Aprovar"><i class="fa-solid fa-check"></i></button> <button class="small-button job-reject" data-id="${j.id}" title="Reprovar"><i class="fa-solid fa-xmark"></i></button>`:`<button class="small-button job-cands" data-id="${j.id}" title="Ver candidatos"><i class="fa-solid fa-user-check"></i></button> <button class="small-button job-edit" data-id="${j.id}"><i class="fa-solid fa-pen"></i></button>`}</td></tr>`;}).join(''):'<tr><td colspan="6" style="text-align:center;padding:30px">Nenhuma vaga publicada.</td></tr>'}</tbody></table></div></div>`;
    document.getElementById('newJob').onclick=()=>openJobEditor();
    document.querySelectorAll('.job-edit').forEach(b=>b.onclick=()=>openJobEditor(b.dataset.id));
    document.querySelectorAll('.job-cands').forEach(b=>b.onclick=()=>{window.__rhJobFilter=b.dataset.id;navigate('candidates');});
    document.querySelectorAll('.job-approve').forEach(b=>b.onclick=()=>{const j=state.jobs.find(x=>x.id===b.dataset.id);if(j){j.status='Aberta';logAudit('Vagas','Aprovação',j.title);save();renderJobs();showToast('Vaga aprovada e publicada para o RH.');}});
    document.querySelectorAll('.job-reject').forEach(b=>b.onclick=()=>{const j=state.jobs.find(x=>x.id===b.dataset.id);if(j){j.status='Reprovada';logAudit('Vagas','Reprovação',j.title);save();renderJobs();showToast('Solicitação de vaga reprovada.');}});
  }

  function openJobEditor(id=null){
    const school=schoolForCurrent();
    if(!school){showToast('Cadastre uma escola primeiro.');return;}
    const j=(state.jobs||[]).find(x=>x.id===id)||{};
    const isDirecao=can('vagas','approve');
    const statusField = isDirecao
      ? `<div><label>Status</label><select id="jobStatus"><option ${j.status==='Aguardando aprovação'?'selected':''}>Aguardando aprovação</option><option ${j.status==='Aberta'?'selected':''}>Aberta</option><option ${j.status==='Reprovada'?'selected':''}>Reprovada</option><option ${j.status==='Fechada'?'selected':''}>Fechada</option></select></div>`
      : (id ? `<div><label>Status</label><input value="${escapeHtml(j.status||'')}" disabled><small class="muted">Somente a Direção altera o status de aprovação.</small></div>` : '');
    openModal(id?'Alterar vaga':'Solicitar abertura de vaga',`${!id?'<div class="alert alert-info">Ao salvar, a solicitação segue para aprovação da Direção antes de ficar disponível para candidatos.</div>':''}<form id="jobForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid"><div class="full"><label>Cargo / título da vaga *</label><input id="jobTitle" value="${escapeHtml(j.title||'')}" required placeholder="Ex.: Professor de Matemática"></div><div><label>Setor</label><select id="jobSector"><option ${j.sector==='Pedagógico'?'selected':''}>Pedagógico</option><option ${j.sector==='Administrativo'?'selected':''}>Administrativo</option><option ${j.sector==='Financeiro'?'selected':''}>Financeiro</option><option ${j.sector==='TI'?'selected':''}>TI</option><option ${j.sector==='Apoio'?'selected':''}>Apoio / Limpeza</option></select></div><div><label>Tipo</label><select id="jobType"><option ${j.type==='Professor'?'selected':''}>Professor</option><option ${j.type==='Funcionário'?'selected':''}>Funcionário</option></select></div><div class="full"><label>Descrição da vaga</label><textarea id="jobDesc" rows="3">${escapeHtml(j.description||'')}</textarea></div>${statusField}</div><div class="form-actions"><button class="btn-primary">${id?'Salvar vaga':'Enviar para aprovação'}</button></div></form>`);
    document.getElementById('jobForm').onsubmit=e=>{
      e.preventDefault();
      const status = isDirecao ? document.getElementById('jobStatus').value : (id ? j.status : 'Aguardando aprovação');
      const data={id:id||crypto.randomUUID(),schoolId:school.id,title:document.getElementById('jobTitle').value,sector:document.getElementById('jobSector').value,type:document.getElementById('jobType').value,description:document.getElementById('jobDesc').value,status};
      if(id)Object.assign(j,data);else state.jobs.push(data);
      logAudit('Vagas',id?'Alteração':'Solicitação',data.title);
      save();closeModal();renderJobs();showToast(id?'Vaga atualizada.':'Solicitação enviada para aprovação da Direção.');
    };
  }

  function renderCandidates(){
    const school=schoolForCurrent();
    const jobs=(state.jobs||[]).filter(j=>j.schoolId===school?.id);
    let cands=(state.candidates||[]).filter(c=>c.schoolId===school?.id);
    const filterId=window.__rhJobFilter;
    if(filterId)cands=cands.filter(c=>c.jobId===filterId);
    const jobName=id=>jobs.find(j=>j.id===id)?.title||'—';
    content.innerHTML=`${pageHeader('Candidatos',filterId?`Filtrando por: ${escapeHtml(jobName(filterId))}`:'Triagem, entrevista e aprovação de candidatos.',`${filterId?'<button class="btn-secondary" id="clearFilter">Limpar filtro</button> ':''}<button class="btn-primary" id="newCand"><i class="fa-solid fa-plus"></i> Novo candidato</button>`)}<div class="table-card"><div class="table-wrap"><table><thead><tr><th>Nome</th><th>Vaga</th><th>Contato</th><th>Status</th><th>Ação</th></tr></thead><tbody>${cands.length?cands.map(c=>`<tr><td><strong>${escapeHtml(c.name)}</strong></td><td>${escapeHtml(jobName(c.jobId))}</td><td>${escapeHtml(c.contact||'-')}</td><td><span class="badge ${candStatusBadge[c.status]||'badge-gray'}">${escapeHtml(c.status)}</span></td><td>${c.status==='Contratado'?'<span class="muted">Contratado</span>':`<select class="cand-status" data-id="${c.id}"><option ${c.status==='Triagem'?'selected':''}>Triagem</option><option ${c.status==='Entrevista'?'selected':''}>Entrevista</option><option ${c.status==='Aprovado'?'selected':''}>Aprovado</option><option ${c.status==='Reprovado'?'selected':''}>Reprovado</option></select> ${c.status==='Aprovado'?`<button class="small-button cand-hire" data-id="${c.id}" title="Contratar"><i class="fa-solid fa-file-signature"></i></button>`:''}`}</td></tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:30px">Nenhum candidato registrado.</td></tr>'}</tbody></table></div></div>`;
    document.getElementById('newCand').onclick=()=>openCandidateEditor();
    document.getElementById('clearFilter')?.addEventListener('click',()=>{window.__rhJobFilter=null;renderCandidates();});
    document.querySelectorAll('.cand-status').forEach(s=>s.onchange=()=>{const c=state.candidates.find(x=>x.id===s.dataset.id);if(c){c.status=s.value;save();renderCandidates();showToast('Status do candidato atualizado.');}});
    document.querySelectorAll('.cand-hire').forEach(b=>b.onclick=()=>openHireEditor(b.dataset.id));
  }

  function openCandidateEditor(){
    const school=schoolForCurrent();
    if(!school){showToast('Cadastre uma escola primeiro.');return;}
    const jobs=(state.jobs||[]).filter(j=>j.schoolId===school.id&&j.status==='Aberta');
    if(!jobs.length){showToast('É preciso ter uma vaga aprovada e aberta pela Direção antes de cadastrar candidatos.');return;}
    openModal('Novo candidato',`<form id="candForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid"><div class="full"><label>Nome completo *</label><input id="candName" required></div><div><label>Vaga *</label><select id="candJob">${jobs.map(j=>`<option value="${j.id}">${escapeHtml(j.title)}</option>`).join('')}</select></div><div><label>Contato (telefone/e-mail)</label><input id="candContact"></div></div><div class="form-actions"><button class="btn-primary">Registrar candidato</button></div></form>`);
    document.getElementById('candForm').onsubmit=e=>{
      e.preventDefault();
      state.candidates.push({id:crypto.randomUUID(),schoolId:school.id,jobId:document.getElementById('candJob').value,name:document.getElementById('candName').value,contact:document.getElementById('candContact').value,status:'Triagem'});
      save();closeModal();renderCandidates();showToast('Candidato registrado em Triagem.');
    };
  }

  function openHireEditor(candId){
    const school=schoolForCurrent();
    const c=state.candidates.find(x=>x.id===candId);
    const job=state.jobs.find(j=>j.id===c?.jobId);
    if(!c)return;
    openModal('Contratar candidato',`<div class="alert alert-info">Ao confirmar, um cadastro de funcionário é criado e enviado para o Financeiro incluir na folha. O acesso ao sistema é liberado separadamente por TI, na tela de Funcionários.</div><form id="hireForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid"><div class="full"><label>Nome</label><input value="${escapeHtml(c.name)}" disabled></div><div><label>Cargo</label><input id="hireRole" value="${escapeHtml(job?.title||'')}"></div><div><label>Tipo</label><select id="hireType"><option ${job?.type==='Professor'?'selected':''}>Professor</option><option ${job?.type!=='Professor'?'selected':''}>Funcionário</option></select></div><div><label>Data de admissão</label><input id="hireDate" type="date" value="${new Date().toISOString().slice(0,10)}"></div><div><label>Regime de contratação</label><select id="hireRegime"><option>Mensalista</option><option>Horista</option></select></div><div><label>Salário mensal (R$) — se Mensalista</label><input id="hireSalary" type="number" min="0" step="0.01"></div><div><label>Carga horária semanal (h/aula) — se Horista</label><input id="hireCarga" type="number" min="0" step="1"></div><div><label>Valor da hora-aula (R$) — se Horista</label><input id="hireValorHora" type="number" min="0" step="0.01"></div></div><div class="form-actions"><button class="btn-primary">Confirmar contratação</button></div></form>`);
    document.getElementById('hireForm').onsubmit=e=>{
      e.preventDefault();
      const regime=document.getElementById('hireRegime').value;
      const carga=Number(document.getElementById('hireCarga').value)||0;
      const valorHora=Number(document.getElementById('hireValorHora').value)||0;
      const salarioBase=Number(document.getElementById('hireSalary').value)||0;
      const salary = regime==='Horista' ? Math.round(carga*valorHora*4.5*100)/100 : salarioBase;
      const emp={id:crypto.randomUUID(),schoolId:school.id,name:c.name,role:document.getElementById('hireRole').value,type:document.getElementById('hireType').value,admissionDate:document.getElementById('hireDate').value,regime,cargaHorariaSemanal:carga,valorHora,salary,status:'Aguardando Financeiro',hasAccess:false};
      state.employees.push(emp);
      c.status='Contratado';
      if(emp.type==='Professor'){state.teachers.push({id:crypto.randomUUID(),schoolId:school.id,name:emp.name,registration:'PROF-'+emp.id.slice(0,5).toUpperCase(),email:'',classId:null,className:'Sem vínculo'});}
      logAudit('Funcionários','Contratação',emp.name);
      save();closeModal();renderCandidates();showToast('Contratação registrada. Dados do colaborador encaminhados ao Financeiro para confirmação.');
    };
  }

  const empStatusBadge={'Aguardando Financeiro':'badge-yellow','Aguardando Liberação de Acesso':'badge-blue',Ativo:'badge-green',Afastado:'badge-yellow',Desligado:'badge-gray'};
  function renderEmployees(){
    const school=schoolForCurrent();
    const emps=(state.employees||[]).filter(e=>e.schoolId===school?.id);
    const isDirecao=can('financeiro','approve');
    content.innerHTML=`${pageHeader(isDirecao?'Confirmação Financeira e Acessos':'Funcionários',isDirecao?'Etapas de Financeiro (confirmar cadastro e liberar para criação de conta) e TI (criar conta, definir permissões e liberar o primeiro acesso).':'Contratos ativos, regime de contratação, cargos e salários. A confirmação financeira e a liberação de acesso são feitas pela Direção (Financeiro/TI).')}<div class="table-card"><div class="table-wrap"><table><thead><tr><th>Nome</th><th>Cargo</th><th>Regime</th><th>Admissão</th><th>Salário</th><th>Status</th><th>Acesso</th><th>Ações</th></tr></thead><tbody>${emps.length?emps.map(e=>{
      let accessCell='<span class="muted">-</span>';
      if(e.hasAccess){accessCell='<span class="badge badge-green">Liberado</span>';}
      else if(isDirecao&&e.status==='Aguardando Financeiro'){accessCell=`<button class="small-button fin-confirm" data-id="${e.id}"><i class="fa-solid fa-check"></i> Confirmar no Financeiro</button>`;}
      else if(isDirecao&&e.status==='Aguardando Liberação de Acesso'){accessCell=`<button class="small-button ti-access" data-id="${e.id}"><i class="fa-solid fa-key"></i> Criar conta (TI)</button>`;}
      else if(e.status==='Aguardando Financeiro'){accessCell='<span class="muted">Aguardando Financeiro</span>';}
      else if(e.status==='Aguardando Liberação de Acesso'){accessCell='<span class="muted">Aguardando TI</span>';}
      return `<tr><td><strong>${escapeHtml(e.name)}</strong></td><td>${escapeHtml(e.role)}</td><td>${escapeHtml(e.regime||e.type||'-')}${e.regime==='Horista'?`<br><small class="muted">${e.cargaHorariaSemanal||0}h/sem · R$ ${Number(e.valorHora||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}/h</small>`:''}</td><td>${formatDate(e.admissionDate)}</td><td>R$ ${Number(e.salary||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}</td><td>${badge(e.status,empStatusBadge)}</td><td>${accessCell}</td><td>${e.status!=='Desligado'?`<button class="small-button emp-leave" data-id="${e.id}" title="Registrar afastamento"><i class="fa-solid fa-bed-pulse"></i></button> <button class="small-button emp-term" data-id="${e.id}" title="Registrar rescisão"><i class="fa-solid fa-file-signature"></i></button>`:'<span class="muted">Desligado</span>'}</td></tr>`;
    }).join(''):'<tr><td colspan="8" style="text-align:center;padding:30px">Nenhum funcionário contratado ainda.</td></tr>'}</tbody></table></div></div>`;
    document.querySelectorAll('.fin-confirm').forEach(b=>b.onclick=()=>{const e=state.employees.find(x=>x.id===b.dataset.id);if(e){e.status='Aguardando Liberação de Acesso';logAudit('Financeiro','Confirmação de contratação',e.name);save();renderEmployees();showToast(`Cadastro financeiro de ${e.name} confirmado. Liberado para a TI criar a conta.`);}});
    document.querySelectorAll('.ti-access').forEach(b=>b.onclick=()=>openAccessEditor(b.dataset.id));
    document.querySelectorAll('.emp-leave').forEach(b=>b.onclick=()=>openCrudEditor(crudModules.leaves,null,{employeeId:b.dataset.id}));
    document.querySelectorAll('.emp-term').forEach(b=>b.onclick=()=>openCrudEditor(crudModules.terminations,null,{employeeId:b.dataset.id}));
  }

  function openAccessEditor(empId){
    const e=state.employees.find(x=>x.id===empId);
    if(!e)return;
    const school=schoolForCurrent();
    const isProf=e.type==='Professor';
    const classes=state.classes.filter(c=>c.schoolId===school?.id);
    openModal('TI — Criar conta e definir acesso',`<div class="alert alert-info">Etapa de TI: criar a conta de usuário, decidir o tipo de acesso e enviar as credenciais por e-mail.</div><form id="accessForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid"><div class="full"><label>Colaborador</label><input value="${escapeHtml(e.name)}" disabled></div><div class="full"><label>É professor?</label><input value="${isProf?'Sim — será associado a turmas e disciplinas':'Não — funcionário administrativo/apoio'}" disabled></div>${isProf?`<div class="full"><label>Turma inicial (opcional)</label><select id="accessClass"><option value="">Sem vínculo por enquanto</option>${classes.map(c=>`<option value="${c.id}">${escapeHtml(c.name)} — ${escapeHtml(c.grade)}</option>`).join('')}</select></div>`:`<div class="full"><label>Perfil de permissões</label><select id="accessProfile"><option>Administrativo</option><option>Secretaria</option><option>Financeiro</option><option>Apoio / Limpeza</option><option>TI</option></select></div>`}<div class="full"><label>E-mail institucional</label><input id="accessEmail" type="email" placeholder="nome@escola.com.br" required></div></div><div class="form-actions"><button class="btn-primary">Criar conta e liberar acesso</button></div></form>`);
    document.getElementById('accessForm').onsubmit=ev=>{
      ev.preventDefault();
      const email=document.getElementById('accessEmail').value;
      e.hasAccess=true; e.status='Ativo'; e.email=email;
      if(isProf){
        const classId=document.getElementById('accessClass').value;
        const cls=classes.find(c=>c.id===classId);
        const teacher=state.teachers.find(t=>t.schoolId===school.id&&t.name===e.name);
        if(teacher){teacher.email=email; if(cls){teacher.classId=cls.id;teacher.className=cls.name;}}
      } else {
        e.accessProfile=document.getElementById('accessProfile').value;
      }
      logAudit('TI','Criação de conta e liberação de acesso',`${e.name} — e-mail de boas-vindas enviado para ${email}`);
      save();closeModal();renderEmployees();showToast(`Conta criada. E-mail de boas-vindas enviado para ${email}. ${e.name} já pode fazer o primeiro acesso.`);
    };
  }

  function renderPayroll(){
    const school=schoolForCurrent();
    const emps=(state.employees||[]).filter(e=>e.schoolId===school?.id&&e.status==='Ativo');
    const mensalistas=emps.filter(e=>e.regime!=='Horista');
    const horistas=emps.filter(e=>e.regime==='Horista');
    const total=emps.reduce((a,e)=>a+(e.salary||0),0);
    const benefitsTotal=(state.benefits||[]).filter(b=>b.schoolId===school?.id&&b.status==='Ativo').reduce((a,b)=>a+(Number(b.value)||0),0);
    const runs=(state.payrollRuns||[]).filter(r=>r.schoolId===school?.id).sort((a,b)=>b.date.localeCompare(a.date));
    content.innerHTML=`${pageHeader('Folha de pagamento','Consolide salários (mensalistas e horistas, com DSR embutido), benefícios e gere a folha do mês.','<button class="btn-primary" id="runPayroll"><i class="fa-solid fa-play"></i> Gerar folha do mês</button>')}<div class="stat-grid">${statCard('Funcionários ativos',emps.length,'fa-id-card')}${statCard('Mensalistas',mensalistas.length,'fa-user-tie')}${statCard('Horistas (hora-aula)',horistas.length,'fa-clock')}${statCard('Total da folha',`R$ ${total.toLocaleString('pt-BR',{minimumFractionDigits:2})}`,'fa-sack-dollar')}</div><div class="alert alert-info">Benefícios ativos (plano de saúde, vale-transporte, bolsas de estudo) somam R$ ${benefitsTotal.toLocaleString('pt-BR',{minimumFractionDigits:2})}/mês, à parte da folha salarial. Para horistas, o valor estimado já inclui DSR e hora-atividade proporcional.</div><div class="card"><div class="card-title"><div><h3>Histórico de folhas geradas</h3></div></div>${runs.length?`<div class="table-wrap"><table><thead><tr><th>Gerada em</th><th>Funcionários</th><th>Total</th></tr></thead><tbody>${runs.map(r=>`<tr><td>${formatDate(r.date)}</td><td>${r.count}</td><td>R$ ${r.total.toLocaleString('pt-BR',{minimumFractionDigits:2})}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">Nenhuma folha gerada ainda.</div>'}</div>`;
    document.getElementById('runPayroll').onclick=()=>{
      state.payrollRuns.push({id:crypto.randomUUID(),schoolId:school.id,date:new Date().toISOString().slice(0,10),count:emps.length,total});
      logAudit('Folha de pagamento','Geração de folha',`${emps.length} funcionários — R$ ${total.toLocaleString('pt-BR',{minimumFractionDigits:2})}`);
      save();renderPayroll();showToast('Folha do mês gerada e enviada à Direção.');
    };
  }

  // ===== Módulos genéricos de RH (Departamento Pessoal, T&D, Clima, Compliance, Ética) =====

  function employeeName(id){return (state.employees||[]).find(e=>e.id===id)?.name||'—';}
  function studentName(id){return (state.students||[]).find(s=>s.id===id)?.name||'—';}
  function badge(value,map){return `<span class="badge ${map[value]||'badge-gray'}">${escapeHtml(value||'-')}</span>`;}

  function fieldHtml(f,item){
    const val = item[f.key] ?? f.default ?? '';
    const cls = f.full ? 'full' : '';
    if (f.type === 'select') {
      return `<div class="${cls}"><label>${f.label}${f.required?' *':''}</label><select id="f_${f.key}" ${f.required?'required':''}>${f.options.map(o=>`<option value="${escapeHtml(o)}" ${String(val)===o?'selected':''}>${escapeHtml(o)}</option>`).join('')}</select></div>`;
    }
    if (f.type === 'textarea') {
      return `<div class="${cls}"><label>${f.label}${f.required?' *':''}</label><textarea id="f_${f.key}" rows="${f.rows||3}" ${f.required?'required':''}>${escapeHtml(val)}</textarea></div>`;
    }
    if (f.type === 'employee') {
      const school = schoolForCurrent();
      const emps = (state.employees||[]).filter(e=>e.schoolId===school?.id);
      return `<div class="${cls}"><label>${f.label}${f.required?' *':''}</label><select id="f_${f.key}" ${f.required?'required':''}><option value="">${f.optional?'— não se aplica / institucional —':'Selecione'}</option>${emps.map(e=>`<option value="${e.id}" ${val===e.id?'selected':''}>${escapeHtml(e.name)}</option>`).join('')}</select></div>`;
    }
    if (f.type === 'student') {
      const school = schoolForCurrent();
      const studs = (state.students||[]).filter(s=>s.schoolId===school?.id);
      return `<div class="${cls}"><label>${f.label}${f.required?' *':''}</label><select id="f_${f.key}" ${f.required?'required':''}><option value="">Selecione</option>${studs.map(s=>`<option value="${s.id}" ${val===s.id?'selected':''}>${escapeHtml(s.name)}</option>`).join('')}</select></div>`;
    }
    if (f.type === 'class') {
      const school = schoolForCurrent();
      const classes = (state.classes||[]).filter(c=>c.schoolId===school?.id);
      return `<div class="${cls}"><label>${f.label}${f.required?' *':''}</label><select id="f_${f.key}" ${f.required?'required':''}><option value="">Selecione</option>${classes.map(c=>`<option value="${c.id}" ${val===c.id?'selected':''}>${escapeHtml(classLabel(c))}</option>`).join('')}</select></div>`;
    }
    if (f.type === 'file') {
      const existing = item[f.key];
      return `<div class="${cls}"><label>${f.label}${f.required?' *':''}</label>
        ${existing?`<div class="file-current"><i class="fa-solid fa-paperclip"></i> <span>${escapeHtml(existing.name)}</span> <small class="muted">(${(existing.size/1024).toFixed(0)} KB)</small> <a href="${existing.dataUrl}" download="${escapeHtml(existing.name)}" class="file-download"><i class="fa-solid fa-download"></i> baixar</a> <label class="file-remove"><input type="checkbox" id="f_${f.key}_remove"> remover anexo</label></div>`:''}
        <input type="file" id="f_${f.key}" accept="${f.accept||'.pdf,.jpg,.jpeg,.png'}" ${f.required&&!existing?'required':''}>
        <small class="muted">${f.hint||'PDF ou imagem, até 4 MB.'}</small></div>`;
    }
    return `<div class="${cls}"><label>${f.label}${f.required?' *':''}</label><input id="f_${f.key}" type="${f.type||'text'}" ${f.step?`step="${f.step}"`:''} ${f.min!==undefined?`min="${f.min}"`:''} ${f.max!==undefined?`max="${f.max}"`:''} value="${escapeHtml(String(val))}" ${f.required?'required':''}></div>`;
  }

  function nextProtocol(prefix,key){
    const y=new Date().getFullYear();
    const n=(state[key]||[]).filter(x=>String(x.protocol||'').startsWith(`${prefix}-${y}-`)).length+124;
    return `${prefix}-${y}-${String(n).padStart(6,'0')}`;
  }
  function scopeRecords(key,list){
    const role=state.role;
    if(key==='announcements'){
      const map={professor:['Toda a escola','Professores'],aluno:['Toda a escola','Alunos'],responsavel:['Toda a escola','Responsáveis']};
      return map[role]?list.filter(x=>map[role].includes(x.audience)):list;
    }
    let kids=null;
    if(role==='aluno'){const k=selectedChild();kids=k?[k]:[];}
    else if(role==='responsavel'){kids=childrenOfGuardian(myGuardianId());}
    else if(role==='professor'){kids=visibleStudents();}
    if(!kids) return list;
    const ids=new Set(kids.map(k=>k.id)),names=new Set(kids.map(k=>k.name));
    if(key==='occurrences') return list.filter(o=>ids.has(o.studentId)||names.has(o.studentName));
    if(key==='studentDocuments'||key==='financeRecords'||key==='healthRecords') return list.filter(x=>ids.has(x.studentId));
    if(key==='serviceRequests') return list.filter(x=>x.createdBy===state.currentUserId||names.has(x.requester));
    return list;
  }
  function renderCrud(cfg){
    const school = schoolForCurrent();
    const moduleKey = PAGE_MODULE_MAP[cfg.key];
    if(moduleKey && !can(moduleKey,'view')){ renderAccessDenied(cfg.title); return; }
    const canCreate = !moduleKey || can(moduleKey,'create');
    const canEdit = !moduleKey || can(moduleKey,'edit');
    const list = scopeRecords(cfg.key,(state[cfg.key]||[]).filter(x=>x.schoolId===school?.id));
    content.innerHTML = `${pageHeader(cfg.title, cfg.desc, school&&canCreate?`<button class="btn-primary" id="crud_new"><i class="fa-solid fa-plus"></i> ${cfg.addLabel}</button>`:'')}${cfg.info?`<div class="alert alert-info">${cfg.info}</div>`:''}<div class="table-card"><div class="table-wrap"><table><thead><tr>${cfg.columns.map(c=>`<th>${c.label}</th>`).join('')}<th>Ação</th></tr></thead><tbody>${list.length?list.map(item=>`<tr>${cfg.columns.map(c=>`<td>${c.render?c.render(item):escapeHtml(String(item[c.field]??'-'))}</td>`).join('')}<td>${canEdit?`<button class="small-button crud-edit" data-id="${item.id}" title="Editar"><i class="fa-solid fa-pen"></i></button>`:'<span class="muted">Somente leitura</span>'}${cfg.extraAction?` <button class="small-button crud-extra" data-id="${item.id}" title="${cfg.extraAction.label}"><i class="fa-solid ${cfg.extraAction.icon}"></i></button>`:''}</td></tr>`).join(''):`<tr><td colspan="${cfg.columns.length+1}" style="text-align:center;padding:30px">${cfg.emptyText}</td></tr>`}</tbody></table></div></div>`;
    document.getElementById('crud_new')?.addEventListener('click',()=>openCrudEditor(cfg));
    document.querySelectorAll('.crud-edit').forEach(b=>b.onclick=()=>openCrudEditor(cfg,b.dataset.id));
    document.querySelectorAll('.crud-extra').forEach(b=>b.onclick=()=>cfg.extraAction.handler((state[cfg.key]||[]).find(x=>x.id===b.dataset.id)));
  }

  function renderAccessDenied(title){
    content.innerHTML=`${pageHeader(title||'Acesso restrito','')}<div class="empty-state"><i class="fa-solid fa-lock" style="font-size:28px;color:var(--muted);margin-bottom:10px;display:block"></i><strong>Seu perfil não tem permissão para visualizar este módulo.</strong><p>Fale com a Direção caso precise de acesso a esta área (Direção → Permissões por Perfil).</p></div>`;
  }

  function logAudit(module,action,summary){
    const school = schoolForCurrent();
    state.auditLog = state.auditLog||[];
    state.auditLog.unshift({id:crypto.randomUUID(),schoolId:school?.id,when:new Date().toISOString(),user:state.user,role:roles[state.role]?.name||state.role,module,action,summary});
    if(state.auditLog.length>300) state.auditLog.length=300;
  }

  function openCrudEditor(cfg,id=null,presets={}){
    const school = schoolForCurrent();
    if (!school) { showToast('Cadastre uma escola primeiro.'); return; }
    const moduleKey = PAGE_MODULE_MAP[cfg.key];
    const action = id ? 'edit' : 'create';
    if(moduleKey && !can(moduleKey,action)){ denyToast(action); return; }
    const item = id ? ((state[cfg.key]||[]).find(x=>x.id===id)||{}) : { ...presets };
    openModal(id?`Alterar ${cfg.singular}`:`Novo(a) ${cfg.singular}`, `<form id="crudForm" class="form-card" style="border:none;padding:0;max-width:none"><div class="form-grid">${cfg.fields.map(f=>fieldHtml(f,item)).join('')}</div><div class="form-actions"><button class="btn-primary">Salvar</button></div></form>`);
    document.getElementById('crudForm').onsubmit = async e => {
      e.preventDefault();
      const data = { schoolId: school.id };
      for (const f of cfg.fields) {
        const el = document.getElementById(`f_${f.key}`);
        if (f.type === 'file') {
          const file = el.files && el.files[0];
          const removeChk = document.getElementById(`f_${f.key}_remove`);
          if (file) {
            if (file.size > 4*1024*1024) { formError(`O arquivo "${file.name}" é muito grande (máximo de 4 MB nesta demonstração).`); return; }
            data[f.key] = await new Promise((resolve,reject)=>{
              const r = new FileReader();
              r.onload = () => resolve({ name:file.name, size:file.size, type:file.type, dataUrl:r.result, uploadedAt:new Date().toISOString(), uploadedBy:state.user });
              r.onerror = () => reject(new Error('Falha ao ler o arquivo'));
              r.readAsDataURL(file);
            });
          } else if (removeChk && removeChk.checked) {
            data[f.key] = null;
          } else {
            data[f.key] = item[f.key] || null;
          }
          if (f.required && !data[f.key]) { formError(`Anexe um arquivo em "${f.label}".`); return; }
          continue;
        }
        data[f.key] = f.type === 'number' ? (Number(el.value)||0) : el.value;
      }
      if (id) { Object.assign(item, data); }
      else { data.id = crypto.randomUUID(); data.createdBy = state.currentUserId; state[cfg.key] = state[cfg.key]||[]; state[cfg.key].push(data); }
      cfg.onSave?.(id?item:data);
      const summary = (id?item:data).name || (id?item:data).title || (id?item:data).protocol || (id?item:data).studentName || ((id?item:data).employeeId&&employeeName((id?item:data).employeeId)) || ((id?item:data).studentId&&studentName((id?item:data).studentId)) || 'Registro';
      logAudit(cfg.title, id?'Alteração':'Criação', summary);
      save(); closeModal(); renderCrud(cfg);
      showToast(cfg.savedMsg || 'Registro salvo.');
    };
  }

  const crudModules = {
    substitutes: {
      key:'substitutes', title:'Banco de Substitutos', addLabel:'Novo substituto', singular:'substituto',
      desc:'Cadastro ágil de professores substitutos para cobrir ausências e licenças médicas sem quebrar o calendário de aulas.',
      emptyText:'Nenhum substituto cadastrado.', savedMsg:'Substituto salvo no banco de talentos.',
      fields:[
        {key:'name',label:'Nome completo',required:true,full:true},
        {key:'subject',label:'Disciplina / área',required:true},
        {key:'phone',label:'Telefone / contato'},
        {key:'availability',label:'Disponibilidade',type:'select',options:['Imediata','A combinar','Apenas manhã','Apenas tarde']},
        {key:'status',label:'Status',type:'select',options:['Disponível','Alocado','Indisponível'],default:'Disponível'}
      ],
      columns:[
        {label:'Nome',field:'name'},{label:'Disciplina',field:'subject'},{label:'Contato',field:'phone'},
        {label:'Disponibilidade',field:'availability'},
        {label:'Status',render:i=>badge(i.status,{'Disponível':'badge-green',Alocado:'badge-blue',Indisponível:'badge-gray'})}
      ]
    },
    benefits: {
      key:'benefits', title:'Benefícios e Bolsas de Estudo', addLabel:'Novo benefício', singular:'benefício',
      desc:'Planos de saúde, vale-transporte, vale-alimentação e bolsas de estudo para filhos de colaboradores.',
      emptyText:'Nenhum benefício cadastrado.', savedMsg:'Benefício salvo.',
      fields:[
        {key:'employeeId',label:'Funcionário',type:'employee',required:true,full:true},
        {key:'type',label:'Tipo de benefício',type:'select',options:['Plano de Saúde','Vale-Transporte','Vale-Alimentação','Bolsa de Estudo (filho)','Outro']},
        {key:'description',label:'Detalhes',type:'textarea',full:true},
        {key:'value',label:'Valor mensal (R$)',type:'number',step:'0.01',min:0},
        {key:'status',label:'Status',type:'select',options:['Ativo','Suspenso'],default:'Ativo'}
      ],
      columns:[
        {label:'Funcionário',render:i=>escapeHtml(employeeName(i.employeeId))},{label:'Benefício',field:'type'},
        {label:'Valor mensal',render:i=>`R$ ${Number(i.value||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}`},
        {label:'Status',render:i=>badge(i.status,{Ativo:'badge-green',Suspenso:'badge-gray'})}
      ]
    },
    leaves: {
      key:'leaves', title:'Afastamentos e Licenças', addLabel:'Novo afastamento', singular:'afastamento',
      desc:'Licença-maternidade, atestados, auxílio-doença e readaptação de função (ex.: professor realocado para a biblioteca).',
      info:'Ao registrar um afastamento "Em andamento", o funcionário é marcado como Afastado. Ao encerrar, ele volta a Ativo automaticamente.',
      emptyText:'Nenhum afastamento registrado.', savedMsg:'Afastamento registrado.',
      fields:[
        {key:'employeeId',label:'Funcionário',type:'employee',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Licença-Maternidade','Licença-Paternidade','Atestado Médico','Auxílio-Doença','Licença Sem Vencimento','Readaptação de Função']},
        {key:'startDate',label:'Início',type:'date',required:true},
        {key:'endDate',label:'Fim previsto',type:'date'},
        {key:'notes',label:'Observações',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Em andamento','Encerrado'],default:'Em andamento'}
      ],
      columns:[
        {label:'Funcionário',render:i=>escapeHtml(employeeName(i.employeeId))},{label:'Tipo',field:'type'},
        {label:'Início',render:i=>formatDate(i.startDate)},{label:'Fim previsto',render:i=>i.endDate?formatDate(i.endDate):'-'},
        {label:'Status',render:i=>badge(i.status,{'Em andamento':'badge-yellow',Encerrado:'badge-gray'})}
      ],
      onSave:(data)=>{
        const emp=(state.employees||[]).find(e=>e.id===data.employeeId);
        if(emp){ if(data.status==='Em andamento') emp.status='Afastado'; else if(emp.status==='Afastado') emp.status='Ativo'; }
      }
    },
    terminations: {
      key:'terminations', title:'Rescisões e Homologações', addLabel:'Nova rescisão', singular:'rescisão',
      desc:'Cálculo de verbas rescisórias e acompanhamento da homologação junto ao sindicato da categoria.',
      info:'Ao salvar, o funcionário selecionado é automaticamente marcado como Desligado.',
      emptyText:'Nenhuma rescisão registrada.', savedMsg:'Rescisão registrada e funcionário desligado.',
      fields:[
        {key:'employeeId',label:'Funcionário',type:'employee',required:true,full:true},
        {key:'date',label:'Data de desligamento',type:'date',required:true,default:new Date().toISOString().slice(0,10)},
        {key:'reason',label:'Motivo',type:'select',options:['Pedido de demissão','Dispensa sem justa causa','Dispensa com justa causa','Término de contrato determinado','Acordo entre as partes']},
        {key:'severance',label:'Verba rescisória estimada (R$)',type:'number',step:'0.01',min:0},
        {key:'status',label:'Status',type:'select',options:['Calculada','Homologada'],default:'Calculada'}
      ],
      columns:[
        {label:'Funcionário',render:i=>escapeHtml(employeeName(i.employeeId))},{label:'Data',render:i=>formatDate(i.date)},
        {label:'Motivo',field:'reason'},{label:'Verba estimada',render:i=>`R$ ${Number(i.severance||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}`},
        {label:'Status',render:i=>badge(i.status,{Calculada:'badge-yellow',Homologada:'badge-green'})}
      ],
      onSave:(data)=>{ const emp=(state.employees||[]).find(e=>e.id===data.employeeId); if(emp) emp.status='Desligado'; }
    },
    trainings: {
      key:'trainings', title:'Treinamentos e Formação Continuada', addLabel:'Novo treinamento', singular:'treinamento',
      desc:'Semanas pedagógicas, capacitação de equipes de frente e incentivo à titulação docente (especialização, mestrado, doutorado).',
      emptyText:'Nenhum treinamento cadastrado.', savedMsg:'Treinamento salvo.',
      fields:[
        {key:'title',label:'Título / evento',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Semana Pedagógica','Capacitação de Equipe de Frente','Incentivo à Titulação','Reciclagem Docente','Outro']},
        {key:'date',label:'Data',type:'date',required:true},
        {key:'participants',label:'Nº de participantes',type:'number',min:0},
        {key:'notes',label:'Observações',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Planejado','Em andamento','Concluído'],default:'Planejado'}
      ],
      columns:[
        {label:'Título',field:'title'},{label:'Tipo',field:'type'},{label:'Data',render:i=>formatDate(i.date)},
        {label:'Participantes',field:'participants'},
        {label:'Status',render:i=>badge(i.status,{Planejado:'badge-blue','Em andamento':'badge-yellow',Concluído:'badge-green'})}
      ]
    },
    evaluations: {
      key:'evaluations', title:'Avaliação de Desempenho (360°)', addLabel:'Nova avaliação', singular:'avaliação',
      desc:'Cruza a visão da coordenação pedagógica, a autoavaliação do professor e o feedback de alunos e pais.',
      emptyText:'Nenhuma avaliação registrada.', savedMsg:'Avaliação registrada.',
      fields:[
        {key:'employeeId',label:'Funcionário',type:'employee',required:true,full:true},
        {key:'period',label:'Período avaliado',required:true},
        {key:'coordScore',label:'Nota da coordenação (0-10)',type:'number',min:0,max:10,step:'0.1'},
        {key:'selfScore',label:'Autoavaliação (0-10)',type:'number',min:0,max:10,step:'0.1'},
        {key:'feedbackScore',label:'Feedback de alunos/pais (0-10)',type:'number',min:0,max:10,step:'0.1'},
        {key:'notes',label:'Observações do PDI',type:'textarea',full:true}
      ],
      columns:[
        {label:'Funcionário',render:i=>escapeHtml(employeeName(i.employeeId))},{label:'Período',field:'period'},
        {label:'Coordenação',field:'coordScore'},{label:'Autoavaliação',field:'selfScore'},{label:'Feedback',field:'feedbackScore'},
        {label:'Média',render:i=>(((Number(i.coordScore)||0)+(Number(i.selfScore)||0)+(Number(i.feedbackScore)||0))/3).toFixed(1)}
      ]
    },
    careerPlans: {
      key:'careerPlans', title:'Plano de Cargos, Carreiras e Salários (PCCS)', addLabel:'Novo registro', singular:'registro de carreira',
      desc:'Progressão vertical por titulação e horizontal por tempo de casa (anuênios e quinquênios).',
      emptyText:'Nenhum registro de carreira cadastrado.', savedMsg:'Plano de carreira atualizado.',
      fields:[
        {key:'employeeId',label:'Funcionário',type:'employee',required:true,full:true},
        {key:'level',label:'Nível / referência atual'},
        {key:'titulacao',label:'Titulação',type:'select',options:['Graduação','Especialização','Mestrado','Doutorado']},
        {key:'tempoCasaAnos',label:'Tempo de casa (anos)',type:'number',min:0},
        {key:'nextProgression',label:'Próxima progressão prevista',full:true},
        {key:'status',label:'Status',type:'select',options:['Em dia','Pendente de análise'],default:'Em dia'}
      ],
      columns:[
        {label:'Funcionário',render:i=>escapeHtml(employeeName(i.employeeId))},{label:'Nível',field:'level'},
        {label:'Titulação',field:'titulacao'},{label:'Tempo de casa',render:i=>`${i.tempoCasaAnos||0} anos`},
        {label:'Status',render:i=>badge(i.status,{'Em dia':'badge-green','Pendente de análise':'badge-yellow'})}
      ]
    },
    climateSurveys: {
      key:'climateSurveys', title:'Pesquisas de Clima Organizacional', addLabel:'Nova pesquisa', singular:'pesquisa de clima',
      desc:'Questionários de satisfação para identificar gargalos de comunicação e insatisfações com a infraestrutura pedagógica.',
      emptyText:'Nenhuma pesquisa registrada.', savedMsg:'Pesquisa de clima registrada.',
      fields:[
        {key:'title',label:'Título da pesquisa',required:true,full:true},
        {key:'date',label:'Data de aplicação',type:'date',required:true},
        {key:'respondents',label:'Nº de respondentes',type:'number',min:0},
        {key:'avgScore',label:'Satisfação média (0-10)',type:'number',min:0,max:10,step:'0.1'},
        {key:'notes',label:'Principais pontos identificados',type:'textarea',full:true}
      ],
      columns:[
        {label:'Título',field:'title'},{label:'Data',render:i=>formatDate(i.date)},{label:'Respondentes',field:'respondents'},
        {label:'Satisfação média',render:i=>{const v=Number(i.avgScore)||0;const cls=v>=7?'badge-green':v>=5?'badge-yellow':'badge-red';return `<span class="badge ${cls}">${escapeHtml(String(i.avgScore??'-'))}</span>`;}}
      ]
    },
    wellbeing: {
      key:'wellbeing', title:'Bem-Estar, Saúde Mental e Endomarketing', addLabel:'Nova ação', singular:'ação de bem-estar',
      desc:'Programas de combate ao burnout, mediação de conflitos complexos e ações de reconhecimento institucional.',
      emptyText:'Nenhuma ação cadastrada.', savedMsg:'Ação registrada.',
      fields:[
        {key:'title',label:'Ação / programa',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Prevenção ao Burnout','Apoio Psicológico','Mediação de Conflito','Endomarketing / Reconhecimento','Outro']},
        {key:'date',label:'Data',type:'date'},
        {key:'notes',label:'Observações',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Planejado','Realizado'],default:'Planejado'}
      ],
      columns:[
        {label:'Ação',field:'title'},{label:'Tipo',field:'type'},{label:'Data',render:i=>i.date?formatDate(i.date):'-'},
        {label:'Status',render:i=>badge(i.status,{Planejado:'badge-blue',Realizado:'badge-green'})}
      ]
    },
    safety: {
      key:'safety', title:'Segurança e Medicina do Trabalho (SST)', addLabel:'Novo registro', singular:'registro de SST',
      desc:'Exames admissionais, periódicos e demissionais, laudos (PGR/LTCAT) e acompanhamento da CIPA.',
      emptyText:'Nenhum registro de SST cadastrado.', savedMsg:'Registro de SST salvo.',
      fields:[
        {key:'employeeId',label:'Funcionário',type:'employee',optional:true,full:true},
        {key:'examType',label:'Tipo',type:'select',options:['Exame Admissional','Exame Periódico','Exame Demissional','Laudo PGR','Laudo LTCAT','Reunião CIPA']},
        {key:'date',label:'Data',type:'date',required:true},
        {key:'dueDate',label:'Validade / próxima data',type:'date'},
        {key:'status',label:'Status',type:'select',options:['Em dia','Vencido','Agendado'],default:'Agendado'}
      ],
      columns:[
        {label:'Funcionário',render:i=>i.employeeId?escapeHtml(employeeName(i.employeeId)):'Institucional'},
        {label:'Tipo',field:'examType'},{label:'Data',render:i=>formatDate(i.date)},
        {label:'Validade',render:i=>i.dueDate?formatDate(i.dueDate):'-'},
        {label:'Status',render:i=>badge(i.status,{'Em dia':'badge-green',Vencido:'badge-red',Agendado:'badge-blue'})}
      ]
    },
    unions: {
      key:'unions', title:'Relações Sindicais e Convenções Coletivas (CCT)', addLabel:'Novo sindicato', singular:'convenção',
      desc:'Negociação, interpretação e aplicação das normas das CCTs junto aos sindicatos de professores e de auxiliares.',
      emptyText:'Nenhuma convenção cadastrada.', savedMsg:'Convenção salva.',
      fields:[
        {key:'name',label:'Sindicato',required:true,full:true},
        {key:'category',label:'Categoria',type:'select',options:['Professores','Auxiliares de Administração Escolar','Outro']},
        {key:'cctValidity',label:'Validade da CCT vigente',type:'date'},
        {key:'notes',label:'Cláusulas relevantes / reajustes',type:'textarea',full:true}
      ],
      columns:[
        {label:'Sindicato',field:'name'},{label:'Categoria',field:'category'},
        {label:'Validade da CCT',render:i=>i.cctValidity?formatDate(i.cctValidity):'-'}
      ]
    },
    lgpd: {
      key:'lgpd', title:'Adequação à LGPD', addLabel:'Novo item', singular:'item de conformidade',
      desc:'Garantia de privacidade e segurança dos dados sensíveis de funcionários, candidatos e suas famílias.',
      emptyText:'Nenhum item de conformidade cadastrado.', savedMsg:'Item de conformidade salvo.',
      fields:[
        {key:'item',label:'Item de conformidade',required:true,full:true},
        {key:'responsible',label:'Responsável'},
        {key:'status',label:'Status',type:'select',options:['Conforme','Em adequação','Pendente'],default:'Pendente'},
        {key:'notes',label:'Observações',type:'textarea',full:true}
      ],
      columns:[
        {label:'Item',field:'item'},{label:'Responsável',field:'responsible'},
        {label:'Status',render:i=>badge(i.status,{Conforme:'badge-green','Em adequação':'badge-yellow',Pendente:'badge-red'})}
      ]
    },
    ethicsCases: {
      key:'ethicsCases', title:'Ouvidoria e Comitê de Ética', addLabel:'Nova apuração', singular:'caso',
      desc:'Apuração sigilosa de denúncias de assédio, discriminação ou condutas inadequadas de funcionários em relação aos alunos.',
      info:'Os detalhes de cada apuração são sigilosos e visíveis apenas ao abrir o registro.',
      emptyText:'Nenhum caso registrado.', savedMsg:'Caso registrado sob sigilo.',
      fields:[
        {key:'protocol',label:'Protocolo (gerado automaticamente se em branco)',full:true},
        {key:'category',label:'Categoria',type:'select',options:['Assédio','Discriminação','Conduta Inadequada com Aluno','Conflito Interpessoal','Outro']},
        {key:'notes',label:'Descrição sigilosa do caso',type:'textarea',required:true,full:true,rows:5},
        {key:'status',label:'Status',type:'select',options:['Em apuração','Concluído','Arquivado'],default:'Em apuração'}
      ],
      columns:[
        {label:'Protocolo',render:i=>escapeHtml(i.protocol||'-')},{label:'Categoria',field:'category'},
        {label:'Status',render:i=>badge(i.status,{'Em apuração':'badge-yellow',Concluído:'badge-green',Arquivado:'badge-gray'})}
      ],
      onSave:(data)=>{ if(!data.protocol){ data.protocol='OUV-'+Date.now().toString().slice(-6); } }
    },
    aeeRecords: {
      key:'aeeRecords', title:'Educação Especial (AEE)', addLabel:'Novo atendimento', singular:'atendimento AEE',
      desc:'Plano de Atendimento Educacional Especializado: necessidades, recursos, profissionais e cronograma. Dado sensível — visível apenas a perfis autorizados.',
      emptyText:'Nenhum atendimento AEE registrado.', savedMsg:'Registro de AEE salvo.',
      fields:[
        {key:'studentId',label:'Aluno',type:'student',required:true,full:true},
        {key:'need',label:'Necessidade educacional',type:'select',options:['Deficiência Intelectual','Deficiência Física','Deficiência Visual','Deficiência Auditiva','TEA (Autismo)','TDAH','Altas Habilidades/Superdotação','Outro']},
        {key:'professional',label:'Profissional responsável'},
        {key:'resources',label:'Recursos utilizados',type:'textarea',full:true},
        {key:'schedule',label:'Cronograma de atendimento'},
        {key:'evolution',label:'Evolução / observações',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Em atendimento','Em avaliação','Encerrado'],default:'Em atendimento'}
      ],
      columns:[
        {label:'Aluno',render:i=>escapeHtml(studentById(i.studentId)?.name||'—')},{label:'Necessidade',field:'need'},
        {label:'Profissional',field:'professional'},{label:'Status',render:i=>badge(i.status,{'Em atendimento':'badge-blue','Em avaliação':'badge-yellow',Encerrado:'badge-gray'})}
      ]
    },
    inventory: {
      key:'inventory', title:'Estoque', addLabel:'Novo item', singular:'item de estoque',
      desc:'Controle de materiais de consumo (separado do patrimônio): entradas, saídas e estoque mínimo.',
      emptyText:'Nenhum item de estoque cadastrado.', savedMsg:'Item de estoque salvo.',
      fields:[
        {key:'name',label:'Produto',required:true,full:true},
        {key:'category',label:'Categoria',type:'select',options:['Material de escritório','Material de limpeza','Material pedagógico','Material de laboratório','Outro']},
        {key:'unit',label:'Unidade',type:'select',options:['un','cx','pct','L','kg']},
        {key:'quantity',label:'Quantidade atual',type:'number',min:0},
        {key:'minQuantity',label:'Estoque mínimo',type:'number',min:0},
        {key:'supplier',label:'Fornecedor'},
        {key:'location',label:'Local de armazenamento'}
      ],
      columns:[
        {label:'Produto',field:'name'},{label:'Categoria',field:'category'},
        {label:'Quantidade',render:i=>`${i.quantity} ${i.unit||''}`},
        {label:'Situação',render:i=>{const low=Number(i.quantity)<Number(i.minQuantity||0);return badge(low?'Abaixo do mínimo':'Regular',{'Abaixo do mínimo':'badge-red',Regular:'badge-green'});}}
      ]
    },
    transportVehicles: {
      key:'transportVehicles', title:'Veículos do Transporte Escolar', addLabel:'Novo veículo', singular:'veículo',
      desc:'Frota utilizada no transporte escolar: placa, capacidade, documentação e manutenção.',
      emptyText:'Nenhum veículo cadastrado.', savedMsg:'Veículo salvo.',
      fields:[
        {key:'plate',label:'Placa',required:true},{key:'model',label:'Modelo'},{key:'capacity',label:'Capacidade (alunos)',type:'number',min:1},
        {key:'docExpiry',label:'Validade da documentação',type:'date'},{key:'lastMaintenance',label:'Última manutenção',type:'date'},
        {key:'status',label:'Situação',type:'select',options:['Em operação','Manutenção','Inativo'],default:'Em operação'}
      ],
      columns:[
        {label:'Placa',field:'plate'},{label:'Modelo',field:'model'},{label:'Capacidade',field:'capacity'},
        {label:'Documentação',render:i=>{if(!i.docExpiry)return '—';const soon=new Date(i.docExpiry)<new Date(Date.now()+30*864e5);return `<span class="${soon?'badge badge-red':''}">${formatDate(i.docExpiry)}${soon?' — vence em breve':''}</span>`;}},
        {label:'Situação',render:i=>badge(i.status,{'Em operação':'badge-green',Manutenção:'badge-yellow',Inativo:'badge-gray'})}
      ]
    },
    transportDrivers: {
      key:'transportDrivers', title:'Motoristas', addLabel:'Novo motorista', singular:'motorista',
      desc:'Condutores responsáveis pelas rotas do transporte escolar.',
      emptyText:'Nenhum motorista cadastrado.', savedMsg:'Motorista salvo.',
      fields:[
        {key:'name',label:'Nome completo',required:true,full:true},{key:'cnh',label:'Nº da CNH'},{key:'cnhExpiry',label:'Validade da CNH',type:'date'},
        {key:'phone',label:'Contato'},{key:'status',label:'Situação',type:'select',options:['Ativo','Afastado','Inativo'],default:'Ativo'}
      ],
      columns:[
        {label:'Nome',field:'name'},{label:'CNH',field:'cnh'},
        {label:'Validade',render:i=>i.cnhExpiry?formatDate(i.cnhExpiry):'—'},{label:'Situação',render:i=>badge(i.status,{Ativo:'badge-green',Afastado:'badge-yellow',Inativo:'badge-gray'})}
      ]
    },
    classCouncils: {
      key:'classCouncils', title:'Conselho de Classe', addLabel:'Novo registro', singular:'reunião de conselho',
      desc:'Reuniões do conselho de classe: pauta, participantes, observações e encaminhamentos por turma/período.',
      emptyText:'Nenhuma reunião registrada.', savedMsg:'Conselho de classe registrado.',
      fields:[
        {key:'classId',label:'Turma',type:'class',required:true,full:true},
        {key:'period',label:'Período',type:'select',options:['1º Bimestre','2º Bimestre','3º Bimestre','4º Bimestre']},
        {key:'date',label:'Data',type:'date',default:new Date().toISOString().slice(0,10)},
        {key:'participants',label:'Participantes'},
        {key:'agenda',label:'Pauta',type:'textarea',full:true},
        {key:'decisions',label:'Encaminhamentos e decisões',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Agendado','Realizado'],default:'Agendado'}
      ],
      columns:[
        {label:'Turma',render:i=>escapeHtml(classLabel(classById(i.classId)))},{label:'Período',field:'period'},{label:'Data',render:i=>formatDate(i.date)},
        {label:'Status',render:i=>badge(i.status,{Agendado:'badge-blue',Realizado:'badge-green'})}
      ]
    },
    publicFunds: {
      key:'publicFunds', title:'Recursos Públicos', addLabel:'Novo recurso', singular:'recurso',
      desc:'Repasses, programas, convênios e recursos próprios recebidos pela escola (PDDE, alimentação, transporte etc.). Não é cobrança de mensalidade — a escola é pública.',
      emptyText:'Nenhum recurso registrado.', savedMsg:'Recurso registrado.',
      fields:[
        {key:'source',label:'Origem',type:'select',options:['Repasse Federal (PDDE)','Repasse Estadual','Repasse Municipal','Alimentação Escolar (PNAE)','Transporte Escolar (PNATE)','Convênio','Recurso Próprio','Projeto/Emenda','Outro']},
        {key:'description',label:'Descrição',full:true},{key:'amount',label:'Valor (R$)',type:'number',min:0,step:'0.01'},
        {key:'receivedDate',label:'Data de recebimento',type:'date'},{key:'status',label:'Status',type:'select',options:['Recebido','Previsto','Em prestação de contas'],default:'Recebido'}
      ],
      columns:[
        {label:'Origem',field:'source'},{label:'Descrição',field:'description'},
        {label:'Valor',render:i=>`R$ ${Number(i.amount||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}`},
        {label:'Status',render:i=>badge(i.status,{Recebido:'badge-green',Previsto:'badge-blue','Em prestação de contas':'badge-yellow'})}
      ]
    },
    publicExpenses: {
      key:'publicExpenses', title:'Despesas Públicas', addLabel:'Nova despesa', singular:'despesa',
      desc:'Execução de despesas da escola pública: material, alimentação, manutenção, equipamentos, serviços e contratos.',
      emptyText:'Nenhuma despesa registrada.', savedMsg:'Despesa registrada.',
      fields:[
        {key:'category',label:'Categoria',type:'select',options:['Material Didático/Escolar','Alimentação Escolar','Manutenção','Equipamentos','Serviços','Transporte','Contratos','Outro']},
        {key:'description',label:'Descrição',full:true},{key:'amount',label:'Valor (R$)',type:'number',min:0,step:'0.01'},
        {key:'supplier',label:'Fornecedor'},{key:'document',label:'Documento/Nota fiscal'},{key:'date',label:'Data',type:'date'},
        {key:'status',label:'Status',type:'select',options:['Pago','Em prestação de contas','Pendente'],default:'Pago'}
      ],
      columns:[
        {label:'Categoria',field:'category'},{label:'Descrição',field:'description'},
        {label:'Valor',render:i=>`R$ ${Number(i.amount||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}`},
        {label:'Status',render:i=>badge(i.status,{Pago:'badge-green','Em prestação de contas':'badge-yellow',Pendente:'badge-red'})}
      ]
    },
    interns: {
      key:'interns', title:'Estagiários e Menores Aprendizes', addLabel:'Novo estagiário', singular:'estagiário',
      desc:'Recrutamento e controle contratual de estudantes de pedagogia e licenciaturas atuando como auxiliares de classe ou monitores.',
      emptyText:'Nenhum estagiário cadastrado.', savedMsg:'Estagiário cadastrado.',
      fields:[
        {key:'name',label:'Nome completo',required:true,full:true},
        {key:'course',label:'Curso'},{key:'institution',label:'Instituição de ensino'},
        {key:'supervisor',label:'Supervisor responsável'},
        {key:'startDate',label:'Início',type:'date'},{key:'endDate',label:'Término previsto',type:'date'},
        {key:'status',label:'Status',type:'select',options:['Ativo','Encerrado'],default:'Ativo'}
      ],
      columns:[
        {label:'Nome',field:'name'},{label:'Curso',field:'course'},{label:'Supervisor',field:'supervisor'},
        {label:'Início',render:i=>i.startDate?formatDate(i.startDate):'-'},
        {label:'Status',render:i=>badge(i.status,{Ativo:'badge-green',Encerrado:'badge-gray'})}
      ]
    },
    occurrences: {
      key:'occurrences', title:'Ocorrências', addLabel:'Nova ocorrência', singular:'ocorrência',
      desc:'Registro de ocorrências de portaria, recepção, sala de aula ou atendimento, com encaminhamento e acompanhamento.',
      emptyText:'Nenhuma ocorrência registrada.', savedMsg:'Ocorrência registrada.',
      fields:[
        {key:'studentName',label:'Aluno envolvido (opcional)',full:true},
        {key:'type',label:'Tipo',type:'select',options:['Portaria','Recepção / Atendimento','Sala de Aula','Comportamental','Disciplinar','Outro']},
        {key:'description',label:'Descrição',type:'textarea',required:true,full:true,rows:4},
        {key:'date',label:'Data',type:'date',default:new Date().toISOString().slice(0,10)},
        {key:'status',label:'Status',type:'select',options:['Em aberto','Encaminhada','Resolvida'],default:'Em aberto'}
      ],
      columns:[
        {label:'Aluno',render:i=>escapeHtml(i.studentName||'-')},{label:'Tipo',field:'type'},{label:'Data',render:i=>i.date?formatDate(i.date):'-'},
        {label:'Status',render:i=>badge(i.status,{'Em aberto':'badge-yellow',Encaminhada:'badge-blue',Resolvida:'badge-green'})}
      ]
    },

    // ===== Ano letivo / Estrutura / Serviços escolares / Financeiro (Direção e Secretarias) =====
    academicPeriods: {
      key:'academicPeriods', title:'Ano Letivo e Períodos', addLabel:'Novo período', singular:'período letivo',
      desc:'Abertura e encerramento do ano letivo, bimestres/trimestres, dias letivos e carga horária.',
      emptyText:'Nenhum período cadastrado.', savedMsg:'Período letivo salvo.',
      fields:[
        {key:'name',label:'Nome (ex.: 2026 — 1º Bimestre)',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Ano Letivo','Bimestre','Trimestre','Semestre']},
        {key:'startDate',label:'Início',type:'date',required:true},
        {key:'endDate',label:'Fim',type:'date',required:true},
        {key:'schoolDays',label:'Dias letivos previstos',type:'number',min:0},
        {key:'status',label:'Status',type:'select',options:['Planejado','Em andamento','Encerrado'],default:'Planejado'}
      ],
      columns:[
        {label:'Nome',field:'name'},{label:'Tipo',field:'type'},{label:'Início',render:i=>formatDate(i.startDate)},
        {label:'Fim',render:i=>formatDate(i.endDate)},{label:'Dias letivos',field:'schoolDays'},
        {label:'Status',render:i=>badge(i.status,{Planejado:'badge-blue','Em andamento':'badge-yellow',Encerrado:'badge-gray'})}
      ]
    },
    enrollmentRequests: {
      key:'enrollmentRequests', title:'Matrículas, Renovações e Transferências', addLabel:'Nova solicitação', singular:'solicitação acadêmica',
      desc:'Fluxo de matrícula inicial, rematrícula, transferência recebida/enviada, trancamento, cancelamento e reativação.',
      emptyText:'Nenhuma solicitação registrada.', savedMsg:'Solicitação acadêmica registrada.',
      fields:[
        {key:'studentName',label:'Aluno',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Matrícula Inicial','Rematrícula','Transferência Recebida','Transferência Enviada','Trancamento','Cancelamento','Reativação','Mudança de Turma','Mudança de Turno']},
        {key:'requestDate',label:'Data da solicitação',type:'date',default:new Date().toISOString().slice(0,10)},
        {key:'notes',label:'Observações',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Em análise','Aprovada','Pendente de documentos','Concluída','Negada'],default:'Em análise'}
      ],
      columns:[
        {label:'Aluno',field:'studentName'},{label:'Tipo',field:'type'},{label:'Data',render:i=>formatDate(i.requestDate)},
        {label:'Status',render:i=>badge(i.status,{'Em análise':'badge-yellow',Aprovada:'badge-blue','Pendente de documentos':'badge-red',Concluída:'badge-green',Negada:'badge-gray'})}
      ],
      onSave:(data)=>{
        if(data.type==='Matrícula Inicial' && data.status==='Concluída' && !data.studentId){
          const student={id:crypto.randomUUID(),schoolId:data.schoolId,name:data.studentName,registration:'ALU-'+Date.now().toString().slice(-6),email:'',classId:null,className:'Sem vínculo'};
          state.students.push(student);
          data.studentId=student.id;
          logAudit('Matrículas','Cadastro automático de aluno',student.name);
        }
      }
    },
    spaces: {
      key:'spaces', title:'Estrutura Física da Instituição', addLabel:'Novo ambiente', singular:'ambiente',
      desc:'Prédios, blocos, salas, laboratórios, biblioteca, quadras e auditórios, com capacidade e recursos disponíveis.',
      emptyText:'Nenhum ambiente cadastrado.', savedMsg:'Ambiente salvo.',
      fields:[
        {key:'name',label:'Nome do ambiente',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Sala de Aula','Laboratório','Biblioteca','Quadra','Auditório','Sala Administrativa','Outro']},
        {key:'capacity',label:'Capacidade',type:'number',min:0},
        {key:'resources',label:'Recursos / equipamentos disponíveis',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Disponível','Em manutenção','Indisponível'],default:'Disponível'}
      ],
      columns:[
        {label:'Nome',field:'name'},{label:'Tipo',field:'type'},{label:'Capacidade',field:'capacity'},
        {label:'Status',render:i=>badge(i.status,{'Disponível':'badge-green','Em manutenção':'badge-yellow',Indisponível:'badge-red'})}
      ]
    },
    assets: {
      key:'assets', title:'Estoque e Patrimônio', addLabel:'Novo item', singular:'item de patrimônio',
      desc:'Equipamentos, inventário, manutenção e controle patrimonial da instituição.',
      emptyText:'Nenhum item cadastrado.', savedMsg:'Item salvo.',
      fields:[
        {key:'name',label:'Item / equipamento',required:true,full:true},
        {key:'category',label:'Categoria',type:'select',options:['Mobiliário','Equipamento de TI','Material Pedagógico','Material de Limpeza','Outro']},
        {key:'quantity',label:'Quantidade',type:'number',min:0},
        {key:'location',label:'Localização'},
        {key:'status',label:'Status',type:'select',options:['Em uso','Em manutenção','Baixado'],default:'Em uso'}
      ],
      columns:[
        {label:'Item',field:'name'},{label:'Categoria',field:'category'},{label:'Quantidade',field:'quantity'},{label:'Localização',field:'location'},
        {label:'Status',render:i=>badge(i.status,{'Em uso':'badge-green','Em manutenção':'badge-yellow',Baixado:'badge-gray'})}
      ]
    },
    library: {
      key:'library', title:'Biblioteca — Acervo e Empréstimos', addLabel:'Novo empréstimo', singular:'empréstimo',
      desc:'Controle de exemplares, empréstimos, devoluções e reservas do acervo da biblioteca.',
      emptyText:'Nenhum empréstimo registrado.', savedMsg:'Registro salvo na biblioteca.',
      fields:[
        {key:'title',label:'Título da obra',required:true,full:true},
        {key:'borrower',label:'Aluno / professor (tomador)'},
        {key:'loanDate',label:'Data do empréstimo',type:'date',default:new Date().toISOString().slice(0,10)},
        {key:'dueDate',label:'Previsão de devolução',type:'date'},
        {key:'status',label:'Status',type:'select',options:['Emprestado','Devolvido','Reservado','Atrasado'],default:'Emprestado'}
      ],
      columns:[
        {label:'Obra',field:'title'},{label:'Tomador',field:'borrower'},{label:'Empréstimo',render:i=>i.loanDate?formatDate(i.loanDate):'-'},
        {label:'Devolução prevista',render:i=>i.dueDate?formatDate(i.dueDate):'-'},
        {label:'Status',render:i=>badge(i.status,{Emprestado:'badge-blue',Devolvido:'badge-green',Reservado:'badge-yellow',Atrasado:'badge-red'})}
      ]
    },
    transportRoutes: {
      key:'transportRoutes', title:'Transporte Escolar', addLabel:'Nova rota', singular:'rota',
      desc:'Rotas, veículos, motoristas, monitores, pontos e alunos atendidos pelo transporte escolar.',
      emptyText:'Nenhuma rota cadastrada.', savedMsg:'Rota salva.',
      fields:[
        {key:'name',label:'Nome da rota',required:true,full:true},
        {key:'vehicle',label:'Veículo'},{key:'driver',label:'Motorista'},{key:'monitor',label:'Monitor'},
        {key:'shift',label:'Turno',type:'select',options:['Manhã','Tarde','Noite','Integral']},
        {key:'studentsCount',label:'Nº de alunos atendidos',type:'number',min:0},
        {key:'status',label:'Status',type:'select',options:['Ativa','Inativa'],default:'Ativa'}
      ],
      columns:[
        {label:'Rota',field:'name'},{label:'Veículo',field:'vehicle'},{label:'Motorista',field:'driver'},
        {label:'Turno',field:'shift'},{label:'Alunos',field:'studentsCount'},
        {label:'Status',render:i=>badge(i.status,{Ativa:'badge-green',Inativa:'badge-gray'})}
      ]
    },
    meals: {
      key:'meals', title:'Alimentação Escolar', addLabel:'Novo cardápio', singular:'cardápio',
      desc:'Cardápios, controle de consumo e restrições alimentares atendidas.',
      emptyText:'Nenhum cardápio cadastrado.', savedMsg:'Cardápio salvo.',
      fields:[
        {key:'title',label:'Cardápio / refeição',required:true,full:true},
        {key:'date',label:'Data',type:'date'},
        {key:'restrictions',label:'Restrições alimentares atendidas',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Planejado','Servido'],default:'Planejado'}
      ],
      columns:[
        {label:'Cardápio',field:'title'},{label:'Data',render:i=>i.date?formatDate(i.date):'-'},
        {label:'Status',render:i=>badge(i.status,{Planejado:'badge-blue',Servido:'badge-green'})}
      ]
    },
    healthRecords: {
      key:'healthRecords', title:'Saúde e Apoio Escolar', addLabel:'Novo registro', singular:'registro de saúde',
      desc:'Contatos de emergência, restrições, registros de atendimento e encaminhamentos de apoio ao aluno.',
      emptyText:'Nenhum registro cadastrado.', savedMsg:'Registro de saúde salvo.',
      fields:[
        {key:'studentId',label:'Aluno',type:'student',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Registro de Atendimento','Encaminhamento','Restrição / Alergia','Contato de Emergência']},
        {key:'description',label:'Descrição',type:'textarea',required:true,full:true},
        {key:'date',label:'Data',type:'date'},
        {key:'status',label:'Status',type:'select',options:['Em aberto','Resolvido'],default:'Em aberto'}
      ],
      columns:[
        {label:'Aluno',render:i=>escapeHtml(studentName(i.studentId))},{label:'Tipo',field:'type'},
        {label:'Data',render:i=>i.date?formatDate(i.date):'-'},
        {label:'Status',render:i=>badge(i.status,{'Em aberto':'badge-yellow',Resolvido:'badge-green'})}
      ]
    },
    financeRecords: {
      key:'financeRecords', title:'Financeiro — Mensalidades e Cobranças', addLabel:'Novo lançamento', singular:'lançamento financeiro',
      desc:'Mensalidades, taxas, bolsas, descontos e controle de inadimplência.',
      emptyText:'Nenhum lançamento cadastrado.', savedMsg:'Lançamento financeiro salvo.',
      fields:[
        {key:'studentId',label:'Aluno',type:'student',required:true,full:true},
        {key:'type',label:'Tipo',type:'select',options:['Mensalidade','Matrícula','Taxa','Material','Outro']},
        {key:'amount',label:'Valor (R$)',type:'number',step:'0.01',min:0},
        {key:'dueDate',label:'Vencimento',type:'date'},
        {key:'status',label:'Status',type:'select',options:['Em aberto','Pago','Atrasado','Negociado'],default:'Em aberto'}
      ],
      columns:[
        {label:'Aluno',render:i=>escapeHtml(studentName(i.studentId))},{label:'Tipo',field:'type'},
        {label:'Valor',render:i=>`R$ ${Number(i.amount||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}`},
        {label:'Vencimento',render:i=>i.dueDate?formatDate(i.dueDate):'-'},
        {label:'Status',render:i=>badge(i.status,{'Em aberto':'badge-blue',Pago:'badge-green',Atrasado:'badge-red',Negociado:'badge-yellow'})}
      ]
    },
    studentDocuments: {
      key:'studentDocuments', title:'Gestão Documental', addLabel:'Novo documento', singular:'documento',
      desc:'Upload e validação de documentos de alunos e responsáveis (RG, CPF, comprovantes, documentos acadêmicos).',
      emptyText:'Nenhum documento cadastrado.', savedMsg:'Documento salvo.',
      fields:[
        {key:'studentId',label:'Aluno',type:'student',required:true,full:true},
        {key:'docType',label:'Tipo de documento',type:'select',options:['RG','CPF','Certidão de Nascimento','Comprovante de Residência','Documento Acadêmico','Documento de Transferência','Outro']},
        {key:'file',label:'Arquivo do documento',type:'file'},
        {key:'notes',label:'Observações',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Pendente','Aprovado','Reprovado'],default:'Pendente'}
      ],
      columns:[
        {label:'Aluno',render:i=>escapeHtml(studentName(i.studentId))},{label:'Tipo de documento',field:'docType'},
        {label:'Arquivo',render:i=>i.file?`<a href="${i.file.dataUrl}" download="${escapeHtml(i.file.name)}"><i class="fa-solid fa-paperclip"></i> ${escapeHtml(i.file.name.length>18?i.file.name.slice(0,16)+'…':i.file.name)}</a>`:'<span class="muted">—</span>'},
        {label:'Status',render:i=>badge(i.status,{Pendente:'badge-yellow',Aprovado:'badge-green',Reprovado:'badge-red'})}
      ]
    },
    contactLogs: {
      key:'contactLogs', title:'Central de Atendimento', addLabel:'Novo registro', singular:'atendimento',
      desc:'Registro de atendimentos presenciais, telefônicos, on-line e encaminhamentos entre setores.',
      emptyText:'Nenhum atendimento registrado.', savedMsg:'Atendimento registrado.',
      fields:[
        {key:'subject',label:'Assunto',required:true,full:true},
        {key:'channel',label:'Canal',type:'select',options:['Presencial','Telefone','On-line / Chat','E-mail']},
        {key:'notes',label:'Observações do atendimento',type:'textarea',full:true},
        {key:'forwardedTo',label:'Encaminhado para (setor)'},
        {key:'status',label:'Status',type:'select',options:['Em atendimento','Concluído','Encaminhado'],default:'Em atendimento'}
      ],
      columns:[
        {label:'Assunto',field:'subject'},{label:'Canal',field:'channel'},{label:'Encaminhado para',render:i=>i.forwardedTo||'-'},
        {label:'Status',render:i=>badge(i.status,{'Em atendimento':'badge-yellow',Concluído:'badge-green',Encaminhado:'badge-blue'})}
      ]
    },
    lessonPlans: {
      key:'lessonPlans', title:'Planejamento de Aulas', addLabel:'Novo plano', singular:'plano de aula',
      desc:'Planos de aula, conteúdos previstos e materiais por turma/disciplina.',
      emptyText:'Nenhum plano cadastrado.', savedMsg:'Plano de aula salvo.',
      fields:[
        {key:'title',label:'Título da aula / unidade',required:true,full:true},
        {key:'subject',label:'Disciplina'},
        {key:'date',label:'Data',type:'date'},
        {key:'content',label:'Conteúdo planejado',type:'textarea',full:true},
        {key:'status',label:'Status',type:'select',options:['Planejado','Ministrado'],default:'Planejado'}
      ],
      columns:[
        {label:'Título',field:'title'},{label:'Disciplina',field:'subject'},{label:'Data',render:i=>i.date?formatDate(i.date):'-'},
        {label:'Status',render:i=>badge(i.status,{Planejado:'badge-blue',Ministrado:'badge-green'})}
      ]
    },
    announcements: {
      key:'announcements', title:'Comunicados e Avisos', addLabel:'Novo comunicado', singular:'comunicado',
      desc:'Comunicados institucionais para professores, alunos e responsáveis, com histórico de envio.',
      emptyText:'Nenhum comunicado publicado.', savedMsg:'Comunicado publicado.',
      fields:[
        {key:'title',label:'Título',required:true,full:true},
        {key:'audience',label:'Público',type:'select',options:['Toda a escola','Professores','Alunos','Responsáveis','Funcionários']},
        {key:'message',label:'Mensagem',type:'textarea',required:true,full:true,rows:4},
        {key:'sendDate',label:'Data de envio',type:'date',default:new Date().toISOString().slice(0,10)},
        {key:'status',label:'Status',type:'select',options:['Rascunho','Enviado'],default:'Enviado'}
      ],
      columns:[
        {label:'Título',field:'title'},{label:'Público',field:'audience'},{label:'Data de envio',render:i=>i.sendDate?formatDate(i.sendDate):'-'},
        {label:'Status',render:i=>badge(i.status,{Rascunho:'badge-gray',Enviado:'badge-green'})}
      ]
    },
    appointments: {
      key:'appointments', title:'Agendamentos', addLabel:'Novo agendamento', singular:'agendamento',
      desc:'Agendamento de atendimentos, reuniões e entrevistas com secretaria, direção ou coordenação.',
      emptyText:'Nenhum agendamento registrado.', savedMsg:'Agendamento registrado.',
      fields:[
        {key:'title',label:'Assunto',required:true,full:true},
        {key:'withWhom',label:'Atendido por',type:'select',options:['Secretaria','Direção','Coordenação Pedagógica']},
        {key:'date',label:'Data',type:'date',required:true},
        {key:'time',label:'Horário (ex.: 14:00)'},
        {key:'status',label:'Status',type:'select',options:['Agendado','Confirmado','Concluído','Cancelado'],default:'Agendado'}
      ],
      columns:[
        {label:'Assunto',field:'title'},{label:'Atendido por',field:'withWhom'},{label:'Data',render:i=>formatDate(i.date)},
        {label:'Horário',field:'time'},{label:'Status',render:i=>badge(i.status,{Agendado:'badge-blue',Confirmado:'badge-yellow',Concluído:'badge-green',Cancelado:'badge-gray'})}
      ]
    },
    serviceRequests: {
      key:'serviceRequests', title:'Solicitações e Protocolos', addLabel:'Nova solicitação', singular:'solicitação',
      desc:'Protocolo de solicitações da comunidade escolar: declarações, históricos, transferências, matrícula e mais.',
      info:'Cada solicitação recebe um número de protocolo automático e segue o fluxo: Aberta → Em análise → Aguardando documento → Em processamento → Concluída/Cancelada.',
      emptyText:'Nenhuma solicitação registrada.', savedMsg:'Solicitação protocolada.',
      fields:[
        {key:'protocol',label:'Protocolo (gerado automaticamente)',full:true},
        {key:'type',label:'Tipo',type:'select',options:['Declaração Escolar','Histórico Escolar','Boletim','Atestado','Transferência','Segunda Via de Documento','Matrícula','Rematrícula','Alteração Cadastral','Revisão de Nota','Aproveitamento de Estudos','Outro']},
        {key:'requester',label:'Solicitante',required:true},
        {key:'priority',label:'Prioridade',type:'select',options:['Normal','Prioritária'],default:'Normal'},
        {key:'dueDate',label:'Prazo',type:'date'},
        {key:'notes',label:'Observações',type:'textarea',full:true},
        {key:'attachment',label:'Anexo (ex.: atestado em PDF)',type:'file',hint:'Anexe aqui o PDF do atestado ou documento, quando houver. Até 4 MB.'},
        {key:'status',label:'Status',type:'select',options:['Aberta','Em análise','Aguardando documento','Em processamento','Concluída','Cancelada'],default:'Aberta'}
      ],
      columns:[
        {label:'Protocolo',render:i=>escapeHtml(i.protocol||'-')},{label:'Tipo',field:'type'},{label:'Solicitante',field:'requester'},
        {label:'Anexo',render:i=>i.attachment?`<a href="${i.attachment.dataUrl}" download="${escapeHtml(i.attachment.name)}" title="Baixar ${escapeHtml(i.attachment.name)}"><i class="fa-solid fa-paperclip"></i> ${escapeHtml(i.attachment.name.length>18?i.attachment.name.slice(0,16)+'…':i.attachment.name)}</a>`:'<span class="muted">—</span>'},
        {label:'Prioridade',render:i=>badge(i.priority,{Normal:'badge-gray',Prioritária:'badge-red'})},
        {label:'Status',render:i=>badge(i.status,{Aberta:'badge-blue','Em análise':'badge-yellow','Aguardando documento':'badge-red','Em processamento':'badge-yellow',Concluída:'badge-green',Cancelada:'badge-gray'})}
      ],
      onSave:(data)=>{ if(!data.protocol){ data.protocol=nextProtocol('ATD','serviceRequests'); } }
    },
    documentIssuances: {
      key:'documentIssuances', title:'Emissão Rápida de Documentos', addLabel:'Emitir documento', singular:'documento emitido',
      desc:'Selecione o aluno e o tipo de documento para gerar e imprimir declarações, atestados, boletins e históricos.',
      emptyText:'Nenhum documento emitido ainda.', savedMsg:'Documento emitido. Use o botão de impressão para visualizar.',
      fields:[
        {key:'studentName',label:'Aluno',required:true,full:true},
        {key:'docType',label:'Tipo de documento',type:'select',options:['Declaração de Matrícula','Declaração de Frequência','Declaração de Escolaridade','Declaração de Conclusão','Atestado','Boletim','Histórico Escolar','Comprovante','Documento de Transferência']},
        {key:'issueDate',label:'Data de emissão',type:'date',default:new Date().toISOString().slice(0,10)},
        {key:'notes',label:'Observações',type:'textarea',full:true},
        {key:'protocol',label:'Protocolo (gerado automaticamente)',full:true}
      ],
      columns:[
        {label:'Protocolo',render:i=>escapeHtml(i.protocol||'-')},{label:'Aluno',field:'studentName'},{label:'Tipo',field:'docType'},
        {label:'Emissão',render:i=>i.issueDate?formatDate(i.issueDate):'-'}
      ],
      onSave:(data)=>{ if(!data.protocol){ data.protocol=nextProtocol('DOC','documentIssuances'); } },
      extraAction:{
        label:'Imprimir / visualizar', icon:'fa-print',
        handler:(item)=>{
          const school=schoolForCurrent();
          openModal('Documento — '+item.docType, `<div class="printable-doc" style="border:1px solid var(--border);padding:24px;border-radius:10px"><h2 style="margin-top:0">${escapeHtml(school?.name||'Escola')}</h2><p><strong>${escapeHtml(item.docType)}</strong></p><p>Protocolo: ${escapeHtml(item.protocol||'-')} • Emitido em: ${item.issueDate?formatDate(item.issueDate):'-'}</p><p>Aluno: ${escapeHtml(item.studentName)}</p><p>${escapeHtml(item.notes||'')}</p><p style="margin-top:40px">Responsável pela emissão: ${escapeHtml(state.user||'-')}</p></div><div class="form-actions"><button class="btn-primary" id="printDocBtn"><i class="fa-solid fa-print"></i> Imprimir</button></div>`);
          document.getElementById('printDocBtn').onclick=()=>window.print();
        }
      }
    }
  };

  function renderAuditLog(){
    const school=schoolForCurrent();
    const logs=(state.auditLog||[]).filter(l=>l.schoolId===school?.id);
    content.innerHTML=`${pageHeader('Auditoria','Registro de quem alterou o quê e quando, em todos os módulos do sistema.')}<div class="table-card"><div class="table-wrap"><table><thead><tr><th>Quando</th><th>Usuário</th><th>Perfil</th><th>Módulo</th><th>Ação</th><th>Registro</th></tr></thead><tbody>${logs.length?logs.map(l=>`<tr><td>${new Date(l.when).toLocaleString('pt-BR')}</td><td>${escapeHtml(l.user||'-')}</td><td>${escapeHtml(l.role||'-')}</td><td>${escapeHtml(l.module||'-')}</td><td>${escapeHtml(l.action||'-')}</td><td>${escapeHtml(String(l.summary||'-'))}</td></tr>`).join(''):'<tr><td colspan="6" style="text-align:center;padding:30px">Nenhuma alteração registrada ainda. Toda criação/edição feita nos módulos de cadastro passa a aparecer aqui.</td></tr>'}</tbody></table></div></div>`;
  }

  const MODULE_LABELS={alunos:'Alunos',responsaveis:'Responsáveis',professores:'Professores',funcionarios:'Funcionários',turmas:'Turmas',matriculas:'Matrículas',diario:'Diário de Classe',frequencia:'Frequência',notas:'Notas',boletim:'Boletim',coordenacao:'Coordenação Pedagógica',ocorrencias:'Ocorrências',documentos:'Documentos',protocolos:'Protocolos/Atendimento',biblioteca:'Biblioteca',transporte:'Transporte',alimentacao:'Alimentação',estoque:'Estoque',patrimonio:'Patrimônio',saude:'Saúde/Apoio',aee:'Educação Especial (AEE)',rh:'Recursos Humanos',vagas:'Vagas',financeiro:'Financeiro',comunicados:'Comunicados',calendario:'Calendário',relatorios:'Relatórios',censo:'Censo Escolar',auditoria:'Auditoria',permissoes:'Permissões',estrutura:'Estrutura/Escola'};
  const ACTION_LABELS={view:'Visualizar',create:'Criar',edit:'Editar',delete:'Excluir',approve:'Aprovar',export:'Exportar'};
  function renderPermissions(){
    state.permissions=state.permissions||seedDefaultPermissions();
    const roleKeys=Object.keys(roles);
    if(!window.__permRole||!roles[window.__permRole]) window.__permRole=roleKeys[0];
    const selected=window.__permRole;
    state.permissions[selected]=state.permissions[selected]||{};
    const actions=Object.keys(ACTION_LABELS);
    content.innerHTML=`${pageHeader('Permissões por Perfil','Defina o que cada perfil pode visualizar, criar, editar, excluir, aprovar ou exportar em cada módulo. Isso controla de verdade o que aparece no menu e nos botões do sistema.')}
      <div class="alert alert-info">Esta matriz é a configuração-mestre de permissões do SIGED. As alterações têm efeito imediato: um item sem "Visualizar" desaparece do menu do perfil, e botões de criar/editar/aprovar/exportar são ocultados ou bloqueados conforme aqui definido.</div>
      <div class="card"><div class="card-title"><div><h3>Perfil</h3><span>Selecione o perfil para editar suas permissões</span></div><select id="permRoleSelect">${roleKeys.map(k=>`<option value="${k}" ${k===selected?'selected':''}>${escapeHtml(roles[k].name)}</option>`).join('')}</select></div>
      <div class="table-wrap"><table><thead><tr><th>Módulo</th>${actions.map(a=>`<th>${ACTION_LABELS[a]}</th>`).join('')}</tr></thead><tbody>${PERMISSION_MODULES.map(m=>`<tr><td><strong>${MODULE_LABELS[m]||m}</strong></td>${actions.map(a=>{const checked=!!state.permissions[selected][m]?.[a];return `<td style="text-align:center"><input type="checkbox" class="perm-check" data-module="${m}" data-action="${a}" ${checked?'checked':''} ${selected==='direcao'?'disabled title="A Direção sempre tem acesso amplo"':''}></td>`;}).join('')}</tr>`).join('')}</tbody></table></div></div>`;
    document.getElementById('permRoleSelect').onchange=e=>{window.__permRole=e.target.value;renderPermissions();};
    document.querySelectorAll('.perm-check').forEach(chk=>chk.onchange=()=>{
      const m=chk.dataset.module, a=chk.dataset.action;
      state.permissions[selected][m]=state.permissions[selected][m]||{};
      state.permissions[selected][m][a]=chk.checked;
      save();
      logAudit('Permissões',chk.checked?'Concedida':'Revogada',`${roles[selected].name} — ${MODULE_LABELS[m]||m} / ${ACTION_LABELS[a]}`);
      showToast('Permissão atualizada. O menu e os botões desse perfil já refletem a mudança.');
      if(state.role===selected) buildMenu();
    });
  }

  function renderQueue(){
    const school=schoolForCurrent();
    const today=new Date().toISOString().slice(0,10);
    const tickets=(state.queueTickets||[]).filter(t=>t.schoolId===school?.id&&t.date===today).sort((a,b)=>a.number-b.number);
    const waiting=tickets.filter(t=>t.status==='Aguardando');
    const current=tickets.find(t=>t.status==='Chamada');
    content.innerHTML=`${pageHeader('Fila de Atendimento','Emissão e chamada de senhas do dia, normais e prioritárias.','<button class="btn-primary" id="newNormal"><i class="fa-solid fa-plus"></i> Senha normal</button> <button class="btn-secondary" id="newPriority"><i class="fa-solid fa-star"></i> Senha prioritária</button>')}
      <div class="stat-grid">${statCard('Aguardando',waiting.length,'fa-hourglass-half')}${statCard('Senha em chamada',current?current.number:'-','fa-bullhorn')}${statCard('Atendidas hoje',tickets.filter(t=>t.status==='Atendida').length,'fa-check')}</div>
      <div class="card"><div class="card-title"><div><h3>Painel de senhas de hoje</h3></div><button class="btn-primary" id="callNext"><i class="fa-solid fa-forward"></i> Chamar próxima</button></div><div class="table-wrap"><table><thead><tr><th>Senha</th><th>Tipo</th><th>Status</th><th>Ação</th></tr></thead><tbody>${tickets.length?tickets.map(t=>`<tr><td><strong>${t.type==='Prioritária'?'P':'N'}${String(t.number).padStart(3,'0')}</strong></td><td>${escapeHtml(t.type)}</td><td>${badge(t.status,{Aguardando:'badge-blue',Chamada:'badge-yellow',Atendida:'badge-green'})}</td><td>${t.status==='Chamada'?`<button class="small-button ticket-done" data-id="${t.id}">Concluir</button>`:'-'}</td></tr>`).join(''):'<tr><td colspan="4" style="text-align:center;padding:30px">Nenhuma senha emitida hoje.</td></tr>'}</tbody></table></div></div>`;
    const nextNumber=()=>(tickets.reduce((a,t)=>Math.max(a,t.number),0)+1);
    document.getElementById('newNormal').onclick=()=>{state.queueTickets=state.queueTickets||[];state.queueTickets.push({id:crypto.randomUUID(),schoolId:school.id,date:today,number:nextNumber(),type:'Normal',status:'Aguardando'});save();renderQueue();showToast('Senha normal emitida.');};
    document.getElementById('newPriority').onclick=()=>{state.queueTickets=state.queueTickets||[];state.queueTickets.push({id:crypto.randomUUID(),schoolId:school.id,date:today,number:nextNumber(),type:'Prioritária',status:'Aguardando'});save();renderQueue();showToast('Senha prioritária emitida.');};
    document.getElementById('callNext').onclick=()=>{
      if(current){showToast('Conclua a senha em chamada antes de chamar a próxima.');return;}
      const priority=waiting.find(t=>t.type==='Prioritária')||waiting[0];
      if(!priority){showToast('Não há senhas aguardando.');return;}
      priority.status='Chamada';save();renderQueue();showToast(`Chamando senha ${priority.type==='Prioritária'?'P':'N'}${String(priority.number).padStart(3,'0')}.`);
    };
    document.querySelectorAll('.ticket-done').forEach(b=>b.onclick=()=>{const t=state.queueTickets.find(x=>x.id===b.dataset.id);if(t){t.status='Atendida';save();renderQueue();showToast('Atendimento concluído.');}});
  }

  function openModal(title,body){document.getElementById('modalTitle').textContent=title;document.getElementById('modalBody').innerHTML=body;document.getElementById('modal').classList.remove('hidden');}
  function closeModal(){document.getElementById('modal').classList.add('hidden');document.getElementById('modalBody').innerHTML='';}
  function showToast(message){const t=document.getElementById('toast');t.textContent=message;t.classList.remove('hidden');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.add('hidden'),3000);}

  // ===== Vida acadêmica integrada (alunos, responsáveis, professores, diário, frequência, notas, boletim) =====
  const PERIODS=['1º Bimestre','2º Bimestre','3º Bimestre','4º Bimestre'];
  const PASS_GRADE=6, RECOVERY_MIN=4, MIN_ATTENDANCE=75;
  const sid=()=>schoolForCurrent()?.id;
  const fmtNum=n=>(n===null||n===undefined||n==='')?'—':Number(n).toFixed(1).replace('.',',');
  const todayIso=()=>new Date().toISOString().slice(0,10);
  const SITUATION_BADGE={Aprovado:'badge-green','Recuperação':'badge-yellow',Reprovado:'badge-red',Pendente:'badge-gray','Em andamento':'badge-blue'};
  const STUDENT_STATUS_BADGE={Ativo:'badge-green',Inativo:'badge-gray',Transferido:'badge-blue',Arquivado:'badge-gray'};
  function classLabel(c){return c?`${c.grade} — Turma ${c.name}`:'Sem turma';}
  function classById(id){return (state.classes||[]).find(c=>c.id===id);}
  function studentById(id){return (state.students||[]).find(s=>s.id===id);}
  function guardianById(id){return (state.guardians||[]).find(g=>g.id===id);}
  function teacherById(id){return (state.teachers||[]).find(t=>t.id===id);}
  function activeStudent(s){return s.status!=='Transferido'&&s.status!=='Inativo'&&s.status!=='Arquivado';}
  function studentsOfClass(classId){return (state.students||[]).filter(s=>s.schoolId===sid()&&s.classId===classId&&activeStudent(s)).sort((a,b)=>a.name.localeCompare(b.name));}
  function myTeacherId(){return state.role==='professor'?currentUser()?.vinculo:null;}
  function myGuardianId(){return state.role==='responsavel'?currentUser()?.vinculo:null;}
  function childrenOfGuardian(gid){return (state.students||[]).filter(s=>s.schoolId===sid()&&(s.guardians||[]).some(g=>g.guardianId===gid));}
  function selectedChild(){
    if(state.role==='aluno') return studentById(currentUser()?.vinculo)||null;
    if(state.role==='responsavel'){
      const kids=childrenOfGuardian(myGuardianId());
      if(!kids.length) return null;
      if(!kids.find(k=>k.id===window.__childId)) window.__childId=kids[0].id;
      return kids.find(k=>k.id===window.__childId);
    }
    return null;
  }
  function childSwitcherHtml(){
    if(state.role!=='responsavel') return '';
    const kids=childrenOfGuardian(myGuardianId());
    if(kids.length<1) return '';
    selectedChild();
    return `<div class="filter-bar"><label for="childSelect"><strong>Aluno(a) selecionado(a):</strong></label><select id="childSelect" aria-label="Selecionar filho">${kids.map(k=>`<option value="${k.id}" ${k.id===window.__childId?'selected':''}>${escapeHtml(k.name)} — ${escapeHtml(classLabel(classById(k.classId)))}</option>`).join('')}</select></div>`;
  }
  function bindChildSwitcher(rerender){document.getElementById('childSelect')?.addEventListener('change',e=>{window.__childId=e.target.value;rerender();});}
  function assignmentsForCurrentUser(){
    const list=(state.teacherAssignments||[]).filter(a=>a.schoolId===sid());
    if(state.role==='professor'){const tid=myTeacherId();return list.filter(a=>a.teacherId===tid);}
    return list;
  }
  function assignmentLabel(a){
    const c=classById(a.classId);const t=teacherById(a.teacherId);
    return `${classLabel(c)} · ${a.subject}${state.role==='professor'?'':' ('+(t?.name||'—')+')'}`;
  }
  function weightsFor(classId,subject){return (state.teacherAssignments||[]).find(a=>a.classId===classId&&a.subject===subject)?.weights;}
  function gradeMedia(g,w){
    w=w||{av1:1,av2:1,trabalho:1};
    let sum=0,ws=0;
    ['av1','av2','trabalho'].forEach(f=>{const v=g[f];if(v!==null&&v!==undefined&&v!==''){const wt=(w[f]??1);sum+=Number(v)*wt;ws+=wt;}});
    if(!ws) return null;
    const base=sum/ws;
    const r=g.recuperacao;
    if(r!==null&&r!==undefined&&r!==''&&Number(r)>base) return (base+Number(r))/2;
    return base;
  }
  function gradeSituation(g,m){
    if(m===null||m===undefined) return 'Pendente';
    if(m>=PASS_GRADE) return 'Aprovado';
    const hasRec=g&&g.recuperacao!==null&&g.recuperacao!==undefined&&g.recuperacao!=='';
    if(hasRec) return 'Reprovado';
    if(m>=RECOVERY_MIN) return 'Recuperação';
    return 'Reprovado';
  }
  function findGrade(classId,subject,period,studentId){return (state.grades||[]).find(g=>g.classId===classId&&g.subject===subject&&g.period===period&&g.studentId===studentId);}
  function periodMedia(studentId,classId,subject,period){const g=findGrade(classId,subject,period,studentId);return g?gradeMedia(g,weightsFor(classId,subject)):null;}
  function finalMedia(studentId,classId,subject){
    const ms=PERIODS.map(p=>periodMedia(studentId,classId,subject,p)).filter(m=>m!==null);
    return ms.length?ms.reduce((a,b)=>a+b,0)/ms.length:null;
  }
  function attendanceStats(studentId,classId,subject){
    const recs=(state.lessonRecords||[]).filter(r=>r.schoolId===sid()&&r.classId===classId&&(!subject||r.subject===subject));
    let total=0,pres=0,fal=0,just=0;
    recs.forEach(r=>{const e=(r.attendance||[]).find(x=>x.studentId===studentId);if(!e)return;total++;if(e.status==='Presente')pres++;else if(e.status==='Falta Justificada')just++;else fal++;});
    const pct=total?Math.round(((pres+just)/total)*1000)/10:null;
    return {total,pres,fal,just,pct};
  }
  function studentOverall(student){
    const c=classById(student.classId);
    if(!c) return {media:null,att:{total:0,pres:0,fal:0,just:0,pct:null},recovery:0};
    const finals=(c.subjects||[]).map(s=>({s:s.name,m:finalMedia(student.id,c.id,s.name)}));
    const ms=finals.filter(x=>x.m!==null).map(x=>x.m);
    return {media:ms.length?ms.reduce((a,b)=>a+b,0)/ms.length:null,att:attendanceStats(student.id,c.id,null),recovery:finals.filter(x=>x.m!==null&&x.m<PASS_GRADE&&x.m>=RECOVERY_MIN).length};
  }
  function riskReasons(student){
    const o=studentOverall(student);const r=[];
    if(o.att.pct!==null&&o.att.pct<MIN_ATTENDANCE) r.push(`Frequência ${String(o.att.pct).replace('.',',')}% (limite ${MIN_ATTENDANCE}%)`);
    if(o.media!==null&&o.media<PASS_GRADE) r.push(`Média geral ${fmtNum(o.media)}`);
    if(o.recovery>=2) r.push(`${o.recovery} disciplinas em recuperação`);
    return r;
  }

  // ----- utilitários de interface -----
  function formError(msg){
    let el=document.getElementById('formError');
    if(!el){const f=document.querySelector('#modalBody form');if(!f)return showToast(msg);el=document.createElement('div');el.id='formError';el.className='alert alert-danger';el.setAttribute('role','alert');f.prepend(el);}
    el.textContent=msg;el.scrollIntoView({block:'nearest'});
  }
  function confirmAction(title,message,onConfirm,confirmLabel='Confirmar'){
    openModal(title,`<p>${message}</p><div class="form-actions"><button type="button" class="btn-secondary" id="cfNo">Cancelar</button> <button type="button" class="btn-primary" id="cfYes">${confirmLabel}</button></div>`);
    document.getElementById('cfNo').onclick=closeModal;
    document.getElementById('cfYes').onclick=()=>{closeModal();onConfirm();};
    document.getElementById('cfNo').focus();
  }
  function notify(type,text,opts={}){
    state.notifications=state.notifications||[];
    state.notifications.unshift({id:crypto.randomUUID(),schoolId:sid(),type,text,studentId:opts.studentId||null,date:new Date().toISOString(),read:false});
    if(state.notifications.length>400) state.notifications.length=400;
  }
  function exportCsv(name,rows){
    const csv=rows.map(r=>r.map(c=>`"${String(c??'').replace(/"/g,'""')}"`).join(';')).join('\n');
    const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),500);
    showToast('Arquivo CSV gerado.');logAudit('Relatórios','Exportação',name);
  }
  function paginate(list,key){
    window.__pg=window.__pg||{};
    const st=window.__pg[key]=window.__pg[key]||{page:1,size:10};
    const pages=Math.max(1,Math.ceil(list.length/st.size));
    if(st.page>pages) st.page=pages;
    return {slice:list.slice((st.page-1)*st.size,st.page*st.size),st,pages,total:list.length};
  }
  function paginationHtml(p,key){
    return `<div class="pagination"><label>Registros por página <select class="pg-size" data-key="${key}">${[10,25,50,100].map(n=>`<option ${n===p.st.size?'selected':''}>${n}</option>`).join('')}</select></label><span>${p.total} registro(s) · página ${p.st.page} de ${p.pages}</span><button type="button" class="small-button pg-prev" data-key="${key}" ${p.st.page<=1?'disabled':''} aria-label="Página anterior"><i class="fa-solid fa-chevron-left"></i></button><button type="button" class="small-button pg-next" data-key="${key}" ${p.st.page>=p.pages?'disabled':''} aria-label="Próxima página"><i class="fa-solid fa-chevron-right"></i></button></div>`;
  }
  function bindPagination(key,rerender){
    document.querySelectorAll(`.pg-size[data-key="${key}"]`).forEach(s=>s.onchange=()=>{window.__pg[key].size=Number(s.value);window.__pg[key].page=1;rerender();});
    document.querySelectorAll(`.pg-prev[data-key="${key}"]`).forEach(b=>b.onclick=()=>{window.__pg[key].page--;rerender();});
    document.querySelectorAll(`.pg-next[data-key="${key}"]`).forEach(b=>b.onclick=()=>{window.__pg[key].page++;rerender();});
  }
  const validCpf=v=>!v||/^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$/.test(v.trim());
  const validEmail=v=>!v||/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
  const validPhone=v=>!v||/^\(?\d{2}\)?\s?9?\d{4}-?\d{4}$/.test(v.trim());
  const maskCpf=v=>v?String(v).replace(/^(\d{3}).?(\d{3}).?(\d{3})-?(\d{2})$/,'***.***.***-$4'):'—';
  function optionsHtml(list,selected,placeholder){return (placeholder!==undefined?`<option value="">${placeholder}</option>`:'')+list.map(o=>{const v=typeof o==='object'?o.value:o;const l=typeof o==='object'?o.label:o;return `<option value="${escapeHtml(v)}" ${String(v)===String(selected)?'selected':''}>${escapeHtml(l)}</option>`;}).join('');}

  // ----- Alunos -----
  function visibleStudents(){
    let list=(state.students||[]).filter(s=>s.schoolId===sid());
    if(state.role==='professor'){
      const classIds=new Set(assignmentsForCurrentUser().map(a=>a.classId));
      list=list.filter(s=>classIds.has(s.classId));
    }
    return list;
  }
  function renderStudents(){
    if(!can('alunos','view')){renderAccessDenied('Alunos');return;}
    window.__stf=window.__stf||{q:'',classId:'',status:''};
    const classes=(state.classes||[]).filter(c=>c.schoolId===sid());
    content.innerHTML=`${pageHeader('Alunos','Cadastro completo, vínculo com responsáveis e turma, situação escolar e acompanhamento.',can('alunos','create')?'<button class="btn-primary" id="newStudent"><i class="fa-solid fa-plus"></i> Novo aluno</button>':'')}
      <div class="filter-bar"><label for="stQ" class="sr-only">Buscar</label><input id="stQ" type="search" placeholder="Buscar por nome, matrícula ou CPF" value="${escapeHtml(window.__stf.q)}"><label for="stClass" class="sr-only">Turma</label><select id="stClass"><option value="">Todas as turmas</option>${classes.map(c=>`<option value="${c.id}" ${window.__stf.classId===c.id?'selected':''}>${escapeHtml(classLabel(c))}</option>`).join('')}</select><label for="stStatus" class="sr-only">Situação</label><select id="stStatus"><option value="">Todas as situações</option>${['Ativo','Inativo','Transferido','Arquivado'].map(s=>`<option ${window.__stf.status===s?'selected':''}>${s}</option>`).join('')}</select><button type="button" class="btn-secondary" id="stClear">Limpar filtros</button></div>
      <div class="table-card"><div id="stTable"></div></div>`;
    const draw=()=>drawStudentsTable();
    document.getElementById('stQ').oninput=e=>{window.__stf.q=e.target.value;if(window.__pg?.students)window.__pg.students.page=1;draw();};
    document.getElementById('stClass').onchange=e=>{window.__stf.classId=e.target.value;draw();};
    document.getElementById('stStatus').onchange=e=>{window.__stf.status=e.target.value;draw();};
    document.getElementById('stClear').onclick=()=>{window.__stf={q:'',classId:'',status:''};renderStudents();};
    document.getElementById('newStudent')?.addEventListener('click',()=>openStudentEditor());
    draw();
  }
  function drawStudentsTable(){
    const f=window.__stf;const q=f.q.trim().toLowerCase();
    let list=visibleStudents();
    if(q) list=list.filter(s=>[s.name,s.socialName,s.registration,s.cpf].some(v=>String(v||'').toLowerCase().includes(q)));
    if(f.classId) list=list.filter(s=>s.classId===f.classId);
    if(f.status) list=list.filter(s=>(s.status||'Ativo')===f.status);
    list.sort((a,b)=>a.name.localeCompare(b.name));
    const p=paginate(list,'students');
    const box=document.getElementById('stTable');
    if(!box) return;
    box.innerHTML=`<div class="table-wrap"><table><thead><tr><th>Aluno</th><th>Matrícula</th><th>Turma</th><th>Frequência</th><th>Média geral</th><th>Situação</th><th>Ações</th></tr></thead><tbody>${p.slice.length?p.slice.map(s=>{const o=studentOverall(s);const attBad=o.att.pct!==null&&o.att.pct<MIN_ATTENDANCE;return `<tr><td><strong>${escapeHtml(s.socialName||s.name)}</strong>${s.socialName?`<br><small class="muted">${escapeHtml(s.name)}</small>`:''}</td><td>${escapeHtml(s.registration||'-')}</td><td>${escapeHtml(classLabel(classById(s.classId)))}</td><td>${o.att.pct===null?'—':`<span class="badge ${attBad?'badge-red':'badge-green'}">${String(o.att.pct).replace('.',',')}%${attBad?' ⚠':''}</span>`}</td><td>${fmtNum(o.media)}</td><td>${badge(s.status||'Ativo',STUDENT_STATUS_BADGE)}</td><td><button type="button" class="small-button st-view" data-id="${s.id}" title="Ver ficha" aria-label="Ver ficha de ${escapeHtml(s.name)}"><i class="fa-solid fa-eye"></i></button> ${can('alunos','edit')?`<button type="button" class="small-button st-edit" data-id="${s.id}" title="Editar" aria-label="Editar ${escapeHtml(s.name)}"><i class="fa-solid fa-pen"></i></button> `:''}${can('boletim','view')?`<button type="button" class="small-button st-card" data-id="${s.id}" title="Boletim" aria-label="Boletim de ${escapeHtml(s.name)}"><i class="fa-solid fa-file-lines"></i></button>`:''}</td></tr>`;}).join(''):`<tr><td colspan="7"><div class="empty-state">Nenhum aluno encontrado.${can('alunos','create')?' <button type="button" class="btn-primary" id="emptyNewStudent">+ Cadastrar aluno</button>':''}</div></td></tr>`}</tbody></table></div>${paginationHtml(p,'students')}`;
    box.querySelectorAll('.st-view').forEach(b=>b.onclick=()=>openStudentView(b.dataset.id));
    box.querySelectorAll('.st-edit').forEach(b=>b.onclick=()=>openStudentEditor(b.dataset.id));
    box.querySelectorAll('.st-card').forEach(b=>b.onclick=()=>{window.__rcStudent=b.dataset.id;const item=(roles[state.role].menu.find(x=>x[1]==='reportCard'));if(item)navigate('reportCard');else renderReportCard();});
    document.getElementById('emptyNewStudent')?.addEventListener('click',()=>openStudentEditor());
    bindPagination('students',drawStudentsTable);
  }
  function openStudentView(id){
    const s=studentById(id);if(!s)return;
    const c=classById(s.classId);
    const gs=(s.guardians||[]).map(g=>({g:guardianById(g.guardianId),k:g.kinship})).filter(x=>x.g);
    const sensitive=can('aee','view');
    const row=(l,v)=>`<div><span>${l}</span><strong>${escapeHtml(v||'—')}</strong></div>`;
    openModal(`Ficha do aluno — ${s.name}`,`<div class="detail-grid">${row('Nome social',s.socialName)}${row('Matrícula',s.registration)}${row('Nascimento',s.birthDate?formatDate(s.birthDate):'')}${row('CPF',can('alunos','edit')?s.cpf:maskCpf(s.cpf))}${row('Sexo',s.gender)}${row('Naturalidade',s.birthplace)}${row('Filiação',[s.mother,s.father].filter(Boolean).join(' / '))}${row('Endereço',[s.street,s.number,s.neighborhood,s.city&&`${s.city}/${s.uf||''}`].filter(Boolean).join(', '))}${row('Contato',[s.cellphone||s.phone,s.email].filter(Boolean).join(' · '))}${row('Turma',classLabel(c))}${row('Turno',c?.shift)}${row('Situação',s.status||'Ativo')}${row('Escola anterior',s.previousSchool)}${row('Data da matrícula',s.enrollmentDate?formatDate(s.enrollmentDate):'')}</div><h4>Responsáveis</h4>${gs.length?`<ul class="plain-list">${gs.map(x=>`<li><strong>${escapeHtml(x.g.name)}</strong> (${escapeHtml(x.k||'Responsável')}) — ${escapeHtml(x.g.phone||'sem telefone')}</li>`).join('')}</ul>`:'<p class="muted">Nenhum responsável vinculado.</p>'}${s.emergencyContact?`<p><strong>Contato de emergência:</strong> ${escapeHtml(s.emergencyContact)}</p>`:''}${s.pickupAuthorized?`<p><strong>Autorizados a retirar:</strong> ${escapeHtml(s.pickupAuthorized)}</p>`:''}${sensitive?`<h4>Dados educacionais (restrito)</h4><p><strong>AEE:</strong> ${s.aee==='Sim'?'Sim':'Não'} ${s.aeeNotes?'— '+escapeHtml(s.aeeNotes):''}</p><p><strong>Observações pedagógicas:</strong> ${escapeHtml(s.pedagogicalNotes||'—')}</p>`:''}<h4>Histórico de alterações</h4>${(s.history||[]).length?`<ul class="plain-list">${s.history.slice().reverse().slice(0,8).map(h=>`<li>${formatDate(h.date)} — ${escapeHtml(h.text)} <small class="muted">(${escapeHtml(h.by||'')})</small></li>`).join('')}</ul>`:'<p class="muted">Sem alterações registradas.</p>'}<div class="form-actions"><button type="button" class="btn-secondary" id="svClose">Fechar</button></div>`);
    document.getElementById('svClose').onclick=closeModal;
  }
  function openStudentEditor(id=null){
    const school=schoolForCurrent();
    if(!school){showToast('Cadastre uma escola primeiro.');return;}
    const action=id?'edit':'create';
    if(!can('alunos',action)){denyToast(action);return;}
    const s=id?studentById(id):{};
    const classes=state.classes.filter(c=>c.schoolId===school.id);
    const guardians=state.guardians.filter(g=>g.schoolId===school.id);
    const gl=(s.guardians||[]);
    const occupancy=c=>{const n=(state.students||[]).filter(x=>x.classId===c.id&&activeStudent(x)&&x.id!==id).length;return `${classLabel(c)} (${n}/${c.vacancies||'?'} alunos)`;};
    const inp=(idn,label,val,extra='')=>`<div><label for="${idn}">${label}</label><input id="${idn}" value="${escapeHtml(val||'')}" ${extra}></div>`;
    const sel=(idn,label,opts,val)=>`<div><label for="${idn}">${label}</label><select id="${idn}">${optionsHtml(opts,val)}</select></div>`;
    const kin=['Mãe','Pai','Avó/Avô','Tio/Tia','Responsável legal','Outro'];
    openModal(id?`Alterar aluno — ${s.name}`:'Novo aluno',`<form id="studentForm" class="form-card" style="border:none;padding:0;max-width:none" novalidate>
      <fieldset><legend>Identificação</legend><div class="form-grid">
        <div class="full"><label for="st_name">Nome completo *</label><input id="st_name" value="${escapeHtml(s.name||'')}" required></div>
        ${inp('st_social','Nome social',s.socialName)}${inp('st_birth','Data de nascimento *',s.birthDate,'type="date"')}
        ${inp('st_cpf','CPF',s.cpf,'placeholder="000.000.000-00"')}${inp('st_rg','RG',s.rg)}
        ${sel('st_gender','Sexo',['','Feminino','Masculino','Outro / não informado'],s.gender)}${inp('st_nat','Nacionalidade',s.nationality||'Brasileira')}
        ${inp('st_birthplace','Naturalidade',s.birthplace)}${inp('st_reg','Matrícula',s.registration,id?'':'placeholder="Gerada automaticamente se vazia"')}
        ${inp('st_mother','Filiação — mãe',s.mother)}${inp('st_father','Filiação — pai',s.father)}
      </div></fieldset>
      <fieldset><legend>Endereço</legend><div class="form-grid">
        ${inp('st_cep','CEP',s.cep,'placeholder="00000-000"')}${inp('st_street','Rua',s.street)}${inp('st_number','Número',s.number)}${inp('st_comp','Complemento',s.complement)}${inp('st_neigh','Bairro',s.neighborhood)}${inp('st_city','Cidade',s.city||school.city)}${inp('st_uf','Estado',s.uf||school.state,'maxlength="2"')}
      </div></fieldset>
      <fieldset><legend>Contatos</legend><div class="form-grid">${inp('st_phone','Telefone',s.phone,'placeholder="(79) 3000-0000"')}${inp('st_cell','Celular',s.cellphone,'placeholder="(79) 99999-0000"')}<div class="full"><label for="st_email">E-mail</label><input id="st_email" type="email" value="${escapeHtml(s.email||'')}"></div></div></fieldset>
      <fieldset><legend>Vida escolar</legend><div class="form-grid">
        <div class="full"><label for="st_class">Turma</label><select id="st_class"><option value="">Sem turma</option>${classes.map(c=>`<option value="${c.id}" ${s.classId===c.id?'selected':''}>${escapeHtml(occupancy(c))}</option>`).join('')}</select></div>
        ${sel('st_status','Situação',['Ativo','Inativo','Transferido','Arquivado'],s.status||'Ativo')}${sel('st_modal','Modalidade',['Regular','EJA','Educação Especial'],s.modality||'Regular')}
        ${inp('st_prev','Escola anterior',s.previousSchool)}${inp('st_enroll','Data da matrícula',s.enrollmentDate||todayIso(),'type="date"')}
      </div></fieldset>
      <fieldset><legend>Responsáveis</legend><div class="form-grid">
        ${sel('st_g1','Responsável 1',[{value:'',label:'— nenhum —'},...guardians.map(g=>({value:g.id,label:g.name}))],gl[0]?.guardianId)}${sel('st_k1','Parentesco 1',kin,gl[0]?.kinship||'Mãe')}
        ${sel('st_g2','Responsável 2',[{value:'',label:'— nenhum —'},...guardians.map(g=>({value:g.id,label:g.name}))],gl[1]?.guardianId)}${sel('st_k2','Parentesco 2',kin,gl[1]?.kinship||'Pai')}
        ${inp('st_emerg','Contato de emergência',s.emergencyContact)}${inp('st_pick','Autorizados a retirar o aluno',s.pickupAuthorized)}
      </div>${guardians.length?'':'<p class="muted">Nenhum responsável cadastrado. Cadastre em Pessoas → Responsáveis.</p>'}</fieldset>
      ${can('aee','view')?`<fieldset><legend>Dados educacionais (restrito)</legend><div class="form-grid">${sel('st_aee','Atendimento Educacional Especializado (AEE)',['Não','Sim'],s.aee||'Não')}<div class="full"><label for="st_aeenotes">Necessidades / acompanhamento</label><textarea id="st_aeenotes" rows="2">${escapeHtml(s.aeeNotes||'')}</textarea></div><div class="full"><label for="st_ped">Observações pedagógicas</label><textarea id="st_ped" rows="2">${escapeHtml(s.pedagogicalNotes||'')}</textarea></div></div></fieldset>`:''}
      <div class="form-actions"><button type="button" class="btn-secondary" id="stCancel">Cancelar</button> <button class="btn-primary">Salvar aluno</button></div></form>`);
    document.getElementById('stCancel').onclick=closeModal;
    document.getElementById('st_name').focus();
    document.getElementById('studentForm').onsubmit=e=>{
      e.preventDefault();
      const v=k=>document.getElementById(k)?.value.trim();
      const data={name:v('st_name'),socialName:v('st_social'),birthDate:v('st_birth'),cpf:v('st_cpf'),rg:v('st_rg'),gender:v('st_gender'),nationality:v('st_nat'),birthplace:v('st_birthplace'),mother:v('st_mother'),father:v('st_father'),cep:v('st_cep'),street:v('st_street'),number:v('st_number'),complement:v('st_comp'),neighborhood:v('st_neigh'),city:v('st_city'),uf:v('st_uf').toUpperCase(),phone:v('st_phone'),cellphone:v('st_cell'),email:v('st_email'),classId:v('st_class')||null,status:v('st_status'),modality:v('st_modal'),previousSchool:v('st_prev'),enrollmentDate:v('st_enroll'),emergencyContact:v('st_emerg'),pickupAuthorized:v('st_pick')};
      if(document.getElementById('st_aee')){data.aee=v('st_aee');data.aeeNotes=v('st_aeenotes');data.pedagogicalNotes=v('st_ped');}
      if(!data.name) return formError('Informe o nome completo do aluno.');
      if(!data.birthDate) return formError('Informe a data de nascimento.');
      if(new Date(data.birthDate)>new Date()) return formError('A data de nascimento não pode ser futura.');
      if(!validCpf(data.cpf)) return formError('CPF em formato inválido. Use 000.000.000-00.');
      if(!validEmail(data.email)) return formError('E-mail inválido.');
      if(!validPhone(data.phone)||!validPhone(data.cellphone)) return formError('Telefone em formato inválido. Ex.: (79) 99999-0000.');
      const others=state.students.filter(x=>x.schoolId===school.id&&x.id!==id);
      const cpfDigits=d=>String(d||'').replace(/\D/g,'');
      if(data.cpf&&others.some(x=>cpfDigits(x.cpf)===cpfDigits(data.cpf))) return formError('Já existe um aluno cadastrado com este CPF.');
      let reg=v('st_reg');
      if(reg&&others.some(x=>x.registration===reg)) return formError('Já existe um aluno com esta matrícula.');
      if(!reg) reg=id?s.registration:'ALU-'+String(2000+state.students.filter(x=>x.schoolId===school.id).length+Math.floor(Math.random()*50));
      data.registration=reg;
      const g1=v('st_g1'),g2=v('st_g2');
      if(g1&&g1===g2) return formError('O mesmo responsável não pode ser informado duas vezes.');
      const newGuardians=[];if(g1)newGuardians.push({guardianId:g1,kinship:v('st_k1')});if(g2)newGuardians.push({guardianId:g2,kinship:v('st_k2')});
      const cls=classById(data.classId);
      if(cls&&data.status==='Ativo'){
        const n=state.students.filter(x=>x.classId===cls.id&&activeStudent(x)&&x.id!==id).length;
        if(n>=(cls.vacancies||Infinity)) return formError(`A turma ${classLabel(cls)} está cheia (${n}/${cls.vacancies}). Escolha outra turma ou amplie as vagas.`);
      }
      data.className=cls?cls.name:'Sem vínculo';
      const now=todayIso();
      if(id){
        const changes=[];
        if((s.classId||null)!==data.classId) changes.push(`Turma: ${classLabel(classById(s.classId))} → ${classLabel(cls)}`);
        if((s.status||'Ativo')!==data.status) changes.push(`Situação: ${s.status||'Ativo'} → ${data.status}`);
        s.history=s.history||[];
        changes.forEach(t=>s.history.push({date:now,text:t,by:state.user}));
        Object.assign(s,data,{guardians:newGuardians});
        logAudit('Alunos','Alteração',`${s.name}${changes.length?' — '+changes.join('; '):''}`);
      } else {
        const ns={id:crypto.randomUUID(),schoolId:school.id,...data,guardians:newGuardians,history:[{date:now,text:`Aluno cadastrado${cls?' na turma '+classLabel(cls):''}`,by:state.user}]};
        state.students.push(ns);
        logAudit('Alunos','Criação',`${ns.name} (${ns.registration})`);
        notify('matricula',`Aluno ${ns.name} cadastrado e vinculado${cls?' à turma '+classLabel(cls):''}.`,{studentId:ns.id});
      }
      save();closeModal();renderStudents();showToast('Aluno salvo. Turma, boletim, portais e relatórios já refletem a alteração.');
    };
  }

  // ----- Responsáveis -----
  function renderGuardians(){
    if(!can('responsaveis','view')){renderAccessDenied('Responsáveis');return;}
    window.__gf=window.__gf||{q:''};
    content.innerHTML=`${pageHeader('Responsáveis','Cadastro de responsáveis e vínculo com um ou mais alunos.',can('responsaveis','create')?'<button class="btn-primary" id="newGuardian"><i class="fa-solid fa-plus"></i> Novo responsável</button>':'')}<div class="filter-bar"><label for="gQ" class="sr-only">Buscar</label><input id="gQ" type="search" placeholder="Buscar por nome, CPF ou aluno" value="${escapeHtml(window.__gf.q)}"><button type="button" class="btn-secondary" id="gClear">Limpar filtros</button></div><div class="table-card"><div id="gTable"></div></div>`;
    const draw=()=>{
      const q=window.__gf.q.trim().toLowerCase();
      let list=(state.guardians||[]).filter(g=>g.schoolId===sid());
      const kidsOf=g=>childrenOfGuardian(g.id);
      if(q) list=list.filter(g=>g.name.toLowerCase().includes(q)||String(g.cpf||'').includes(q)||kidsOf(g).some(k=>k.name.toLowerCase().includes(q)));
      list.sort((a,b)=>a.name.localeCompare(b.name));
      const p=paginate(list,'guardians');
      const canEdit=can('responsaveis','edit');
      document.getElementById('gTable').innerHTML=`<div class="table-wrap"><table><thead><tr><th>Responsável</th><th>CPF</th><th>Contato</th><th>Filhos vinculados</th><th>Situação</th><th>Ação</th></tr></thead><tbody>${p.slice.length?p.slice.map(g=>`<tr><td><strong>${escapeHtml(g.name)}</strong></td><td>${canEdit?escapeHtml(g.cpf||'—'):maskCpf(g.cpf)}</td><td>${escapeHtml(g.phone||'—')}<br><small class="muted">${escapeHtml(g.email||'')}</small></td><td>${kidsOf(g).map(k=>escapeHtml(k.name)+' <small class="muted">('+escapeHtml(k.className||'')+')</small>').join('<br>')||'<span class="muted">Nenhum</span>'}</td><td>${badge(g.status||'Ativo',{Ativo:'badge-green',Inativo:'badge-gray'})}</td><td>${canEdit?`<button type="button" class="small-button g-edit" data-id="${g.id}" aria-label="Editar ${escapeHtml(g.name)}"><i class="fa-solid fa-pen"></i></button>`:'<span class="muted">Somente leitura</span>'}</td></tr>`).join(''):`<tr><td colspan="6"><div class="empty-state">Nenhum responsável encontrado.</div></td></tr>`}</tbody></table></div>${paginationHtml(p,'guardians')}`;
      document.querySelectorAll('.g-edit').forEach(b=>b.onclick=()=>openGuardianEditor(b.dataset.id));
      bindPagination('guardians',draw);
    };
    document.getElementById('gQ').oninput=e=>{window.__gf.q=e.target.value;draw();};
    document.getElementById('gClear').onclick=()=>{window.__gf={q:''};renderGuardians();};
    document.getElementById('newGuardian')?.addEventListener('click',()=>openGuardianEditor());
    draw();
  }
  function openGuardianEditor(id=null){
    const action=id?'edit':'create';
    if(!can('responsaveis',action)){denyToast(action);return;}
    const school=schoolForCurrent();if(!school)return;
    const g=id?guardianById(id):{};
    openModal(id?`Alterar responsável — ${g.name}`:'Novo responsável',`<form id="guardianForm" class="form-card" style="border:none;padding:0;max-width:none" novalidate><div class="form-grid"><div class="full"><label for="g_name">Nome completo *</label><input id="g_name" value="${escapeHtml(g.name||'')}" required></div><div><label for="g_cpf">CPF *</label><input id="g_cpf" value="${escapeHtml(g.cpf||'')}" placeholder="000.000.000-00"></div><div><label for="g_phone">Telefone / celular *</label><input id="g_phone" value="${escapeHtml(g.phone||'')}" placeholder="(79) 99999-0000"></div><div class="full"><label for="g_email">E-mail</label><input id="g_email" type="email" value="${escapeHtml(g.email||'')}"></div><div><label for="g_emerg">Contato de emergência</label><select id="g_emerg">${optionsHtml(['Sim','Não'],g.emergency||'Sim')}</select></div><div><label for="g_pick">Autorizado a retirar o aluno</label><select id="g_pick">${optionsHtml(['Sim','Não'],g.canPickup||'Sim')}</select></div><div><label for="g_status">Situação</label><select id="g_status">${optionsHtml(['Ativo','Inativo'],g.status||'Ativo')}</select></div></div><div class="form-actions"><button type="button" class="btn-secondary" id="gCancel">Cancelar</button> <button class="btn-primary">Salvar responsável</button></div></form>`);
    document.getElementById('gCancel').onclick=closeModal;
    document.getElementById('g_name').focus();
    document.getElementById('guardianForm').onsubmit=e=>{
      e.preventDefault();
      const v=k=>document.getElementById(k).value.trim();
      const data={name:v('g_name'),cpf:v('g_cpf'),phone:v('g_phone'),email:v('g_email'),emergency:v('g_emerg'),canPickup:v('g_pick'),status:v('g_status')};
      if(!data.name) return formError('Informe o nome do responsável.');
      if(!data.cpf) return formError('Informe o CPF do responsável.');
      if(!validCpf(data.cpf)) return formError('CPF em formato inválido. Use 000.000.000-00.');
      if(!data.phone) return formError('Informe um telefone de contato.');
      if(!validPhone(data.phone)) return formError('Telefone em formato inválido. Ex.: (79) 99999-0000.');
      if(!validEmail(data.email)) return formError('E-mail inválido.');
      const dig=d=>String(d||'').replace(/\D/g,'');
      if(state.guardians.some(x=>x.schoolId===school.id&&x.id!==id&&dig(x.cpf)===dig(data.cpf))) return formError('Já existe um responsável com este CPF.');
      if(id){Object.assign(g,data);logAudit('Responsáveis','Alteração',data.name);}
      else{state.guardians.push({id:crypto.randomUUID(),schoolId:school.id,...data});logAudit('Responsáveis','Criação',data.name);}
      save();closeModal();renderGuardians();showToast('Responsável salvo. Vincule-o a um aluno na ficha do aluno.');
    };
  }

  // ----- Professores e distribuição -----
  function renderTeachers(){
    if(!can('professores','view')){renderAccessDenied('Professores');return;}
    const list=(state.teachers||[]).filter(t=>t.schoolId===sid()).sort((a,b)=>a.name.localeCompare(b.name));
    const asg=t=>(state.teacherAssignments||[]).filter(a=>a.teacherId===t.id);
    content.innerHTML=`${pageHeader('Professores','Cadastro funcional, formação, vínculo e turmas/disciplinas atribuídas.',can('professores','create')?'<button class="btn-primary" id="newTeacher"><i class="fa-solid fa-plus"></i> Novo professor</button>':'')}<div class="table-card"><div class="table-wrap"><table><thead><tr><th>Professor</th><th>Matrícula funcional</th><th>Vínculo</th><th>Formação</th><th>Atribuições</th><th>Carga</th><th>Situação</th><th>Ação</th></tr></thead><tbody>${list.length?list.map(t=>{const a=asg(t);const load=a.reduce((x,y)=>x+(Number(y.weeklyClasses)||0),0);return `<tr><td><strong>${escapeHtml(t.name)}</strong><br><small class="muted">${escapeHtml(t.email||'')}</small></td><td>${escapeHtml(t.registration||'—')}</td><td>${escapeHtml(t.bond||'—')}</td><td>${escapeHtml(t.formation||'—')}</td><td>${a.length?a.map(x=>escapeHtml(x.subject)+' · '+escapeHtml(classById(x.classId)?.grade.replace(' do Ensino','')||'')+' '+escapeHtml(classById(x.classId)?.name||'')).join('<br>'):'<span class="muted">Sem atribuição</span>'}</td><td>${load} aulas/sem</td><td>${badge(t.status||'Ativo',{Ativo:'badge-green',Afastado:'badge-yellow',Inativo:'badge-gray'})}</td><td>${can('professores','edit')?`<button type="button" class="small-button t-edit" data-id="${t.id}" aria-label="Editar ${escapeHtml(t.name)}"><i class="fa-solid fa-pen"></i></button>`:'<span class="muted">Somente leitura</span>'}</td></tr>`;}).join(''):'<tr><td colspan="8"><div class="empty-state">Nenhum professor cadastrado.</div></td></tr>'}</tbody></table></div></div>`;
    document.getElementById('newTeacher')?.addEventListener('click',()=>openTeacherEditor());
    document.querySelectorAll('.t-edit').forEach(b=>b.onclick=()=>openTeacherEditor(b.dataset.id));
  }
  function openTeacherEditor(id=null){
    const action=id?'edit':'create';
    if(!can('professores',action)){denyToast(action);return;}
    const school=schoolForCurrent();if(!school)return;
    const t=id?teacherById(id):{};
    const inp=(idn,label,val,extra='')=>`<div><label for="${idn}">${label}</label><input id="${idn}" value="${escapeHtml(val||'')}" ${extra}></div>`;
    openModal(id?`Alterar professor — ${t.name}`:'Novo professor',`<form id="teacherForm" class="form-card" style="border:none;padding:0;max-width:none" novalidate><div class="form-grid"><div class="full"><label for="t_name">Nome completo *</label><input id="t_name" value="${escapeHtml(t.name||'')}" required></div>${inp('t_reg','Matrícula funcional',t.registration,'placeholder="Gerada se vazia"')}${inp('t_cpf','CPF',t.cpf,'placeholder="000.000.000-00"')}${inp('t_email','E-mail institucional',t.email,'type="email"')}${inp('t_phone','Contato',t.phone)}${inp('t_form','Formação',t.formation)}<div><label for="t_bond">Vínculo</label><select id="t_bond">${optionsHtml(['Efetivo','Temporário','Contratado','Substituto','Cedido'],t.bond||'Efetivo')}</select></div>${inp('t_hours','Carga horária contratada (h/sem)',t.contractHours||20,'type="number" min="1" max="60"')}<div><label for="t_status">Situação</label><select id="t_status">${optionsHtml(['Ativo','Afastado','Inativo'],t.status||'Ativo')}</select></div></div><div class="form-actions"><button type="button" class="btn-secondary" id="tCancel">Cancelar</button> <button class="btn-primary">Salvar professor</button></div></form>`);
    document.getElementById('tCancel').onclick=closeModal;document.getElementById('t_name').focus();
    document.getElementById('teacherForm').onsubmit=e=>{
      e.preventDefault();const v=k=>document.getElementById(k).value.trim();
      const data={name:v('t_name'),registration:v('t_reg'),cpf:v('t_cpf'),email:v('t_email'),phone:v('t_phone'),formation:v('t_form'),bond:v('t_bond'),contractHours:Number(v('t_hours'))||0,status:v('t_status')};
      if(!data.name) return formError('Informe o nome do professor.');
      if(!validCpf(data.cpf)) return formError('CPF em formato inválido.');
      if(!validEmail(data.email)) return formError('E-mail inválido.');
      if(!data.registration) data.registration='PROF-'+(1100+state.teachers.length);
      if(state.teachers.some(x=>x.schoolId===school.id&&x.id!==id&&x.registration===data.registration)) return formError('Já existe um professor com esta matrícula funcional.');
      if(id){Object.assign(t,data);logAudit('Professores','Alteração',data.name);}
      else{state.teachers.push({id:crypto.randomUUID(),schoolId:school.id,classId:null,className:'Sem vínculo',...data});logAudit('Professores','Criação',data.name);}
      save();closeModal();renderTeachers();showToast('Professor salvo.');
    };
  }
  function renderAssignments(){
    if(!can('professores','view')){renderAccessDenied('Distribuição de professores');return;}
    const list=(state.teacherAssignments||[]).filter(a=>a.schoolId===sid());
    const canEdit=can('professores','edit');
    content.innerHTML=`${pageHeader('Distribuição de professores','Atribua professor, disciplina e turma. O professor passa a ver a turma no portal e a lançar diário, frequência e notas.',canEdit?'<button class="btn-primary" id="newAsg"><i class="fa-solid fa-plus"></i> Nova atribuição</button>':'')}<div class="table-card"><div class="table-wrap"><table><thead><tr><th>Professor</th><th>Disciplina</th><th>Turma</th><th>Turno</th><th>Aulas semanais</th><th>Ação</th></tr></thead><tbody>${list.length?list.map(a=>{const c=classById(a.classId);return `<tr><td><strong>${escapeHtml(teacherById(a.teacherId)?.name||'—')}</strong></td><td>${escapeHtml(a.subject)}</td><td>${escapeHtml(classLabel(c))}</td><td>${escapeHtml(c?.shift||'—')}</td><td>${a.weeklyClasses}</td><td>${canEdit?`<button type="button" class="small-button asg-del" data-id="${a.id}" aria-label="Remover atribuição"><i class="fa-solid fa-trash"></i></button>`:'—'}</td></tr>`;}).join(''):'<tr><td colspan="6"><div class="empty-state">Nenhuma atribuição cadastrada.</div></td></tr>'}</tbody></table></div></div>`;
    document.getElementById('newAsg')?.addEventListener('click',openAssignmentEditor);
    document.querySelectorAll('.asg-del').forEach(b=>b.onclick=()=>{const a=state.teacherAssignments.find(x=>x.id===b.dataset.id);if(!a)return;confirmAction('Remover atribuição',`Remover ${escapeHtml(a.subject)} de ${escapeHtml(teacherById(a.teacherId)?.name||'')} na turma ${escapeHtml(classLabel(classById(a.classId)))}? Diários e notas já lançados são preservados, mas o professor deixa de vê-los em seu portal.`,()=>{state.teacherAssignments=state.teacherAssignments.filter(x=>x.id!==a.id);logAudit('Distribuição','Remoção',`${a.subject} — ${teacherById(a.teacherId)?.name}`);save();renderAssignments();showToast('Atribuição removida.');},'Remover');});
  }
  function openAssignmentEditor(){
    if(!can('professores','edit')){denyToast('edit');return;}
    const school=schoolForCurrent();
    const teachers=state.teachers.filter(t=>t.schoolId===school.id&&(t.status||'Ativo')==='Ativo');
    const classes=state.classes.filter(c=>c.schoolId===school.id);
    if(!teachers.length||!classes.length){showToast('Cadastre professores e turmas antes de distribuir.');return;}
    const subjOpts=cid=>optionsHtml((classById(cid)?.subjects||[]).map(s=>s.name),'');
    openModal('Nova atribuição',`<form id="asgForm" class="form-card" style="border:none;padding:0;max-width:none" novalidate><div class="form-grid"><div class="full"><label for="a_teacher">Professor *</label><select id="a_teacher">${optionsHtml(teachers.map(t=>({value:t.id,label:t.name})),'')}</select></div><div class="full"><label for="a_class">Turma *</label><select id="a_class">${optionsHtml(classes.map(c=>({value:c.id,label:classLabel(c)+' · '+c.shift})),'')}</select></div><div><label for="a_subject">Disciplina *</label><select id="a_subject">${subjOpts(classes[0].id)}</select></div><div><label for="a_hours">Aulas semanais *</label><input id="a_hours" type="number" min="1" max="10" value="2"></div></div><div class="form-actions"><button type="button" class="btn-secondary" id="aCancel">Cancelar</button> <button class="btn-primary">Atribuir</button></div></form>`);
    document.getElementById('aCancel').onclick=closeModal;
    document.getElementById('a_class').onchange=e=>{document.getElementById('a_subject').innerHTML=subjOpts(e.target.value);};
    document.getElementById('asgForm').onsubmit=e=>{
      e.preventDefault();
      const tid=document.getElementById('a_teacher').value,cid=document.getElementById('a_class').value,subject=document.getElementById('a_subject').value,hours=Number(document.getElementById('a_hours').value);
      if(!subject) return formError('Selecione a disciplina.');
      if(!hours||hours<1) return formError('Informe as aulas semanais.');
      if(state.teacherAssignments.some(a=>a.classId===cid&&a.subject===subject)) return formError(`A disciplina ${subject} já tem professor nesta turma (${teacherById(state.teacherAssignments.find(a=>a.classId===cid&&a.subject===subject).teacherId)?.name}).`);
      const c=classById(cid);
      const sameShiftLoad=state.teacherAssignments.filter(a=>a.teacherId===tid&&classById(a.classId)?.shift===c.shift).reduce((x,y)=>x+y.weeklyClasses,0);
      const maxSlots=timeSlots.length*weekdays.length;
      if(sameShiftLoad+hours>maxSlots) return formError(`Conflito de horário: o professor ficaria com ${sameShiftLoad+hours} aulas no turno ${c.shift}, acima dos ${maxSlots} horários disponíveis na semana.`);
      const total=state.teacherAssignments.filter(a=>a.teacherId===tid).reduce((x,y)=>x+y.weeklyClasses,0)+hours;
      const contract=teacherById(tid)?.contractHours;
      if(contract&&total>contract) return formError(`Carga excede a contratada: ${total} aulas/sem para ${contract}h contratadas.`);
      state.teacherAssignments.push({id:crypto.randomUUID(),schoolId:school.id,teacherId:tid,classId:cid,subject,weeklyClasses:hours,weights:{av1:1,av2:1,trabalho:1}});
      logAudit('Distribuição','Atribuição',`${teacherById(tid)?.name} — ${subject} — ${classLabel(c)}`);
      save();closeModal();renderAssignments();showToast('Atribuição criada. O professor já enxerga a turma no portal.');
    };
  }

  // ----- Diário de classe -----
  function renderDiaryBook(){
    if(!can('diario','view')){renderAccessDenied('Diário de classe');return;}
    const asg=assignmentsForCurrentUser();
    const canEdit=can('diario','create');
    const head=pageHeader('Diário de classe','Registre o conteúdo ministrado e a chamada de cada aula.');
    if(!asg.length){content.innerHTML=`${head}<div class="empty-state">Nenhuma turma/disciplina atribuída${state.role==='professor'?' a você':''}. A Secretaria pode atribuir em Pessoas → Distribuição de professores.</div>`;return;}
    if(!asg.find(a=>a.id===window.__dbAsg)) window.__dbAsg=asg[0].id;
    if(!window.__dbDate) window.__dbDate=todayIso();
    const a=asg.find(x=>x.id===window.__dbAsg);
    const studs=studentsOfClass(a.classId);
    const existing=(state.lessonRecords||[]).find(r=>r.classId===a.classId&&r.subject===a.subject&&r.date===window.__dbDate)||null;
    const statusOf=sId=>existing?.attendance?.find(x=>x.studentId===sId)?.status||'Presente';
    const recs=(state.lessonRecords||[]).filter(r=>r.classId===a.classId&&r.subject===a.subject).sort((x,y)=>y.date.localeCompare(x.date));
    const pct=r=>{const n=(r.attendance||[]).length;const p=(r.attendance||[]).filter(x=>x.status==='Presente'||x.status==='Falta Justificada').length;return n?Math.round(p/n*100):0;};
    content.innerHTML=`${head}<div class="filter-bar"><label for="dbAsg"><strong>Turma / disciplina</strong></label><select id="dbAsg">${asg.map(x=>`<option value="${x.id}" ${x.id===a.id?'selected':''}>${escapeHtml(assignmentLabel(x))}</option>`).join('')}</select><label for="dbDate"><strong>Data</strong></label><input id="dbDate" type="date" value="${window.__dbDate}"></div>
    ${canEdit?`<form id="diaryForm" class="card" novalidate><div class="card-title"><div><h3>${existing?'Aula registrada — editar':'Nova aula'} · ${formatDate(window.__dbDate)}</h3><span>${studs.length} alunos na turma</span></div></div>
      <div class="form-grid"><div class="full"><label for="d_title">Conteúdo ministrado (título) *</label><input id="d_title" value="${escapeHtml(existing?.title||'')}" required></div><div class="full"><label for="d_desc">Descrição</label><textarea id="d_desc" rows="2">${escapeHtml(existing?.description||'')}</textarea></div><div><label for="d_meth">Metodologia</label><input id="d_meth" value="${escapeHtml(existing?.methodology||'')}"></div><div><label for="d_notes">Observações</label><input id="d_notes" value="${escapeHtml(existing?.notes||'')}"></div></div>
      <h4>Chamada</h4><div class="table-wrap"><table><thead><tr><th>Aluno</th><th>Presente</th><th>Falta</th><th>Falta justificada</th></tr></thead><tbody>${studs.length?studs.map(s=>{const st=statusOf(s.id);return `<tr><td>${escapeHtml(s.socialName||s.name)}</td>${['Presente','Falta','Falta Justificada'].map(o=>`<td style="text-align:center"><input type="radio" name="att_${s.id}" value="${o}" ${st===o?'checked':''} aria-label="${o} — ${escapeHtml(s.name)}"></td>`).join('')}</tr>`;}).join(''):'<tr><td colspan="4"><div class="empty-state">Nenhum aluno ativo nesta turma.</div></td></tr>'}</tbody></table></div>
      <div class="form-actions"><button class="btn-primary" ${studs.length?'':'disabled'}>${existing?'Atualizar aula':'Salvar aula'}</button></div></form>`:'<div class="alert alert-info">Seu perfil pode consultar os registros, mas não lançar aulas.</div>'}
    <div class="card"><div class="card-title"><div><h3>Aulas registradas</h3><span>${recs.length} aula(s) · presença média ${recs.length?Math.round(recs.reduce((x,r)=>x+pct(r),0)/recs.length):0}%</span></div></div><div class="table-wrap"><table><thead><tr><th>Data</th><th>Conteúdo</th><th>Presença</th><th>Ação</th></tr></thead><tbody>${recs.length?recs.slice(0,15).map(r=>`<tr><td>${formatDate(r.date)}</td><td>${escapeHtml(r.title)}</td><td>${pct(r)}%</td><td><button type="button" class="small-button dr-view" data-id="${r.id}" aria-label="Ver aula de ${formatDate(r.date)}"><i class="fa-solid fa-eye"></i></button>${canEdit?` <button type="button" class="small-button dr-edit" data-date="${r.date}" aria-label="Editar aula"><i class="fa-solid fa-pen"></i></button>`:''}</td></tr>`).join(''):'<tr><td colspan="4"><div class="empty-state">Nenhuma aula registrada para esta turma/disciplina.</div></td></tr>'}</tbody></table></div></div>`;
    document.getElementById('dbAsg').onchange=e=>{window.__dbAsg=e.target.value;renderDiaryBook();};
    document.getElementById('dbDate').onchange=e=>{window.__dbDate=e.target.value||todayIso();renderDiaryBook();};
    document.querySelectorAll('.dr-edit').forEach(b=>b.onclick=()=>{window.__dbDate=b.dataset.date;renderDiaryBook();});
    document.querySelectorAll('.dr-view').forEach(b=>b.onclick=()=>{
      const r=state.lessonRecords.find(x=>x.id===b.dataset.id);if(!r)return;
      openModal(`Aula de ${formatDate(r.date)} — ${r.subject}`,`<p><strong>Conteúdo:</strong> ${escapeHtml(r.title)}</p><p>${escapeHtml(r.description||'')}</p><p><strong>Metodologia:</strong> ${escapeHtml(r.methodology||'—')}</p><p><strong>Observações:</strong> ${escapeHtml(r.notes||'—')}</p><div class="table-wrap"><table><thead><tr><th>Aluno</th><th>Frequência</th></tr></thead><tbody>${(r.attendance||[]).map(x=>`<tr><td>${escapeHtml(studentById(x.studentId)?.name||'—')}</td><td>${badge(x.status,{Presente:'badge-green',Falta:'badge-red','Falta Justificada':'badge-yellow'})}</td></tr>`).join('')}</tbody></table></div><div class="form-actions"><button type="button" class="btn-secondary" id="drClose">Fechar</button></div>`);
      document.getElementById('drClose').onclick=closeModal;
    });
    document.getElementById('diaryForm')?.addEventListener('submit',ev=>{
      ev.preventDefault();
      const title=document.getElementById('d_title').value.trim();
      if(!title){showToast('Informe o conteúdo ministrado.');document.getElementById('d_title').focus();return;}
      if(window.__dbDate>todayIso()){showToast('Não é possível registrar aula em data futura.');return;}
      const attendance=studs.map(s=>({studentId:s.id,status:document.querySelector(`input[name="att_${s.id}"]:checked`)?.value||'Presente'}));
      const rec=existing||{id:crypto.randomUUID(),schoolId:sid(),classId:a.classId,subject:a.subject,date:window.__dbDate,teacherId:a.teacherId};
      const previous=existing?JSON.parse(JSON.stringify(existing.attendance||[])):[];
      Object.assign(rec,{title,description:document.getElementById('d_desc').value.trim(),methodology:document.getElementById('d_meth').value.trim(),notes:document.getElementById('d_notes').value.trim(),attendance});
      if(!existing) state.lessonRecords.push(rec);
      attendance.forEach(x=>{const before=previous.find(p=>p.studentId===x.studentId)?.status;if(x.status==='Falta'&&before!=='Falta'){const s=studentById(x.studentId);notify('frequencia',`${s?.name} faltou à aula de ${a.subject} em ${formatDate(rec.date)}.`,{studentId:x.studentId});}});
      logAudit('Diário',existing?'Alteração de frequência':'Lançamento de frequência',`${classLabel(classById(a.classId))} · ${a.subject} · ${formatDate(rec.date)} — ${attendance.filter(x=>x.status==='Presente').length} presentes, ${attendance.filter(x=>x.status!=='Presente').length} ausências`);
      save();renderDiaryBook();showToast('Aula salva. Frequência já atualizada nos portais, boletim e relatórios.');
    });
  }

  // ----- Frequência -----
  function renderAttendance(){
    if(!can('frequencia','view')){renderAccessDenied('Frequência');return;}
    const kid=selectedChild();
    if(state.role==='aluno'||state.role==='responsavel'){
      if(!kid){content.innerHTML=`${pageHeader('Frequência','')}<div class="empty-state">Nenhum aluno vinculado a esta conta.</div>`;return;}
      const c=classById(kid.classId);
      const subjects=(c?.subjects||[]).map(s=>s.name);
      const total=attendanceStats(kid.id,kid.classId,null);
      content.innerHTML=`${pageHeader('Frequência',`Acompanhamento de presença de ${escapeHtml(kid.name)}.`)}${childSwitcherHtml()}${total.pct!==null&&total.pct<MIN_ATTENDANCE?`<div class="alert alert-danger" role="alert"><i class="fa-solid fa-triangle-exclamation"></i> <div><strong>Frequência abaixo do esperado:</strong> ${escapeHtml(kid.name)} está com ${String(total.pct).replace('.',',')}% (mínimo de ${MIN_ATTENDANCE}%).</div></div>`:''}<div class="stat-grid">${statCard('Frequência geral',total.pct===null?'—':String(total.pct).replace('.',',')+'%','fa-clipboard-check')}${statCard('Aulas registradas',total.total,'fa-chalkboard')}${statCard('Faltas',total.fal,'fa-user-xmark')}${statCard('Faltas justificadas',total.just,'fa-file-medical')}</div><div class="table-card"><div class="table-wrap"><table><thead><tr><th>Disciplina</th><th>Aulas</th><th>Presenças</th><th>Faltas</th><th>Justificadas</th><th>Frequência</th></tr></thead><tbody>${subjects.map(sn=>{const st=attendanceStats(kid.id,kid.classId,sn);const bad=st.pct!==null&&st.pct<MIN_ATTENDANCE;return `<tr><td>${escapeHtml(sn)}</td><td>${st.total}</td><td>${st.pres}</td><td>${st.fal}</td><td>${st.just}</td><td>${st.pct===null?'—':`<span class="badge ${bad?'badge-red':'badge-green'}">${String(st.pct).replace('.',',')}%${bad?' — abaixo do limite':''}</span>`}</td></tr>`;}).join('')}</tbody></table></div></div>`;
      bindChildSwitcher(renderAttendance);
      return;
    }
    const asg=assignmentsForCurrentUser();
    const classes=state.role==='professor'?[...new Set(asg.map(a=>a.classId))].map(classById).filter(Boolean):(state.classes||[]).filter(c=>c.schoolId===sid());
    if(!classes.length){content.innerHTML=`${pageHeader('Frequência','')}<div class="empty-state">Nenhuma turma disponível.</div>`;return;}
    window.__af=window.__af||{classId:'',subject:'',onlyLow:false,q:''};
    if(!classes.find(c=>c.id===window.__af.classId)) window.__af.classId=classes[0].id;
    const f=window.__af;
    const subjectsAll=state.role==='professor'?asg.filter(a=>a.classId===f.classId).map(a=>a.subject):(classById(f.classId)?.subjects||[]).map(s=>s.name);
    if(f.subject&&!subjectsAll.includes(f.subject)) f.subject='';
    content.innerHTML=`${pageHeader('Frequência','Percentual de presença por aluno, calculado a partir das chamadas registradas no diário.',`<button type="button" class="btn-secondary" id="atPrint"><i class="fa-solid fa-print"></i> Imprimir relatório</button>${can('frequencia','export')?' <button type="button" class="btn-secondary" id="atCsv"><i class="fa-solid fa-file-csv"></i> Exportar CSV</button>':''}`)}
    <div class="filter-bar"><label for="atClass" class="sr-only">Turma</label><select id="atClass">${classes.map(c=>`<option value="${c.id}" ${c.id===f.classId?'selected':''}>${escapeHtml(classLabel(c))}</option>`).join('')}</select><label for="atSubj" class="sr-only">Disciplina</label><select id="atSubj"><option value="">Todas as disciplinas</option>${subjectsAll.map(s=>`<option ${s===f.subject?'selected':''}>${escapeHtml(s)}</option>`).join('')}</select><label for="atQ" class="sr-only">Aluno</label><input id="atQ" type="search" placeholder="Filtrar aluno" value="${escapeHtml(f.q)}"><label><input type="checkbox" id="atLow" ${f.onlyLow?'checked':''}> Somente abaixo do limite</label><button type="button" class="btn-secondary" id="atClear">Limpar filtros</button></div>
    <div id="atTable" class="table-card printable-area"></div>`;
    const rows=()=>{
      let list=studentsOfClass(f.classId).map(s=>({s,st:attendanceStats(s.id,f.classId,f.subject||null)}));
      if(f.q.trim()) list=list.filter(x=>x.s.name.toLowerCase().includes(f.q.trim().toLowerCase()));
      if(f.onlyLow) list=list.filter(x=>x.st.pct!==null&&x.st.pct<MIN_ATTENDANCE);
      return list;
    };
    const draw=()=>{
      const list=rows();
      const low=list.filter(x=>x.st.pct!==null&&x.st.pct<MIN_ATTENDANCE).length;
      document.getElementById('atTable').innerHTML=`${low?`<div class="alert alert-danger" role="alert"><i class="fa-solid fa-triangle-exclamation"></i> <div><strong>Frequência abaixo do limite:</strong> ${low} aluno(s) em acompanhamento (mínimo ${MIN_ATTENDANCE}%).</div></div>`:''}<div class="table-wrap"><table><thead><tr><th>Aluno</th><th>Aulas</th><th>Presenças</th><th>Faltas</th><th>Justificadas</th><th>Frequência</th><th>Situação</th></tr></thead><tbody>${list.length?list.map(x=>{const bad=x.st.pct!==null&&x.st.pct<MIN_ATTENDANCE;return `<tr><td>${escapeHtml(x.s.name)}</td><td>${x.st.total}</td><td>${x.st.pres}</td><td>${x.st.fal}</td><td>${x.st.just}</td><td>${x.st.pct===null?'—':String(x.st.pct).replace('.',',')+'%'}</td><td>${x.st.pct===null?badge('Sem registros',{}):bad?badge('Em acompanhamento',{'Em acompanhamento':'badge-red'}):badge('Regular',{Regular:'badge-green'})}</td></tr>`;}).join(''):'<tr><td colspan="7"><div class="empty-state">Nenhum aluno encontrado para os filtros.</div></td></tr>'}</tbody></table></div>`;
    };
    document.getElementById('atClass').onchange=e=>{f.classId=e.target.value;f.subject='';renderAttendance();};
    document.getElementById('atSubj').onchange=e=>{f.subject=e.target.value;draw();};
    document.getElementById('atQ').oninput=e=>{f.q=e.target.value;draw();};
    document.getElementById('atLow').onchange=e=>{f.onlyLow=e.target.checked;draw();};
    document.getElementById('atClear').onclick=()=>{window.__af={classId:f.classId,subject:'',onlyLow:false,q:''};renderAttendance();};
    document.getElementById('atPrint').onclick=()=>printArea();
    document.getElementById('atCsv')?.addEventListener('click',()=>exportCsv(`frequencia_${classById(f.classId)?.name||'turma'}.csv`,[['Aluno','Aulas','Presenças','Faltas','Justificadas','Frequência %'],...rows().map(x=>[x.s.name,x.st.total,x.st.pres,x.st.fal,x.st.just,x.st.pct??''])]));
    draw();
  }
  function printArea(){document.body.classList.add('print-area');window.print();setTimeout(()=>document.body.classList.remove('print-area'),500);}

  // ----- Notas (diário de notas) -----
  function renderGradebook(){
    if(!can('notas','view')){renderAccessDenied('Notas');return;}
    const asg=assignmentsForCurrentUser();
    const canEdit=can('notas','edit');
    const head=pageHeader('Notas','Lançamento de avaliações por turma, disciplina e período. A média é calculada automaticamente.');
    if(!asg.length){content.innerHTML=`${head}<div class="empty-state">Nenhuma turma/disciplina atribuída${state.role==='professor'?' a você':''}. A Secretaria pode atribuir em Pessoas → Distribuição de professores.</div>`;return;}
    if(!asg.find(a=>a.id===window.__gbAsg)) window.__gbAsg=asg[0].id;
    if(!PERIODS.includes(window.__gbPeriod)) window.__gbPeriod=PERIODS[0];
    const a=asg.find(x=>x.id===window.__gbAsg),period=window.__gbPeriod;
    a.weights=a.weights||{av1:1,av2:1,trabalho:1};
    const studs=studentsOfClass(a.classId);
    const FIELDS=[['av1','Avaliação 1'],['av2','Avaliação 2'],['trabalho','Trabalho'],['recuperacao','Recuperação']];
    const inputs=(s,g)=>FIELDS.map(([f,l])=>`<td><input type="number" class="gb-in" min="0" max="10" step="0.1" data-s="${s.id}" data-f="${f}" value="${g[f]??''}" ${canEdit?'':'disabled'} aria-label="${l} de ${escapeHtml(s.name)}"></td>`).join('');
    content.innerHTML=`${head}<div class="filter-bar"><label for="gbAsg"><strong>Turma / disciplina</strong></label><select id="gbAsg">${asg.map(x=>`<option value="${x.id}" ${x.id===a.id?'selected':''}>${escapeHtml(assignmentLabel(x))}</option>`).join('')}</select><label for="gbPer"><strong>Período</strong></label><select id="gbPer">${PERIODS.map(p=>`<option ${p===period?'selected':''}>${p}</option>`).join('')}</select></div>
    <div class="card"><div class="card-title"><div><h3>Pesos das avaliações</h3><span>Média ponderada de Avaliação 1, Avaliação 2 e Trabalho. Com recuperação, a nova média é (média + recuperação) ÷ 2 quando maior. Aprovado ≥ ${PASS_GRADE}; recuperação entre ${RECOVERY_MIN} e ${PASS_GRADE-0.1}; reprovado abaixo de ${RECOVERY_MIN}.</span></div></div><div class="filter-bar">${[['av1','Peso Av. 1'],['av2','Peso Av. 2'],['trabalho','Peso Trabalho']].map(([k,l])=>`<label for="w_${k}">${l}</label><input id="w_${k}" class="w-in" data-k="${k}" type="number" min="0" max="10" step="0.5" value="${a.weights[k]}" style="width:80px" ${canEdit?'':'disabled'}>`).join('')}</div></div>
    <div class="table-card"><div class="table-wrap"><table><thead><tr><th>Aluno</th>${FIELDS.map(([,l])=>`<th>${l}</th>`).join('')}<th>Média</th><th>Situação</th></tr></thead><tbody>${studs.length?studs.map(s=>{const g=findGrade(a.classId,a.subject,period,s.id)||{};const m=gradeMedia(g,a.weights);const sit=gradeSituation(g,m);return `<tr data-row="${s.id}"><td>${escapeHtml(s.name)}</td>${inputs(s,g)}<td class="gb-media">${fmtNum(m)}</td><td class="gb-sit">${badge(sit,SITUATION_BADGE)}</td></tr>`;}).join(''):'<tr><td colspan="7"><div class="empty-state">Nenhum aluno ativo nesta turma.</div></td></tr>'}</tbody></table></div></div>
    ${canEdit&&studs.length?'<div class="form-actions"><button type="button" class="btn-primary" id="gbSave"><i class="fa-solid fa-floppy-disk"></i> Salvar notas</button></div>':''}`;
    document.getElementById('gbAsg').onchange=e=>{window.__gbAsg=e.target.value;renderGradebook();};
    document.getElementById('gbPer').onchange=e=>{window.__gbPeriod=e.target.value;renderGradebook();};
    document.querySelectorAll('.w-in').forEach(i=>i.onchange=()=>{const v=Number(i.value);if(isNaN(v)||v<0||v>10){showToast('Peso inválido (0 a 10).');i.value=a.weights[i.dataset.k];return;}a.weights[i.dataset.k]=v;logAudit('Notas','Alteração de pesos',`${assignmentLabel(a)} — ${i.dataset.k}=${v}`);save();renderGradebook();});
    const collect=s=>{const o={};FIELDS.forEach(([f])=>{const el=document.querySelector(`.gb-in[data-s="${s}"][data-f="${f}"]`);o[f]=el.value===''?null:Number(el.value);});return o;};
    const refreshRow=sId=>{const row=document.querySelector(`tr[data-row="${sId}"]`);const g=collect(sId);const m=gradeMedia(g,a.weights);row.querySelector('.gb-media').textContent=fmtNum(m);row.querySelector('.gb-sit').innerHTML=badge(gradeSituation(g,m),SITUATION_BADGE);};
    document.querySelectorAll('.gb-in').forEach(i=>i.oninput=()=>{const v=i.value;const bad=v!==''&&(isNaN(Number(v))||Number(v)<0||Number(v)>10);i.classList.toggle('invalid',bad);i.setAttribute('aria-invalid',bad?'true':'false');if(!bad)refreshRow(i.dataset.s);});
    document.getElementById('gbSave')?.addEventListener('click',()=>{
      if(document.querySelector('.gb-in.invalid')){showToast('Existem notas inválidas. Use valores entre 0 e 10.');return;}
      const changes=[];
      studs.forEach(s=>{const now=collect(s.id);const old=findGrade(a.classId,a.subject,period,s.id)||{};FIELDS.forEach(([f,l])=>{const from=old[f]??null;if(from!==now[f])changes.push({s,f,l,from,to:now[f]});});});
      if(!changes.length){showToast('Nenhuma alteração para salvar.');return;}
      const apply=()=>{
        const stamp=new Date().toISOString();
        studs.forEach(s=>{
          const now=collect(s.id);let g=findGrade(a.classId,a.subject,period,s.id);
          const diff=changes.filter(c=>c.s.id===s.id);if(!diff.length)return;
          if(!g){g={id:crypto.randomUUID(),schoolId:sid(),classId:a.classId,subject:a.subject,period,studentId:s.id,av1:null,av2:null,trabalho:null,recuperacao:null,history:[]};state.grades.push(g);}
          g.history=g.history||[];
          diff.forEach(c=>g.history.push({date:stamp,by:state.user,field:c.f,from:c.from,to:c.to}));
          Object.assign(g,now);
          notify('nota',`Nova nota lançada em ${a.subject} (${period}) para ${s.name}.`,{studentId:s.id});
        });
        changes.slice(0,25).forEach(c=>logAudit('Notas',c.from!==null?'Alteração de nota':'Lançamento de nota',`${c.s.name} — ${a.subject} (${period}) — ${c.l}: ${fmtNum(c.from)} → ${fmtNum(c.to)}`));
        save();renderGradebook();showToast(`${changes.length} nota(s) salva(s). Boletim e portais atualizados.`);
      };
      const overwrites=changes.filter(c=>c.from!==null);
      if(overwrites.length) confirmAction('Confirmar alteração de notas',`Você está alterando ${overwrites.length} nota(s) já lançada(s). O histórico da alteração será registrado na auditoria. Deseja continuar?`,apply,'Alterar notas'); else apply();
    });
  }

  // ----- Boletim -----
  function reportCardStudent(){
    const kid=selectedChild();if(kid) return kid;
    if(state.role==='aluno'||state.role==='responsavel') return null;
    const list=visibleStudents().filter(activeStudent).sort((a,b)=>a.name.localeCompare(b.name));
    if(window.__rcStudent&&list.find(s=>s.id===window.__rcStudent)) return studentById(window.__rcStudent);
    window.__rcStudent=list[0]?.id;return studentById(window.__rcStudent)||null;
  }
  function renderReportCard(){
    if(!can('boletim','view')){renderAccessDenied('Boletim');return;}
    const staff=state.role!=='aluno'&&state.role!=='responsavel';
    const s=reportCardStudent();
    const school=schoolForCurrent();
    let picker='';
    if(staff){
      const list=visibleStudents().filter(activeStudent).sort((a,b)=>a.name.localeCompare(b.name));
      picker=`<div class="filter-bar"><label for="rcStudent"><strong>Aluno</strong></label><select id="rcStudent">${list.map(x=>`<option value="${x.id}" ${s&&x.id===s.id?'selected':''}>${escapeHtml(x.name)} — ${escapeHtml(classLabel(classById(x.classId)))}</option>`).join('')}</select></div>`;
    } else picker=childSwitcherHtml();
    const head=pageHeader('Boletim escolar','Notas por período, frequência e resultado por disciplina.','<button type="button" class="btn-secondary" id="rcPrint"><i class="fa-solid fa-print"></i> Imprimir boletim</button>');
    if(!s){content.innerHTML=`${head}${picker}<div class="empty-state">Nenhum aluno disponível para exibir o boletim.</div>`;return;}
    const c=classById(s.classId);
    const subjects=(c?.subjects||[]).map(x=>x.name);
    let anyReprov=false,anyRec=false,allDone=subjects.length>0;
    const rows=subjects.map(sn=>{
      const ms=PERIODS.map(p=>periodMedia(s.id,c.id,sn,p));
      const fm=finalMedia(s.id,c.id,sn);
      const filled=ms.filter(m=>m!==null).length;
      const att=attendanceStats(s.id,c.id,sn);
      let sit='Em andamento';
      if(filled===4){const last=findGrade(c.id,sn,PERIODS[3],s.id);sit=gradeSituation(last,fm);} else allDone=false;
      if(sit==='Reprovado')anyReprov=true;if(sit==='Recuperação')anyRec=true;
      if(filled<4&&fm!==null&&fm<RECOVERY_MIN)sit='Recuperação';
      return `<tr><td>${escapeHtml(sn)}</td>${ms.map(m=>`<td>${fmtNum(m)}</td>`).join('')}<td><strong>${fmtNum(fm)}</strong></td><td>${att.pct===null?'—':String(att.pct).replace('.',',')+'%'}</td><td>${badge(sit,SITUATION_BADGE)}</td></tr>`;
    });
    const o=studentOverall(s);
    const result=!allDone?'Em andamento':anyReprov?'Reprovado':anyRec?'Recuperação':'Aprovado';
    const code='SIGED-'+(school?.inep||'0000')+'-'+String(s.registration||'').replace(/\D/g,'')+'-'+new Date().getFullYear();
    content.innerHTML=`${head}${picker}${o.att.pct!==null&&o.att.pct<MIN_ATTENDANCE?`<div class="alert alert-danger" role="alert"><i class="fa-solid fa-triangle-exclamation"></i> <div><strong>Atenção:</strong> frequência geral de ${String(o.att.pct).replace('.',',')}%, abaixo do mínimo de ${MIN_ATTENDANCE}%.</div></div>`:''}
    <div class="report-card-doc" id="reportCardDoc"><div class="rc-head"><div><h2>${escapeHtml(school?.name||'Escola')}</h2><p>${escapeHtml(school?.address||'')} — ${escapeHtml(school?.city||'')}/${escapeHtml(school?.state||'')}${school?.inep?' · INEP '+escapeHtml(school.inep):''}</p></div><div class="rc-title"><strong>BOLETIM ESCOLAR</strong><span>Ano letivo ${c?.year||new Date().getFullYear()}</span></div></div>
    <div class="rc-student"><div><span>Aluno</span><strong>${escapeHtml(s.name)}</strong></div><div><span>Matrícula</span><strong>${escapeHtml(s.registration||'—')}</strong></div><div><span>Turma</span><strong>${escapeHtml(classLabel(c))}</strong></div><div><span>Turno</span><strong>${escapeHtml(c?.shift||'—')}</strong></div></div>
    <div class="table-wrap"><table class="rc-table"><thead><tr><th>Disciplina</th>${PERIODS.map(p=>`<th>${p}</th>`).join('')}<th>Média final</th><th>Frequência</th><th>Situação</th></tr></thead><tbody>${rows.length?rows.join(''):'<tr><td colspan="8"><div class="empty-state">Aluno sem turma/matriz curricular.</div></td></tr>'}</tbody></table></div>
    <div class="rc-foot"><div><span>Média geral</span><strong>${fmtNum(o.media)}</strong></div><div><span>Frequência geral</span><strong>${o.att.pct===null?'—':String(o.att.pct).replace('.',',')+'%'}</strong></div><div><span>Resultado</span><strong>${result}</strong></div></div>
    <p class="rc-code">Código de validação: <strong>${code}</strong> · Emitido em ${new Date().toLocaleDateString('pt-BR')} · Documento gerado pelo SIGED (simulação de QR Code: <span class="fake-qr" aria-hidden="true">▚▞▚▞</span>)</p></div>`;
    document.getElementById('rcStudent')?.addEventListener('change',e=>{window.__rcStudent=e.target.value;renderReportCard();});
    bindChildSwitcher(renderReportCard);
    document.getElementById('rcPrint').onclick=()=>{logAudit('Boletim','Emissão',`Boletim de ${s.name}`);document.body.classList.add('print-report');window.print();setTimeout(()=>document.body.classList.remove('print-report'),500);};
  }


  // ----- Acompanhamento pedagógico (central inteligente) -----
  const AT_RISK_LEVELS={
    'Normal':{className:'normal',icon:'fa-circle-check',tone:'green',min:0,max:24},
    'Atenção':{className:'attention',icon:'fa-triangle-exclamation',tone:'yellow',min:25,max:44},
    'Acompanhamento intensivo':{className:'intensive',icon:'fa-bullseye',tone:'orange',min:45,max:69},
    'Atenção imediata':{className:'immediate',icon:'fa-bell',tone:'red',min:70,max:100}
  };

  function atRiskActivities(student){
    const list=(state.activities||[]).filter(a=>a.schoolId===sid()&&a.studentId===student.id);
    if(!list.length) return {total:0,missing:0};
    const missing=list.filter(a=>{
      const status=String(a.status||a.situation||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
      return a.delivered===false||a.entregue===false||a.submitted===false||['nao entregue','pendente','atrasada','atrasado','nao realizada','nao realizado'].includes(status);
    }).length;
    return {total:list.length,missing};
  }

  function atRiskOccurrences(student){
    const cutoff=Date.now()-30*24*60*60*1000;
    return (state.occurrences||[]).filter(o=>o.schoolId===sid()&&o.studentId===student.id&&new Date(`${o.date||''}T12:00:00`).getTime()>=cutoff).sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  }

  function atRiskGradeSeries(student){
    const c=classById(student.classId);
    if(!c) return [];
    return PERIODS.map((period,index)=>{
      const values=(c.subjects||[]).map(sub=>periodMedia(student.id,c.id,sub.name,period)).filter(v=>v!==null);
      return {period,index,value:values.length?values.reduce((a,b)=>a+b,0)/values.length:null};
    }).filter(x=>x.value!==null);
  }

  function atRiskAttendanceTrend(student){
    const c=classById(student.classId);
    if(!c) return {previous:null,current:null,delta:null};
    const records=(state.lessonRecords||[]).filter(r=>r.schoolId===sid()&&r.classId===c.id&&Array.isArray(r.attendance)&&r.attendance.some(x=>x.studentId===student.id)).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
    if(records.length<4) return {previous:null,current:null,delta:null};
    const cut=Math.floor(records.length/2);
    const calc=arr=>{let total=0,present=0;arr.forEach(r=>{const x=(r.attendance||[]).find(y=>y.studentId===student.id);if(!x)return;total++;if(x.status==='Presente'||x.status==='Falta Justificada')present++;});return total?Math.round((present/total)*1000)/10:null;};
    const previous=calc(records.slice(0,cut)), current=calc(records.slice(cut));
    return {previous,current,delta:previous!==null&&current!==null?Math.round((current-previous)*10)/10:null};
  }

  function atRiskAnalysis(student){
    const overall=studentOverall(student);
    const gradeSeries=atRiskGradeSeries(student);
    const gradePrevious=gradeSeries.length>1?gradeSeries[gradeSeries.length-2].value:null;
    const gradeCurrent=gradeSeries.length?gradeSeries[gradeSeries.length-1].value:null;
    const gradeDelta=gradePrevious!==null&&gradeCurrent!==null?Math.round((gradeCurrent-gradePrevious)*10)/10:null;
    const attTrend=atRiskAttendanceTrend(student);
    const recentOccurrences=atRiskOccurrences(student);
    const activities=atRiskActivities(student);

    let frequencyScore=0;
    if(overall.att.pct!==null){
      if(overall.att.pct<70) frequencyScore=35;
      else if(overall.att.pct<75) frequencyScore=30;
      else if(overall.att.pct<80) frequencyScore=20;
      else if(overall.att.pct<85) frequencyScore=10;
    }

    let performanceScore=0;
    if(overall.media!==null){
      if(overall.media<4) performanceScore=30;
      else if(overall.media<6) performanceScore=22;
      else if(overall.media<7) performanceScore=10;
    }

    const recoveryScore=overall.recovery>=3?15:overall.recovery===2?10:overall.recovery===1?5:0;
    let trendScore=0;
    if(gradeDelta!==null){
      if(gradeDelta<=-1.5) trendScore+=8;
      else if(gradeDelta<=-0.7) trendScore+=5;
    }
    if(attTrend.delta!==null){
      if(attTrend.delta<=-10) trendScore+=7;
      else if(attTrend.delta<=-5) trendScore+=4;
    }
    if(activities.missing>=3) trendScore+=4;
    trendScore=Math.min(15,trendScore);

    const occurrenceScore=recentOccurrences.length?5:0;
    const index=Math.min(100,frequencyScore+performanceScore+recoveryScore+trendScore+occurrenceScore);
    const level=index>=70?'Atenção imediata':index>=45?'Acompanhamento intensivo':index>=25?'Atenção':'Normal';
    const reasons=[];
    if(overall.att.pct!==null&&overall.att.pct<MIN_ATTENDANCE) reasons.push(`Frequência ${String(overall.att.pct).replace('.',',')}%`);
    if(overall.media!==null&&overall.media<PASS_GRADE) reasons.push(`Média geral ${fmtNum(overall.media)}`);
    if(overall.recovery) reasons.push(`${overall.recovery} disciplina${overall.recovery===1?'':'s'} em recuperação`);
    if(gradeDelta!==null&&gradeDelta<=-0.7) reasons.push(`Queda de ${Math.abs(gradeDelta).toFixed(1).replace('.',',')} ponto${Math.abs(gradeDelta)===1?'':'s'} na média`);
    if(attTrend.delta!==null&&attTrend.delta<=-5) reasons.push(`Queda de ${Math.abs(attTrend.delta).toFixed(1).replace('.',',')} p.p. na frequência`);
    if(activities.missing) reasons.push(`${activities.missing} atividade${activities.missing===1?'':'s'} não entregue${activities.missing===1?'':'s'}`);
    if(recentOccurrences.length) reasons.push(`${recentOccurrences.length} ocorrência${recentOccurrences.length===1?'':'s'} nos últimos 30 dias`);

    const positiveEvolution=(gradeDelta!==null&&gradeDelta>=0.5)||(attTrend.delta!==null&&attTrend.delta>=3);
    const consistentPositive=(gradeDelta!==null&&gradeDelta>=0.5&&attTrend.delta!==null&&attTrend.delta>=3)||((gradeDelta===null||gradeDelta>=0.5)&&(attTrend.delta===null||attTrend.delta>=3)&&gradeSeries.length>=2);
    const recentChanges=[];
    if(gradeDelta!==null&&Math.abs(gradeDelta)>=0.5) recentChanges.push({kind:gradeDelta<0?'negative':'positive',text:gradeDelta<0?`Média caiu ${Math.abs(gradeDelta).toFixed(1).replace('.',',')} ponto(s)`: `Média subiu ${gradeDelta.toFixed(1).replace('.',',')} ponto(s)`});
    if(attTrend.delta!==null&&Math.abs(attTrend.delta)>=3) recentChanges.push({kind:attTrend.delta<0?'negative':'positive',text:attTrend.delta<0?`Frequência caiu ${Math.abs(attTrend.delta).toFixed(1).replace('.',',')} p.p.`:`Frequência subiu ${attTrend.delta.toFixed(1).replace('.',',')} p.p.`});
    if(recentOccurrences.length) recentChanges.push({kind:'negative',text:`${recentOccurrences.length} ocorrência(s) registrada(s) nos últimos 30 dias`});
    if(activities.missing) recentChanges.push({kind:'negative',text:`${activities.missing} atividade(s) não entregue(s)`});

    return {student,overall,gradeSeries,gradePrevious,gradeCurrent,gradeDelta,attTrend,recentOccurrences,activities,index,level,reasons,positiveEvolution,consistentPositive,recentChanges,score:{frequency:frequencyScore,performance:performanceScore,recovery:recoveryScore,trend:trendScore,occurrences:occurrenceScore}};
  }

  function atRiskLevelHtml(level){
    const meta=AT_RISK_LEVELS[level]||AT_RISK_LEVELS.Normal;
    return `<span class="at-risk-level ${meta.className}"><i class="fa-solid ${meta.icon}"></i>${escapeHtml(level)}</span>`;
  }

  function atRiskIndexHtml(index,level){
    const meta=AT_RISK_LEVELS[level]||AT_RISK_LEVELS.Normal;
    return `<div class="at-risk-index ${meta.className}" title="Índice calculado pelas regras de frequência, desempenho, recuperação, mudanças recentes e ocorrências"><span>${index}%</span></div>`;
  }

  function atRiskDeltaHtml(value,suffix=''){
    if(value===null||value===undefined) return '<span class="muted">Sem comparação</span>';
    const cls=value>0?'positive':value<0?'negative':'neutral';
    const sign=value>0?'+':'';
    return `<span class="at-risk-delta ${cls}">${sign}${String(value).replace('.',',')}${suffix}</span>`;
  }

  function atRiskSuggestions(a){
    const out=[];
    const push=(key,title,desc)=>out.push({key,title,desc});
    if(a.overall.att.pct!==null&&a.overall.att.pct<MIN_ATTENDANCE) push('attendance','Contatar responsável',`A frequência atual é ${String(a.overall.att.pct).replace('.',',')}%. Registrar contato para alinhar rotina e causas das ausências.`);
    if(a.overall.att.pct!==null&&a.overall.att.pct<85) push('schedule','Agendar acompanhamento',`Definir uma data de revisão para monitorar frequência e combinar a próxima ação.`);
    if(a.overall.media!==null&&a.overall.media<PASS_GRADE) push('teacher','Conversar com professor',`Revisar as disciplinas com baixo desempenho e definir uma intervenção pedagógica específica.`);
    if(a.overall.recovery>0) push('reinforcement','Encaminhar para reforço',`Há ${a.overall.recovery} disciplina${a.overall.recovery===1?'':'s'} em recuperação. Registrar o apoio pedagógico planejado.`);
    if(a.recentOccurrences.length) push('occurrence','Revisar ocorrência',`Há ocorrência(s) recente(s) vinculada(s) ao aluno; registrar encaminhamento ou retorno da equipe.`);
    if(a.activities.missing) push('activities','Revisar atividades',`${a.activities.missing} atividade(s) não entregue(s) foram identificadas nos dados disponíveis.`);
    return out;
  }

  function atRiskTracking(studentId){
    return (state.trackingRecords||[]).filter(t=>t.studentId===studentId&&t.schoolId===sid()).sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  }

  function atRiskManualTracking(studentId){
    return atRiskTracking(studentId).filter(t=>!String(t.kind||'').startsWith('system-'));
  }

  function atRiskHasActiveTracking(a){
    const manual=atRiskManualTracking(a.student.id);
    const latestManual=manual[0];
    return a.level!=='Normal'||latestManual?.status==='Em acompanhamento';
  }

  function atRiskTimeline(studentId,a){
    const records=atRiskTracking(studentId).map(r=>({date:r.date||todayIso(),kind:r.kind||'manual-action',title:r.title||((r.kind||'').startsWith('system-')?'Evento automático':'Ação registrada'),notes:r.notes||'',responsible:r.responsible||''}));
    const latestByKey=new Set();
    a.recentChanges.forEach((x,i)=>{
      const key=`${x.kind}|${x.text}`;
      if(!latestByKey.has(key)) { records.push({date:todayIso(),kind:x.kind==='negative'?'system-change':'system-evolution',title:x.kind==='negative'?'Mudança detectada':'Evolução positiva detectada',notes:x.text,responsible:'Sistema'}); latestByKey.add(key); }
    });
    if(a.consistentPositive && a.level==='Normal' && atRiskManualTracking(studentId).some(t=>t.status==='Em acompanhamento')) records.push({date:todayIso(),kind:'system-closure',title:'Sugestão de encerramento',notes:'O aluno apresentou evolução consistente e o índice atual voltou à faixa Normal.',responsible:'Sistema'});
    return records.sort((x,y)=>String(y.date).localeCompare(String(x.date)));
  }

  function atRiskPersistAutoState(analyses){
    let changed=false;
    const now=todayIso();
    analyses.forEach(a=>{
      const records=atRiskTracking(a.student.id);
      const autoKey=[a.level,a.index,a.reasons.join('|')].join('::');
      const lastSystem=records.find(r=>String(r.kind||'').startsWith('system-')&&r.kind!=='system-closure');
      if(a.level!=='Normal' && (!lastSystem||lastSystem.autoKey!==autoKey)){
        state.trackingRecords.push({id:crypto.randomUUID(),schoolId:sid(),studentId:a.student.id,date:now,reasons:a.reasons,notes:a.reasons.length?`Aluno entrou/permanece em acompanhamento por: ${a.reasons.join('; ')}.`:'Acompanhamento automático iniciado.',responsible:'Sistema',status:'Em acompanhamento',kind:lastSystem?'system-change':'system-entry',title:lastSystem?'Mudança detectada automaticamente':'Entrada automática em acompanhamento',autoKey,index:a.index,level:a.level});
        changed=true;
      }
      if(a.consistentPositive && a.level==='Normal' && atRiskManualTracking(a.student.id).some(t=>t.status==='Em acompanhamento')){
        const exists=records.some(r=>r.kind==='system-closure'&&r.studentId===a.student.id&&r.date===now);
        if(!exists){
          state.trackingRecords.push({id:crypto.randomUUID(),schoolId:sid(),studentId:a.student.id,date:now,reasons:[],notes:'Evolução consistente detectada. Revisão do acompanhamento recomendada; encerramento depende de confirmação do usuário.',responsible:'Sistema',status:'Em acompanhamento',kind:'system-closure',title:'Sugestão de encerramento'});
          changed=true;
        }
      }
    });
    if(changed) save();
    return changed;
  }

  function atRiskSuggestionsHtml(a){
    const suggestions=atRiskSuggestions(a);
    if(!suggestions.length && !(a.consistentPositive&&atRiskManualTracking(a.student.id).some(t=>t.status==='Em acompanhamento'))) return '<p class="muted">Nenhuma sugestão automática no momento.</p>';
    const cards=suggestions.map(x=>`<div class="at-risk-suggestion"><div><strong><i class="fa-solid fa-lightbulb"></i> ${escapeHtml(x.title)}</strong><p>${escapeHtml(x.desc)}</p></div><div class="at-risk-suggestion-actions"><button class="small-button ar-suggest-accept" data-id="${a.student.id}" data-key="${x.key}">Aceitar</button><button class="small-button ar-suggest-edit" data-id="${a.student.id}" data-key="${x.key}">Editar</button><button class="small-button ar-suggest-ignore" data-id="${a.student.id}" data-key="${x.key}">Ignorar</button></div></div>`).join('');
    const closure=a.consistentPositive&&a.level==='Normal'&&atRiskManualTracking(a.student.id).some(t=>t.status==='Em acompanhamento')?`<div class="at-risk-closure"><div><strong><i class="fa-solid fa-circle-check"></i> O aluno apresentou evolução consistente.</strong><p>Deseja revisar e, se estiver de acordo, encerrar o acompanhamento?</p></div><button class="btn-primary ar-review-close" data-id="${a.student.id}">Revisar encerramento</button></div>`:'';
    return cards+closure;
  }

  function openAtRiskDetails(studentId){
    const s=studentById(studentId); if(!s)return;
    const a=atRiskAnalysis(s), c=classById(s.classId), meta=AT_RISK_LEVELS[a.level]||AT_RISK_LEVELS.Normal;
    const manual=atRiskManualTracking(s.id), timeline=atRiskTimeline(s.id,a);
    const currentMean=a.overall.media===null?'—':fmtNum(a.overall.media), prevMean=a.gradePrevious===null?'—':fmtNum(a.gradePrevious);
    const currentAtt=a.overall.att.pct===null?'—':String(a.overall.att.pct).replace('.',',')+'%', prevAtt=a.attTrend.previous===null?'—':String(a.attTrend.previous).replace('.',',')+'%';
    openModal(`Acompanhamento inteligente — ${s.name}`,`<div class="at-risk-modal">
      <div class="at-risk-detail-hero"><div><span class="eyebrow">Central de acompanhamento</span><h2>${escapeHtml(s.name)}</h2><p>${escapeHtml(classLabel(c))} · Matrícula ${escapeHtml(s.registration||'—')}</p></div><div class="at-risk-hero-right">${atRiskIndexHtml(a.index,a.level)}<div>${atRiskLevelHtml(a.level)}<small>Índice calculado automaticamente</small></div></div></div>
      <div class="at-risk-detail-grid"><div class="at-risk-detail-box"><span>Antes</span><strong>Média ${prevMean}</strong><small>Frequência ${prevAtt}</small></div><div class="at-risk-detail-box"><span>Atual</span><strong>Média ${currentMean}</strong><small>Frequência ${currentAtt}</small></div><div class="at-risk-detail-box"><span>Variação</span><strong>${atRiskDeltaHtml(a.gradeDelta,' ponto(s)')}</strong><small>${atRiskDeltaHtml(a.attTrend.delta,' p.p.')}</small></div></div>
      <div class="at-risk-breakdown"><div class="card-title"><div><h3>Por que recebeu este nível?</h3><span>Regras transparentes usadas pelo índice</span></div></div>${[['Frequência',a.score.frequency,35],['Desempenho',a.score.performance,30],['Recuperações',a.score.recovery,15],['Mudanças recentes',a.score.trend,15],['Ocorrências recentes',a.score.occurrences,5]].map(x=>`<div class="at-risk-bar-row"><div><span>${x[0]}</span><strong>${x[1]}/${x[2]}</strong></div><div class="at-risk-bar"><span style="width:${x[2]?Math.round((x[1]/x[2])*100):0}%"></span></div></div>`).join('')}</div>
      <div class="at-risk-section"><div class="card-title"><div><h3>Sinais detectados</h3><span>Atualizados a partir dos dados disponíveis</span></div></div><div class="at-risk-reason-list">${a.reasons.length?a.reasons.map(r=>`<span class="badge badge-red">${escapeHtml(r)}</span>`).join(''):'<span class="badge badge-green">Nenhum sinal crítico detectado</span>'}</div></div>
      <div class="at-risk-section"><div class="card-title"><div><h3>Ações sugeridas</h3><span>Você decide o que aceitar, editar ou ignorar</span></div></div>${atRiskSuggestionsHtml(a)}</div>
      <div class="at-risk-section"><div class="card-title"><div><h3>Histórico</h3><span>${manual.length} ação(ões) registrada(s)</span></div><button class="small-button ar-add" data-id="${s.id}"><i class="fa-solid fa-plus"></i> Registrar ação</button></div><div class="at-risk-timeline">${timeline.length?timeline.map(t=>`<div class="at-risk-timeline-item"><span class="at-risk-timeline-dot ${t.kind==='system-evolution'?'positive':t.kind==='system-change'?'negative':''}"></span><div><div class="at-risk-timeline-head"><strong>${escapeHtml(t.title)}</strong><time>${formatDate(t.date)}</time></div><p>${escapeHtml(t.notes)}</p>${t.responsible?`<small>${escapeHtml(t.responsible)}</small>`:''}</div></div>`).join(''):'<p class="muted">Nenhum evento registrado ainda.</p>'}</div></div>
    </div>`);
    document.querySelectorAll('.ar-add').forEach(b=>b.onclick=()=>{closeModal();openTrackingEditor(b.dataset.id);});
    bindAtRiskSuggestionButtons(a);
  }

  function bindAtRiskSuggestionButtons(a){
    document.querySelectorAll('.ar-suggest-accept').forEach(b=>b.onclick=()=>openAtRiskSuggestionEditor(b.dataset.id,b.dataset.key,false));
    document.querySelectorAll('.ar-suggest-edit').forEach(b=>b.onclick=()=>openAtRiskSuggestionEditor(b.dataset.id,b.dataset.key,true));
    document.querySelectorAll('.ar-suggest-ignore').forEach(b=>b.onclick=()=>{
      const s=studentById(b.dataset.id); if(!s)return;
      if(!can('coordenacao','create')){denyToast('create');return;}
      const a2=atRiskAnalysis(s), suggestion=atRiskSuggestions(a2).find(x=>x.key===b.dataset.key); if(!suggestion)return;
      state.trackingRecords.push({id:crypto.randomUUID(),schoolId:sid(),studentId:s.id,date:todayIso(),reasons:a2.reasons,notes:`Sugestão ignorada: ${suggestion.title}.`,responsible:state.user||'',status:'Em acompanhamento',kind:'suggestion-ignored',title:'Sugestão ignorada',suggestionKey:suggestion.key});
      logAudit('Acompanhamento','Sugestão ignorada',`${s.name} — ${suggestion.title}`);save();closeModal();renderAtRisk();showToast('Sugestão ignorada.');
    });
    document.querySelectorAll('.ar-review-close').forEach(b=>b.onclick=()=>openTrackingCloseReview(b.dataset.id));
  }

  function openAtRiskSuggestionEditor(studentId,key,editing){
    if(!can('coordenacao','create')){denyToast('create');return;}
    const s=studentById(studentId); if(!s)return;
    const a=atRiskAnalysis(s), suggestion=atRiskSuggestions(a).find(x=>x.key===key); if(!suggestion)return;
    openModal(`${editing?'Editar':'Aceitar'} sugestão — ${s.name}`,`<form id="atRiskSuggestionForm" class="form-card" style="border:none;padding:0" novalidate><div class="alert alert-info"><i class="fa-solid fa-lightbulb"></i><div><strong>${escapeHtml(suggestion.title)}</strong><br>${escapeHtml(suggestion.desc)}</div></div><label for="ars_notes">Ação a registrar *</label><textarea id="ars_notes" rows="5" required>${escapeHtml(suggestion.title+' — '+suggestion.desc)}</textarea><label for="ars_resp">Responsável</label><input id="ars_resp" value="${escapeHtml(state.user||'')}" placeholder="Nome do responsável"><div class="form-actions"><button type="button" class="btn-secondary" id="arsCancel">Cancelar</button><button class="btn-primary">Registrar ação</button></div></form>`);
    document.getElementById('arsCancel').onclick=closeModal;
    document.getElementById('atRiskSuggestionForm').onsubmit=e=>{e.preventDefault();const notes=document.getElementById('ars_notes').value.trim();if(!notes)return formError('Descreva a ação realizada.');state.trackingRecords.push({id:crypto.randomUUID(),schoolId:sid(),studentId:s.id,date:todayIso(),reasons:a.reasons,notes,responsible:document.getElementById('ars_resp').value.trim()||state.user||'',status:'Em acompanhamento',kind:'manual-action',title:suggestion.title,suggestionKey:key});logAudit('Acompanhamento',editing?'Sugestão editada e aceita':'Sugestão aceita',`${s.name} — ${suggestion.title}`);save();closeModal();renderAtRisk();showToast('Ação registrada no acompanhamento.');};
  }

  function openAtRiskCloseReview(studentId){
    if(!can('coordenacao','create')){denyToast('create');return;}
    const s=studentById(studentId);if(!s)return;
    const a=atRiskAnalysis(s);
    openModal(`Revisar encerramento — ${s.name}`,`<div class="at-risk-close-review"><div class="at-risk-close-banner"><i class="fa-solid fa-circle-check"></i><div><strong>Evolução positiva detectada</strong><p>Média atual ${a.overall.media===null?'—':fmtNum(a.overall.media)} · Frequência ${a.overall.att.pct===null?'—':String(a.overall.att.pct).replace('.',',')+'%'} · Índice ${a.index}% (${a.level}).</p></div></div><p>O sistema não encerra o acompanhamento automaticamente. Confirme apenas depois de revisar o histórico e a evolução apresentada.</p><div class="form-actions"><button type="button" class="btn-secondary" id="arCloseReviewCancel">Manter acompanhamento</button><button type="button" class="btn-primary" id="arConfirmClose">Encerrar acompanhamento</button></div></div>`);
    document.getElementById('arCloseReviewCancel').onclick=closeModal;
    document.getElementById('arConfirmClose').onclick=()=>{state.trackingRecords.push({id:crypto.randomUUID(),schoolId:sid(),studentId:s.id,date:todayIso(),reasons:a.reasons,notes:'Acompanhamento encerrado após revisão do histórico e evolução positiva.',responsible:state.user||'',status:'Encerrado',kind:'manual-action',title:'Acompanhamento encerrado'});logAudit('Acompanhamento','Encerramento',`${s.name} — encerramento confirmado pelo usuário`);save();closeModal();renderAtRisk();showToast('Acompanhamento encerrado após confirmação.');};
  }

  function openTrackingEditor(studentId){
    if(!can('coordenacao','create')){denyToast('create');return;}
    const s=studentById(studentId);if(!s)return;
    openModal(`Registrar ação — ${s.name}`,`<form id="trkForm" class="form-card" style="border:none;padding:0" novalidate><label for="trk_notes">Ação realizada / observações *</label><textarea id="trk_notes" rows="4" required></textarea><label for="trk_resp">Responsável pelo acompanhamento</label><input id="trk_resp" value="${escapeHtml(state.user||'')}"><label for="trk_status">Status</label><select id="trk_status">${optionsHtml(['Em acompanhamento','Encerrado'],'Em acompanhamento')}</select><div class="form-actions"><button type="button" class="btn-secondary" id="trkCancel">Cancelar</button> <button class="btn-primary">Salvar</button></div></form>`);
    document.getElementById('trkCancel').onclick=closeModal;
    document.getElementById('trkForm').onsubmit=e=>{
      e.preventDefault();
      const notes=document.getElementById('trk_notes').value.trim();
      if(!notes)return formError('Descreva a ação realizada.');
      state.trackingRecords.push({id:crypto.randomUUID(),schoolId:sid(),studentId,date:todayIso(),reasons:atRiskAnalysis(s).reasons,notes,responsible:document.getElementById('trk_resp').value.trim(),status:document.getElementById('trk_status').value,kind:'manual-action',title:'Ação registrada'});
      logAudit('Acompanhamento','Registro',`${s.name} — ${notes.slice(0,60)}`);
      save();closeModal();renderAtRisk();showToast('Ação de acompanhamento registrada.');
    };
  }

  function renderAtRisk(){
    if(!can('coordenacao','view')){renderAccessDenied('Alunos em acompanhamento');return;}
    const students=visibleStudents().filter(activeStudent);
    const analyses=students.map(atRiskAnalysis);
    atRiskPersistAutoState(analyses);
    window.__atRiskFilter=window.__atRiskFilter||{q:'',level:'',classId:'',onlyActive:false};
    const immediate=analyses.filter(a=>a.level==='Atenção imediata');
    const intensive=analyses.filter(a=>a.level==='Acompanhamento intensivo');
    const recent=analyses.filter(a=>a.recentChanges.length&&a.recentChanges.some(x=>x.kind==='negative'));
    const positive=analyses.filter(a=>a.positiveEvolution);
    const active=analyses.filter(atRiskHasActiveTracking);
    const classes=(state.classes||[]).filter(c=>c.schoolId===sid());
    const panel=(title,icon,items,tone,empty)=>`<div class="at-risk-panel ${tone}"><div class="at-risk-panel-head"><span class="at-risk-panel-icon"><i class="fa-solid ${icon}"></i></span><div><strong>${title}</strong><small>${items.length} aluno(s)</small></div></div><div class="at-risk-panel-list">${items.slice(0,4).map(a=>`<button class="at-risk-panel-item ar-open" data-id="${a.student.id}"><span>${escapeHtml(a.student.name)}</span><small>${escapeHtml(a.reasons[0]||'Evolução registrada')}</small></button>`).join('')||`<p class="muted">${empty}</p>`}</div></div>`;

    content.innerHTML=`${pageHeader('Alunos em Acompanhamento','Central inteligente: o sistema analisa dados acadêmicos disponíveis, explica o nível de atenção e acompanha a evolução.','<button type="button" class="btn-primary" id="arRefresh"><i class="fa-solid fa-rotate"></i> Atualizar análise</button>')}
      <div class="at-risk-disclaimer"><i class="fa-solid fa-circle-info"></i><div><strong>Automação baseada em regras transparentes.</strong><span>Os indicadores são apoio à decisão pedagógica e não substituem a análise da equipe. Encerramentos exigem confirmação humana.</span></div></div>
      <div class="stat-grid at-risk-stats">${statCard('Atenção imediata',immediate.length,'fa-bell')}${statCard('Em acompanhamento',active.length,'fa-bullseye')}${statCard('Mudanças recentes',recent.length,'fa-chart-line')}${statCard('Evolução positiva',positive.length,'fa-arrow-trend-up')}</div>
      <div class="at-risk-panels">${panel('Atenção imediata','fa-bell',immediate,'red','Nenhum caso no nível mais alto.')}${panel('Em acompanhamento','fa-bullseye',active,'orange','Nenhum acompanhamento ativo.')}${panel('Mudanças recentes','fa-chart-line',recent,'yellow','Nenhuma mudança negativa recente.')}${panel('Evolução positiva','fa-arrow-trend-up',positive,'green','Nenhuma evolução positiva identificada.')}</div>
      <div class="filter-bar at-risk-filters"><label for="arQ" class="sr-only">Buscar aluno</label><input id="arQ" type="search" placeholder="Buscar por nome ou matrícula" value="${escapeHtml(window.__atRiskFilter.q)}"><label for="arLevel" class="sr-only">Nível</label><select id="arLevel"><option value="">Todos os níveis</option>${Object.keys(AT_RISK_LEVELS).map(x=>`<option value="${escapeHtml(x)}" ${window.__atRiskFilter.level===x?'selected':''}>${escapeHtml(x)}</option>`).join('')}</select><label for="arClass" class="sr-only">Turma</label><select id="arClass"><option value="">Todas as turmas</option>${classes.map(c=>`<option value="${c.id}" ${window.__atRiskFilter.classId===c.id?'selected':''}>${escapeHtml(classLabel(c))}</option>`).join('')}</select><label class="at-risk-check"><input id="arOnlyActive" type="checkbox" ${window.__atRiskFilter.onlyActive?'checked':''}> Somente em acompanhamento</label><button type="button" class="btn-secondary" id="arClear">Limpar filtros</button></div>
      <div id="arStudentGrid"></div>`;

    const draw=()=>{
      let list=analyses.slice();
      const f=window.__atRiskFilter;
      if(f.q) {const q=f.q.toLowerCase();list=list.filter(a=>a.student.name.toLowerCase().includes(q)||String(a.student.registration||'').toLowerCase().includes(q));}
      if(f.level) list=list.filter(a=>a.level===f.level);
      if(f.classId) list=list.filter(a=>a.student.classId===f.classId);
      if(f.onlyActive) list=list.filter(atRiskHasActiveTracking);
      list.sort((a,b)=>b.index-a.index||a.student.name.localeCompare(b.student.name));
      document.getElementById('arStudentGrid').innerHTML=list.length?`<div class="at-risk-student-grid">${list.map(a=>{
        const c=classById(a.student.classId), manual=atRiskManualTracking(a.student.id), suggestions=atRiskSuggestions(a);
        return `<article class="at-risk-student-card ${AT_RISK_LEVELS[a.level].className}"><div class="at-risk-student-top"><div class="at-risk-avatar">${escapeHtml((a.student.name||'?').trim().split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase())}</div><div class="at-risk-student-name"><strong>${escapeHtml(a.student.name)}</strong><span>${escapeHtml(classLabel(c))}</span><small>${escapeHtml(a.student.registration||'Sem matrícula')}</small></div><div>${atRiskIndexHtml(a.index,a.level)}</div></div><div class="at-risk-student-status">${atRiskLevelHtml(a.level)} ${a.positiveEvolution?'<span class="at-risk-evolution"><i class="fa-solid fa-arrow-trend-up"></i> Evolução positiva</span>':''}</div><div class="at-risk-student-metrics"><div><span>Média atual</span><strong>${a.overall.media===null?'—':fmtNum(a.overall.media)}</strong></div><div><span>Frequência</span><strong>${a.overall.att.pct===null?'—':String(a.overall.att.pct).replace('.',',')+'%'}</strong></div><div><span>Recuperações</span><strong>${a.overall.recovery}</strong></div><div><span>Ações</span><strong>${manual.length}</strong></div></div><div class="at-risk-mini-trend"><span>Antes → atual</span><strong>${a.gradePrevious===null?'—':fmtNum(a.gradePrevious)} → ${a.gradeCurrent===null?'—':fmtNum(a.gradeCurrent)}</strong>${atRiskDeltaHtml(a.gradeDelta,' pt')}</div><div class="at-risk-reasons">${a.reasons.slice(0,4).map(r=>`<span class="badge badge-red">${escapeHtml(r)}</span>`).join('')||'<span class="badge badge-green">Sem sinais críticos</span>'}</div><div class="at-risk-student-actions"><button class="small-button ar-open" data-id="${a.student.id}"><i class="fa-solid fa-eye"></i> Ver acompanhamento</button>${can('coordenacao','create')?`<button class="small-button ar-add" data-id="${a.student.id}"><i class="fa-solid fa-plus"></i> Ação</button>`:''}<span class="at-risk-suggestion-count"><i class="fa-solid fa-lightbulb"></i> ${suggestions.length} sugestão(ões)</span></div></article>`;}).join('')}</div>`:'<div class="empty-state">Nenhum aluno corresponde aos filtros selecionados.</div>';
      document.querySelectorAll('.ar-open').forEach(b=>b.onclick=()=>openAtRiskDetails(b.dataset.id));
      document.querySelectorAll('.ar-add').forEach(b=>b.onclick=()=>openTrackingEditor(b.dataset.id));
    };
    document.getElementById('arQ').oninput=e=>{window.__atRiskFilter.q=e.target.value;draw();};
    document.getElementById('arLevel').onchange=e=>{window.__atRiskFilter.level=e.target.value;draw();};
    document.getElementById('arClass').onchange=e=>{window.__atRiskFilter.classId=e.target.value;draw();};
    document.getElementById('arOnlyActive').onchange=e=>{window.__atRiskFilter.onlyActive=e.target.checked;draw();};
    document.getElementById('arClear').onclick=()=>{window.__atRiskFilter={q:'',level:'',classId:'',onlyActive:false};renderAtRisk();};
    document.getElementById('arRefresh').onclick=()=>renderAtRisk();
    draw();
  }
  // ----- Censo Escolar (validação) -----
  function renderCensus(){
    if(!can('censo','view')){renderAccessDenied('Censo Escolar');return;}
    const school=schoolForCurrent();
    content.innerHTML=`${pageHeader('Censo Escolar','Painel de preparação para o Censo Escolar: dados da escola, infraestrutura, turmas, alunos e profissionais, com validação de consistência.','<button type="button" class="btn-primary" id="runValidation"><i class="fa-solid fa-check-double"></i> Executar validação</button>')}
      <div class="stat-grid">${statCard('Alunos',state.students.filter(s=>s.schoolId===school.id).length,'fa-user-graduate')}${statCard('Turmas',state.classes.filter(c=>c.schoolId===school.id).length,'fa-people-roof')}${statCard('Professores',state.teachers.filter(t=>t.schoolId===school.id).length,'fa-chalkboard-user')}${statCard('Funcionários',state.employees.filter(e=>e.schoolId===school.id).length,'fa-id-card')}</div>
      <div class="card"><div class="card-title"><div><h3>Dados da escola / gestor</h3></div></div><div class="detail-grid"><div><span>Escola</span><strong>${escapeHtml(school.name)}</strong></div><div><span>INEP</span><strong>${escapeHtml(school.inep||'—')}</strong></div><div><span>Endereço</span><strong>${escapeHtml(school.address||'—')}</strong></div><div><span>Gestor</span><strong>${escapeHtml((state.mockUsers.find(u=>u.role==='direcao')||{}).name||'—')}</strong></div></div></div>
      <div id="censusResult"></div>`;
    document.getElementById('runValidation').onclick=()=>{
      const issues=[];
      state.students.filter(s=>s.schoolId===school.id&&activeStudent(s)).forEach(s=>{
        if(!s.cpf) issues.push({type:'Aluno sem CPF',ref:s.name});
        if(!s.classId) issues.push({type:'Aluno sem turma',ref:s.name});
        if(!(s.guardians||[]).length) issues.push({type:'Matrícula sem responsável',ref:s.name});
        if(!s.birthDate) issues.push({type:'Dado obrigatório incompleto (nascimento)',ref:s.name});
      });
      state.teachers.filter(t=>t.schoolId===school.id).forEach(t=>{
        if(!(state.teacherAssignments||[]).some(a=>a.teacherId===t.id)) issues.push({type:'Professor sem disciplina atribuída',ref:t.name});
      });
      state.classes.filter(c=>c.schoolId===school.id).forEach(c=>{
        if(!c.schedule||!Object.keys(c.schedule).length) issues.push({type:'Turma sem horário',ref:classLabel(c)});
      });
      logAudit('Censo Escolar','Validação',`${issues.length} inconsistência(s) encontrada(s).`);save();
      document.getElementById('censusResult').innerHTML=`<div class="card"><div class="card-title"><div><h3>Resultado da validação</h3><span>${issues.length} inconsistência(s)</span></div></div>${issues.length?`<div class="table-wrap"><table><thead><tr><th>Tipo</th><th>Referência</th></tr></thead><tbody>${issues.map(i=>`<tr><td><span class="badge badge-red">${escapeHtml(i.type)}</span></td><td>${escapeHtml(i.ref)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state"><i class="fa-solid fa-circle-check" style="color:#16a34a"></i> Nenhuma inconsistência encontrada.</div>'}</div>`;
    };
  }

  // ----- Busca global -----
  function renderGlobalSearch(){
    content.innerHTML=`${pageHeader('Busca global','Pesquise alunos, professores, funcionários, turmas, protocolos, documentos e responsáveis.')}<div class="filter-bar"><input id="gsQ" type="search" placeholder="Digite ao menos 2 caracteres..." style="flex:1;min-width:260px" autofocus></div><div id="gsResults"></div>`;
    document.getElementById('gsQ').oninput=e=>runGlobalSearch(e.target.value);
    document.getElementById('gsQ').focus();
  }
  function runGlobalSearch(term){
    const box=document.getElementById('gsResults');if(!box)return;
    const q=term.trim().toLowerCase();
    if(q.length<2){box.innerHTML='<div class="empty-state">Digite ao menos 2 caracteres para buscar.</div>';return;}
    const school=schoolForCurrent();
    const groups=[];
    if(can('alunos','view')){const r=state.students.filter(s=>s.schoolId===school.id&&(s.name.toLowerCase().includes(q)||String(s.registration||'').toLowerCase().includes(q)));if(r.length)groups.push(['Alunos',r.map(s=>`${s.name} — ${classLabel(classById(s.classId))} (mat. ${s.registration||'—'})`)]);}
    if(can('professores','view')){const r=state.teachers.filter(t=>t.schoolId===school.id&&t.name.toLowerCase().includes(q));if(r.length)groups.push(['Professores',r.map(t=>`${t.name} — ${t.registration||''}`)]);}
    if(can('rh','view')){const r=state.employees.filter(e=>e.schoolId===school.id&&e.name.toLowerCase().includes(q));if(r.length)groups.push(['Funcionários',r.map(e=>`${e.name} — ${e.role}`)]);}
    if(can('responsaveis','view')){const r=state.guardians.filter(g=>g.schoolId===school.id&&g.name.toLowerCase().includes(q));if(r.length)groups.push(['Responsáveis',r.map(g=>`${g.name} — ${g.phone||''}`)]);}
    {const r=state.classes.filter(c=>c.schoolId===school.id&&classLabel(c).toLowerCase().includes(q));if(r.length)groups.push(['Turmas',r.map(classLabel)]);}
    if(can('protocolos','view')){const r=state.serviceRequests.filter(x=>x.schoolId===school.id&&(String(x.protocol).toLowerCase().includes(q)||String(x.requester).toLowerCase().includes(q)));if(r.length)groups.push(['Protocolos',r.map(x=>`${x.protocol} — ${x.type} (${x.requester})`)]);}
    box.innerHTML=groups.length?groups.map(([label,items])=>`<div class="card"><div class="card-title"><div><h3>${label}</h3><span>${items.length} resultado(s)</span></div></div><ul class="plain-list">${items.slice(0,10).map(i=>`<li>${escapeHtml(i)}</li>`).join('')}</ul></div>`).join(''):'<div class="empty-state">Nenhum resultado encontrado para os módulos aos quais você tem acesso.</div>';
  }

  // ----- Topo: busca, tema, notificações, perfil -----
  function wireTopbar(){
    document.getElementById('globalSearchButton')?.addEventListener('click',()=>{
      openModal('Busca global','<div class="filter-bar"><input id="gsModalQ" type="search" placeholder="Buscar alunos, professores, turmas, protocolos..." style="flex:1"></div><div id="gsResults"></div>');
      document.getElementById('gsModalQ').focus();
      document.getElementById('gsModalQ').oninput=e=>runGlobalSearch(e.target.value);
    });
    document.getElementById('themeButton')?.addEventListener('click',()=>{
      const dark=document.documentElement.classList.toggle('theme-dark');
      document.getElementById('themeButton').querySelector('i').className=dark?'fa-solid fa-sun':'fa-solid fa-moon';
      localStorage.setItem('siged_theme',dark?'dark':'light');
    });
    if(localStorage.getItem('siged_theme')==='dark'){document.documentElement.classList.add('theme-dark');const ic=document.getElementById('themeButton')?.querySelector('i');if(ic)ic.className='fa-solid fa-sun';}
    document.getElementById('notificationButton')?.addEventListener('click',()=>{
      const panel=document.getElementById('notificationPanel');
      panel.classList.toggle('hidden');
      if(!panel.classList.contains('hidden')) renderNotificationPanel();
    });
    document.getElementById('profileButton')?.addEventListener('click',()=>{
      confirmAction('Sair do sistema','Deseja encerrar sua sessão no SIGED?',()=>document.getElementById('logoutButton').click(),'Sair');
    });
  }
  function renderNotificationPanel(){
    const panel=document.getElementById('notificationPanel');if(!panel)return;
    const list=(state.notifications||[]).filter(n=>n.schoolId===sid()).slice(0,8);
    const badgeEl=document.getElementById('notifCount');
    const unread=(state.notifications||[]).filter(n=>n.schoolId===sid()&&!n.read).length;
    if(badgeEl) badgeEl.textContent=unread>9?'9+':String(unread);
    if(badgeEl) badgeEl.style.display=unread?'flex':'none';
    const body=panel.querySelector('.notification-body')||panel;
    const items=list.length?list.map(n=>`<div class="notification-item ${n.read?'':'unread'}"><i class="fa-solid fa-bell"></i><div><strong>${escapeHtml(n.text)}</strong><p>${new Date(n.date).toLocaleString('pt-BR')}</p></div></div>`).join(''):'<div class="empty-state">Nenhuma notificação.</div>';
    const oldItems=panel.querySelectorAll('.notification-item');oldItems.forEach(x=>x.remove());
    panel.insertAdjacentHTML('beforeend',items);
    list.forEach(n=>n.read=true);
    save();
  }
  function updateNotifBadge(){
    const unread=(state.notifications||[]).filter(n=>n.schoolId===sid()&&!n.read).length;
    let el=document.getElementById('notifCount');
    if(!el){const btn=document.getElementById('notificationButton');if(!btn)return;el=document.createElement('span');el.id='notifCount';el.className='notif-badge';btn.appendChild(el);}
    el.textContent=unread>9?'9+':String(unread);el.style.display=unread?'flex':'none';
  }


  function renderSettings(){
    content.innerHTML=`${pageHeader('Configurações','Preferências do ambiente de demonstração.')}
      <div class="card"><div class="card-title"><div><h3>Modo de demonstração</h3><span>Este sistema roda inteiramente no navegador (sem servidor). Os dados ficam salvos no localStorage deste navegador.</span></div></div>
      <p>Se algo ficou inconsistente durante os testes, você pode restaurar o cenário de demonstração original (Colégio Horizonte Azul, com alunos, professores, turmas, notas e frequência já preenchidos).</p>
      <div class="form-actions"><button type="button" class="btn-secondary" id="resetDemoBtn"><i class="fa-solid fa-rotate-left"></i> Restaurar dados de demonstração</button></div></div>`;
    document.getElementById('resetDemoBtn').onclick=()=>{
      confirmAction('Restaurar dados de demonstração','Isso apaga TODOS os dados atuais (inclusive o que você cadastrou nesta sessão) e recarrega o cenário de exemplo original. Esta ação não pode ser desfeita. Deseja continuar?',()=>{
        localStorage.removeItem(STORAGE);
        showToast('Dados restaurados. Recarregando...');
        setTimeout(()=>location.reload(),600);
      },'Restaurar dados');
    };
  }

  // ===== Dados de exemplo (carga inicial) — para o sistema já nascer com uma escola em funcionamento =====
  function seedDemoData(){
    const now=new Date().toISOString();
    const year=new Date().getFullYear();
    const today=new Date();
    const isoDaysAgo=n=>{const d=new Date(today);d.setDate(d.getDate()-n);return d.toISOString().slice(0,10);};
    const slug=t=>t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').split(' ').slice(0,2).join('.');
    const domain='@horizonteazul.edu.br';

    const school={id:crypto.randomUUID(),name:'Colégio Horizonte Azul',cnpj:'12.345.678/0001-90',inep:'28012345',email:'contato'+domain,phone:'(79) 3211-4455',address:'Av. Beira Mar, 1200 — Praia 13 de Julho',city:'Aracaju',state:'SE',createdAt:now};
    state.schools.push(school);
    state.currentSchoolId=school.id;

    const classDefs=[
      {grade:'5º ano do Ensino Fundamental',name:'A',shift:'Manhã',room:'Sala 12',vacancies:32},
      {grade:'1º ano do Ensino Médio',name:'A',shift:'Manhã',room:'Sala 21',vacancies:30},
      {grade:'3º ano do Ensino Médio',name:'A',shift:'Tarde',room:'Sala 05',vacancies:28}
    ];
    const classes=classDefs.map(cd=>{const subjects=getTemplate(cd.grade);return {id:crypto.randomUUID(),schoolId:school.id,year,grade:cd.grade,name:cd.name,shift:cd.shift,room:cd.room,vacancies:cd.vacancies,subjects,schedule:buildSchedule(subjects),updatedAt:now};});
    state.classes.push(...classes);

    // Professores (cadastro + funcionário) e distribuição por turma/disciplina
    const teacherDefs=[
      {name:'Marina Souza Lima',role:'Professora de Língua Portuguesa',formation:'Licenciatura em Letras',bond:'Efetivo',subjects:['Língua Portuguesa'],classIdx:[0,1,2],hours:3},
      {name:'Rafael Andrade Costa',role:'Professor de Matemática',formation:'Licenciatura em Matemática',bond:'Efetivo',subjects:['Matemática'],classIdx:[0,1,2],hours:3},
      {name:'Juliana Ferreira Melo',role:'Professora de Biologia',formation:'Licenciatura em Ciências Biológicas',bond:'Contratado',subjects:['Biologia'],classIdx:[1,2],hours:2},
      {name:'Eduardo Pontes Silva',role:'Professor de História',formation:'Licenciatura em História',bond:'Efetivo',subjects:['História'],classIdx:[0,1,2],hours:2},
      {name:'Camila Rocha Barros',role:'Professora de Educação Física',formation:'Licenciatura em Educação Física',bond:'Temporário',subjects:['Educação Física'],classIdx:[0,1,2],hours:1}
    ];
    const teacherIds=[];
    teacherDefs.forEach((t,idx)=>{
      const email=slug(t.name)+domain;const tid=crypto.randomUUID();teacherIds.push(tid);
      state.teachers.push({id:tid,schoolId:school.id,name:t.name,registration:'PROF-'+(1000+idx),cpf:`0${idx}1.234.567-${10+idx}`,email,phone:'(79) 99911-00'+(10+idx),formation:t.formation,bond:t.bond,contractHours:20,status:'Ativo',classId:classes[t.classIdx[0]].id,className:classes[t.classIdx[0]].name});
      state.employees.push({id:crypto.randomUUID(),schoolId:school.id,name:t.name,role:t.role,type:'Professor',admissionDate:`${year-2}-02-01`,regime:'Horista',cargaHorariaSemanal:20,valorHora:38,salary:Math.round(20*38*4.5*100)/100,status:'Ativo',hasAccess:true,email});
      t.classIdx.forEach(ci=>t.subjects.forEach(sn=>{
        if((classes[ci].subjects||[]).some(x=>x.name===sn)) state.teacherAssignments.push({id:crypto.randomUUID(),schoolId:school.id,teacherId:tid,classId:classes[ci].id,subject:sn,weeklyClasses:t.hours,weights:{av1:1,av2:1,trabalho:1}});
      }));
    });

    // Demais funcionários (gestão e apoio)
    const staffDefs=[
      {name:'Marcos Vieira Teixeira',role:'Diretor Escolar',salary:7800,profile:'Direção'},
      {name:'Patrícia Gomes Almeida',role:'Secretária Escolar',salary:2600,profile:'Secretaria'},
      {name:'Roberta Cavalcante',role:'Assistente de Atendimento',salary:2300,profile:'Secretaria'},
      {name:'Simone Albuquerque',role:'Analista de RH',salary:3900,profile:'Administrativo'},
      {name:'André Luiz Santana',role:'Coordenador Pedagógico',salary:4200,profile:'Administrativo'},
      {name:'Fernanda Dias Oliveira',role:'Auxiliar de Serviços Gerais',salary:1650,profile:'Apoio / Limpeza'}
    ];
    staffDefs.forEach(s=>state.employees.push({id:crypto.randomUUID(),schoolId:school.id,name:s.name,role:s.role,type:'Funcionário',admissionDate:`${year-1}-03-10`,regime:'Mensalista',cargaHorariaSemanal:0,valorHora:0,salary:s.salary,status:'Ativo',hasAccess:true,email:slug(s.name)+domain,accessProfile:s.profile}));

    // Responsáveis e alunos (18 alunos, 12 responsáveis; alguns responsáveis têm mais de um filho)
    const firstNames=['Ana','Bruno','Caio','Duda','Elisa','Felipe','Gabriela','Heitor','Igor','Júlia','Karina','Lucas','Mariana','Nicolas','Olívia','Pedro','Rafaela','Sofia'];
    const lastNames=['Almeida','Barros','Costa','Dantas','Esteves','Farias','Gonçalves','Henriques','Ibiapina','Jardim','Lacerda','Menezes'];
    const guardianFirst=['Maria','José','Cláudia','Roberto','Sandra','Paulo','Luciana','Ricardo','Adriana','Marcelo','Tânia','Fábio'];
    const guardians=guardianFirst.map((fn,i)=>{const g={id:crypto.randomUUID(),schoolId:school.id,name:`${fn} ${lastNames[i]}`,cpf:`1${String(i).padStart(2,'0')}.456.789-0${i%10}`,phone:`(79) 99${String(8000+i*37).slice(0,3)}-${String(1000+i*91).slice(0,4)}`,email:slug(`${fn} ${lastNames[i]}`)+'@email.com',emergency:'Sim',canPickup:'Sim',status:'Ativo'};state.guardians.push(g);return g;});
    const students=[];let si=0;
    classes.forEach((cls,ci)=>{for(let i=0;i<6;i++){
      const gi=si%12;const g=guardians[gi];
      const birthYear=year-(ci===0?10:ci===1?15:17);
      const st={id:crypto.randomUUID(),schoolId:school.id,name:`${firstNames[si]} ${lastNames[gi]}`,socialName:'',birthDate:`${birthYear}-0${(si%9)+1}-1${si%9}`,cpf:`2${String(si).padStart(2,'0')}.111.222-${String(10+si).slice(-2)}`,rg:`${1000000+si*13}-SSP/SE`,gender:si%2?'Masculino':'Feminino',nationality:'Brasileira',birthplace:'Aracaju/SE',mother:g.name,father:'',cep:'49030-000',street:'Rua das Acácias',number:String(100+si),complement:'',neighborhood:'Jardins',city:'Aracaju',uf:'SE',phone:'',cellphone:g.phone,email:'',classId:cls.id,className:cls.name,status:'Ativo',modality:'Regular',previousSchool:si%5===0?'Escola Municipal Santos Dumont':'',enrollmentDate:`${year}-01-2${si%9}`,emergencyContact:`${g.name} — ${g.phone}`,pickupAuthorized:g.name,aee:si===4?'Sim':'Não',aeeNotes:si===4?'Acompanhamento com sala de recursos multifuncionais (2x/semana).':'',pedagogicalNotes:'',registration:'ALU-'+(2000+si),guardians:[{guardianId:g.id,kinship:si%2?'Pai':'Mãe'}],history:[{date:`${year}-01-2${si%9}`,text:`Matrícula efetivada na turma ${classLabel(cls)}`,by:'Secretaria'}]};
      state.students.push(st);students.push(st);si++;}});

    // Lançamentos de aulas e frequência (coerentes com turmas, professores e alunos)
    const asgs=state.teacherAssignments.filter(a=>a.schoolId===school.id);
    asgs.forEach((a,ai)=>{
      const studs=students.filter(s=>s.classId===a.classId);
      for(let k=0;k<8;k++){
        const attendance=studs.map((s,idx)=>{const n=students.indexOf(s);let status='Presente';const seed=(n*3+k*5+ai)%11;if(n===3&&k%2===0)status='Falta';else if(n===8&&k%3===0)status='Falta';else if(seed===0)status='Falta';else if((n+k+ai)%13===0)status='Falta Justificada';return {studentId:s.id,status};});
        state.lessonRecords.push({id:crypto.randomUUID(),schoolId:school.id,classId:a.classId,subject:a.subject,date:isoDaysAgo(56-k*7-(ai%3)),teacherId:a.teacherId,title:`${a.subject} — aula ${k+1}`,description:'Conteúdo do bimestre conforme planejamento.',methodology:k%2?'Aula expositiva dialogada':'Atividade em grupo',notes:'',attendance});
      }
    });

    // Notas do 1º e 2º bimestres (completas) e 3º (parcial)
    students.forEach((s,n)=>{
      const cls=classById(s.classId);
      (cls.subjects||[]).forEach((sub,ki)=>{
        PERIODS.slice(0,3).forEach((per,pi)=>{
          if(pi===2&&(n+ki)%2===0) return;
          let base=6.2+((n*7+ki*3+pi*5)%37)/10;
          if(n===3) base=4.2+((ki*3+pi)%9)/10;
          if(n===8) base=5.4+((ki+pi)%6)/10;
          if(base>9.8) base=9.8;
          const av1=Math.round(base*10)/10;
          const av2=pi===2?null:Math.min(10,Math.round((base+(((n+ki)%5)-2)*0.4)*10)/10);
          const trab=pi===2?null:Math.min(10,Math.round((base+0.5)*10)/10);
          const rec=(pi===1&&av2!==null&&base<5.8&&(n+ki)%2===0)?Math.min(10,Math.round((base+2)*10)/10):null;
          state.grades.push({id:crypto.randomUUID(),schoolId:school.id,classId:cls.id,subject:sub.name,period:per,studentId:s.id,av1,av2:av2<0?0:av2,trabalho:trab,recuperacao:rec,history:[{date:now,by:'Carga inicial',field:'av1',from:null,to:av1}]});
        });
      });
    });

    // Contas de demonstração (login simulado)
    const mk=(name,role,email,password,vinculo,vinculoLabel,matricula)=>state.mockUsers.push({id:crypto.randomUUID(),name,role,email,password,schoolId:school.id,status:'Ativo',vinculo:vinculo||null,vinculoLabel:vinculoLabel||'',matricula});
    mk('Marcos Vieira Teixeira','direcao','diretor'+domain,'direcao123',null,'Diretor Escolar','FUNC-0001');
    mk('Patrícia Gomes Almeida','secretaria_gestao','secretaria'+domain,'secretaria123',null,'Secretária Escolar','FUNC-0002');
    mk('Roberta Cavalcante','secretaria_atendimento','atendimento'+domain,'atendimento123',null,'Assistente de Atendimento','FUNC-0003');
    mk('Simone Albuquerque','rh','rh'+domain,'rh123',null,'Analista de RH','FUNC-0004');
    mk('Marina Souza Lima','professor',slug('Marina Souza Lima')+domain,'professor123',teacherIds[0],'Professora de Língua Portuguesa','PROF-1000');
    mk('Rafael Andrade Costa','professor',slug('Rafael Andrade Costa')+domain,'professor123',teacherIds[1],'Professor de Matemática','PROF-1001');
    mk(students[0].name,'aluno','aluno.'+slug(students[0].name)+'@aluno.horizonteazul.edu.br','aluno123',students[0].id,`Aluno(a) — ${classLabel(classes[0])}`,students[0].registration);
    mk(guardians[0].name,'responsavel',guardians[0].email,'responsavel123',guardians[0].id,`Responsável por ${students.filter(x=>x.guardians[0].guardianId===guardians[0].id).length} alunos`,'RESP-0001');

    // Pipeline de contratação (BPMN)
    state.jobs.push({id:crypto.randomUUID(),schoolId:school.id,title:'Professor de Educação Física (2ª vaga)',sector:'Pedagógico',type:'Professor',description:'Reforço para turmas do Ensino Fundamental no turno da manhã.',status:'Aguardando aprovação'});
    const jobOpen={id:crypto.randomUUID(),schoolId:school.id,title:'Auxiliar Administrativo',sector:'Administrativo',type:'Funcionário',description:'Apoio à secretaria escolar no atendimento e organização de documentos.',status:'Aberta'};
    state.jobs.push(jobOpen);
    [{name:'Beatriz Nunes Carvalho',status:'Aprovado'},{name:'Thiago Moreira Ramos',status:'Entrevista'},{name:'Larissa Prado Teixeira',status:'Triagem'}].forEach(c=>state.candidates.push({id:crypto.randomUUID(),schoolId:school.id,jobId:jobOpen.id,name:c.name,contact:'(79) 9 9988-7766',status:c.status}));
    state.employees.push({id:crypto.randomUUID(),schoolId:school.id,name:'Beatriz Nunes Carvalho',role:'Auxiliar Administrativo',type:'Funcionário',admissionDate:todayIso(),regime:'Mensalista',cargaHorariaSemanal:0,valorHora:0,salary:1800,status:'Aguardando Financeiro',hasAccess:false});
    state.employees.push({id:crypto.randomUUID(),schoolId:school.id,name:'Carlos Eduardo Lima',role:'Professor de Geografia',type:'Professor',admissionDate:todayIso(),regime:'Horista',cargaHorariaSemanal:16,valorHora:35,salary:Math.round(16*35*4.5*100)/100,status:'Aguardando Liberação de Acesso',hasAccess:false});
    state.teachers.push({id:crypto.randomUUID(),schoolId:school.id,name:'Carlos Eduardo Lima',registration:'PROF-1099',email:'',classId:null,className:'Sem vínculo',status:'Ativo',bond:'Contratado',formation:'Licenciatura em Geografia',contractHours:16});

    // Matrículas, período letivo, comunicados, financeiro, protocolo, ocorrência
    state.enrollmentRequests.push({id:crypto.randomUUID(),schoolId:school.id,studentName:'Vitor Hugo Nascimento',type:'Matrícula Inicial',requestDate:todayIso(),notes:'Documentação entregue; ao concluir esta solicitação, o cadastro do aluno é criado automaticamente.',status:'Em análise'});
    state.enrollmentRequests.push({id:crypto.randomUUID(),schoolId:school.id,studentName:'Yasmin Cordeiro Reis',type:'Transferência Recebida',requestDate:todayIso(),notes:'Aguardando envio do histórico escolar pela escola de origem.',status:'Pendente de documentos'});
    state.academicPeriods.push({id:crypto.randomUUID(),schoolId:school.id,name:`${year} — Ano Letivo`,type:'Ano Letivo',startDate:`${year}-02-03`,endDate:`${year}-12-18`,schoolDays:200,status:'Em andamento'});
    state.announcements.push({id:crypto.randomUUID(),schoolId:school.id,title:'Reunião de pais e mestres — 3º bimestre',audience:'Responsáveis',message:'Convidamos os responsáveis para a reunião de acompanhamento pedagógico, na próxima sexta-feira, às 18h.',sendDate:todayIso(),status:'Enviado'});
    state.announcements.push({id:crypto.randomUUID(),schoolId:school.id,title:'Semana Pedagógica confirmada',audience:'Professores',message:'A Semana Pedagógica acontecerá antes do início do próximo semestre, com palestras e planejamento.',sendDate:todayIso(),status:'Enviado'});
    state.announcements.push({id:crypto.randomUUID(),schoolId:school.id,title:'Calendário de avaliações do 3º bimestre',audience:'Alunos',message:'As avaliações do 3º bimestre seguem o calendário publicado no portal. Bons estudos!',sendDate:todayIso(),status:'Enviado'});
    state.financeRecords.push({id:crypto.randomUUID(),schoolId:school.id,studentId:students[0].id,type:'Taxa / material',amount:120,dueDate:`${year}-11-10`,status:'Em aberto'});
    state.financeRecords.push({id:crypto.randomUUID(),schoolId:school.id,studentId:students[1].id,type:'Taxa / material',amount:120,dueDate:`${year}-09-10`,status:'Atrasado'});
    state.serviceRequests.push({id:crypto.randomUUID(),schoolId:school.id,protocol:'ATD-'+year+'-000123',type:'Declaração Escolar',requester:students[0].name,priority:'Normal',dueDate:`${year}-10-05`,notes:'Declaração para fins de auxílio-transporte.',status:'Em análise'});
    state.occurrences.push({id:crypto.randomUUID(),schoolId:school.id,studentName:students[3].name,studentId:students[3].id,type:'Comportamental',description:'Faltas recorrentes em aulas da manhã; família contatada pela coordenação.',date:isoDaysAgo(5),status:'Encaminhada'});
    state.notifications.push({id:crypto.randomUUID(),schoolId:school.id,type:'comunicado',text:'Reunião de pais e mestres — 3º bimestre.',studentId:null,date:now,read:false});

    const seedLog=(module,action,summary)=>state.auditLog.unshift({id:crypto.randomUUID(),schoolId:school.id,when:now,user:'Sistema',role:'Carga inicial',module,action,summary});
    seedLog('Escolas','Cadastro','Colégio Horizonte Azul cadastrado como escola de demonstração.');
    seedLog('Alunos','Cadastro','18 alunos com 12 responsáveis, distribuídos em 3 turmas.');
    seedLog('Diário','Lançamento de frequência','Aulas e chamadas registradas para as turmas do ano letivo.');
    seedLog('Notas','Lançamento de nota','Notas dos 1º e 2º bimestres lançadas (3º parcial).');
    save();
  }
  if(!state.schools.length){ seedDemoData(); }
  if(!Object.keys(state.permissions||{}).length){ state.permissions = seedDefaultPermissions(); save(); }
  renderAccountCards();

});
